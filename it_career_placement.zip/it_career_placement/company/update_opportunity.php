<?php
// Include your database connection
include('../includes/db_connect.php');

// Ensure this file is only accessed via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Capture the data from the form
    $opp_id = intval($_POST['opp_id']);
    $title = $_POST['title'];
    $min_gpa = floatval($_POST['min_gpa']);
    $skills = $_POST['skills_required'];
    $responsibilities = $_POST['core_responsibilities'];
    $status = $_POST['status'];

    try {
        // Prepare and execute the update query
        // Ensure column names match your 'opportunities' table structure
        $stmt = $pdo->prepare("
            UPDATE opportunities 
            SET title = ?, 
                min_gpa = ?, 
                skills_required = ?, 
                core_responsibilities = ?, 
                status = ? 
            WHERE opp_id = ?
        ");
        
        $stmt->execute([$title, $min_gpa, $skills, $responsibilities, $status, $opp_id]);

        // Redirect back to the manager page with a success message
        header("Location: manage_opportunities.php?success=1");
        exit();

    } catch (PDOException $e) {
        // If there is an error, show it
        die("Error updating record: " . $e->getMessage());
    }
} else {
    // If someone tries to access this page directly without POST, redirect them
    header("Location: manage_opportunities.php");
    exit();
}
?>