<?php
session_start();
include('../includes/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $logo_path = !empty($_FILES['logo']['name']) ? 'uploads/logos/' . basename($_FILES['logo']['name']) : '';
    $license_path = !empty($_FILES['license']['name']) ? 'uploads/licenses/' . basename($_FILES['license']['name']) : '';
    
    if (!empty($_FILES['logo']['tmp_name'])) move_uploaded_file($_FILES['logo']['tmp_name'], '../' . $logo_path);
    if (!empty($_FILES['license']['tmp_name'])) move_uploaded_file($_FILES['license']['tmp_name'], '../' . $license_path);

    $check = $pdo->prepare("SELECT company_id FROM company_profiles WHERE company_id = ?");
    $check->execute([$_SESSION['user_id']]);
    
    if ($check->fetch()) {
        $stmt = $pdo->prepare("UPDATE company_profiles SET name=?, year_established=?, company_size=?, location=?, contact_person=?, website=?, social_links=?, intern_benefits=?, about=?, logo_path=?, license_path=?, status='Pending' WHERE company_id=?");
        $stmt->execute([$_POST['name'], $_POST['year'], $_POST['size'], $_POST['location'], $_POST['contact_person'], $_POST['website'], $_POST['social'], $_POST['intern_benefits'], $_POST['about'], $logo_path, $license_path, $_SESSION['user_id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO company_profiles (company_id, name, year_established, company_size, location, contact_person, website, social_links, intern_benefits, about, logo_path, license_path, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')");
        $stmt->execute([$_SESSION['user_id'], $_POST['name'], $_POST['year'], $_POST['size'], $_POST['location'], $_POST['contact_person'], $_POST['website'], $_POST['social'], $_POST['intern_benefits'], $_POST['about'], $logo_path, $license_path]);
    }

    header("Location: profile.php?msg=success");
    exit();
}
?>