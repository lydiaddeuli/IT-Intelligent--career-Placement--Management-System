<?php
session_start();
include('../includes/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['app_id'])) {
    $app_id = $_POST['app_id'];
    
    // Update the status to Accepted_by_Company
    $stmt = $pdo->prepare("UPDATE applications SET status = 'Accepted_by_Company' WHERE app_id = ?");
    $stmt->execute([$app_id]);
    
    // Redirect back to the review page
    header("Location: review_applications.php?status=success");
    exit();
}
?>