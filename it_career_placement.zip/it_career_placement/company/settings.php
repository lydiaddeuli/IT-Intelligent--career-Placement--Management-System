<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$org_id = $_SESSION['user_id'];
$user_id = $_SESSION['user_id'];

// Fetch company details for header
$stmt = $pdo->prepare("SELECT org_name FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$company = $stmt->fetch();
$company_name = $company['org_name'] ?? 'Company';
$company_avatar = 'https://ui-avatars.com/api/?name=' . urlencode($company_name) . '&background=0091DF&color=fff&size=40';

// Fetch company verification status for sidebar
$stmt = $pdo->prepare("SELECT verification_status FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$org = $stmt->fetch();
$status = $org['verification_status'] ?? 'Pending';

$msg = ""; 
$error = "";

// Process account update parameters 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_account'])) {
        $email = trim($_POST['email']);
        $old_password = $_POST['old_password'];
        $new_password = $_POST['new_password'];
        
        // 1. Update basic data string first
        if (!empty($email)) {
            $updEmail = $pdo->prepare("UPDATE users SET email = ? WHERE user_id = ?");
            $updEmail->execute([$email, $user_id]);
            $msg = "Account parameter records updated.";
        }
        
        // 2. Perform password update sequence if requested
        if (!empty($old_password) && !empty($new_password)) {
            $chk = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
            $chk->execute([$user_id]);
            $current_hash = $chk->fetchColumn();
            
            if (password_verify($old_password, $current_hash)) {
                $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
                $updPass = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $updPass->execute([$new_hash, $user_id]);
                $msg = "Profile parameters and security passwords updated successfully.";
            } else {
                $error = "Authentication Check Failed: Current password statement is invalid.";
            }
        }
    }
}

// Fetch current user email record info block
$userStmt = $pdo->prepare("SELECT email FROM users WHERE user_id = ?");
$userStmt->execute([$user_id]);
$userEmail = $userStmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF; 
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;
            --mustard-yellow: #F59E0B; 
            --dark-text: #1C2D42; 
            --muted-text: #64748B;
            --white: #FFFFFF; 
            --milky-white: #F9F9FB; 
            --border-light: #E2E8F0;
            --pure-black: #000000; 
            --alert-red: #EF4444;
        }
        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }
        
        .sidebar-menu li.locked-role a { 
            color: #A0AEC0; 
            cursor: not-allowed; 
        }
        .sidebar-menu li.locked-role a i { 
            color: #CBD5E0; 
        }
        .lock-tag { 
            margin-left: auto; 
            font-size: 0.7rem; 
            background: #FEE2E2; 
            color: var(--alert-red); 
            padding: 2px 10px; 
            border-radius: 4px; 
            font-weight: 700; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }
        
        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }
        
        .top-badge-indicator { 
            display: flex; 
            align-items: center; 
            gap: 6px; 
            font-size: 0.75rem; 
            font-weight: 700; 
            background: rgba(255,255,255,0.15); 
            padding: 4px 14px; 
            border-radius: 20px; 
            border: 1px solid rgba(255,255,255,0.2);
            white-space: nowrap;
        }
        .top-badge-indicator i {
            font-size: 0.7rem;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .company-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .company-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .settings-card { 
            background: var(--white); 
            padding: 30px 35px; 
            border-radius: 12px; 
            border: 1px solid var(--border-light); 
            max-width: 650px; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02); 
        }
        .settings-card h2 { 
            margin-top: 0; 
            margin-bottom: 4px; 
            font-size: 1.2rem; 
            color: var(--dark-text); 
            font-weight: 800; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
        }
        .settings-card .subtitle {
            color: var(--muted-text);
            font-size: 0.85rem;
            margin-bottom: 22px;
        }
        
        .form-group { 
            margin-bottom: 18px; 
            position: relative; 
        }
        .form-group label { 
            display: block; 
            font-weight: 700; 
            margin-bottom: 5px; 
            color: var(--dark-text); 
            font-size: 0.8rem; 
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .form-group label i {
            margin-right: 6px;
            color: var(--softcare-blue);
        }
        .form-group input[type="email"], 
        .form-group input[type="password"] { 
            width: 100%; 
            padding: 10px 42px 10px 14px; 
            border: 1px solid var(--border-light); 
            border-radius: 8px; 
            box-sizing: border-box; 
            font-size: 0.9rem; 
            background: var(--milky-white); 
            transition: border-color 0.3s; 
            font-family: inherit;
        }
        .form-group input:focus { 
            border-color: var(--softcare-blue); 
            outline: none; 
            background: var(--white); 
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }
        
        .password-toggle-icon { 
            position: absolute; 
            right: 14px; 
            top: 38px; 
            color: var(--muted-text); 
            cursor: pointer; 
            font-size: 1rem; 
            transition: 0.2s;
        }
        .password-toggle-icon:hover { 
            color: var(--softcare-blue); 
        }
        
        .btn-submit { 
            display: block; 
            width: 100%; 
            padding: 12px; 
            background: var(--softcare-blue); 
            color: var(--white); 
            border: none; 
            text-align: center; 
            border-radius: 8px; 
            font-weight: 700; 
            cursor: pointer; 
            text-transform: uppercase; 
            letter-spacing: 0.5px; 
            transition: background 0.3s; 
            font-size: 0.85rem; 
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn-submit:hover { 
            background: #0077b6; 
        }
        
        .alert-box { 
            padding: 12px 18px; 
            border-radius: 8px; 
            font-weight: 600; 
            margin-bottom: 20px; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 0.88rem;
        }
        .alert-success { 
            background: #DCFCE7; 
            color: var(--aloe-green); 
            border: 1px solid #BBF7D0; 
        }
        .alert-danger { 
            background: #FEF2F2; 
            color: var(--alert-red); 
            border: 1px solid #FEE2E2; 
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar { 
                width: 70px; 
            }
            .sidebar-header span {
                display: none;
            }
            .sidebar-header {
                padding: 14px 16px;
                justify-content: center;
                min-height: 56px;
            }
            .sidebar-logo {
                height: 32px;
            }
            .main-content { 
                margin-left: 70px; 
            }
            .sidebar-menu li a span {
                display: none;
            }
            .sidebar-menu li a {
                padding: 12px 16px;
                justify-content: center;
            }
            .sidebar-menu li a i {
                margin: 0;
                font-size: 1.1rem;
            }
            .sidebar-menu li a.active-page {
                padding-left: 16px;
                border-left: 3px solid var(--softcare-blue);
            }
            .lock-tag {
                display: none;
            }
            .app-header-bar {
                padding: 12px 16px;
                min-height: 56px;
                flex-wrap: wrap;
                gap: 8px;
            }
            .header-left .brand-title {
                font-size: 0.95rem;
            }
            .top-badge-indicator {
                font-size: 0.65rem;
                padding: 3px 10px;
            }
            .profile-trigger-zone .company-name {
                font-size: 0.75rem;
                max-width: 80px;
            }
            .company-avatar-circle {
                width: 28px;
                height: 28px;
            }
            .profile-trigger-zone {
                padding-left: 10px;
                gap: 6px;
            }
            .page-content {
                padding: 16px;
            }
            .settings-card {
                padding: 20px;
            }
            .header-dropdown-card {
                right: 10px;
                top: 56px;
                width: 190px;
            }
        }

        @media (max-width: 576px) {
            .sidebar { 
                width: 60px; 
            }
            .main-content { 
                margin-left: 60px; 
            }
            .sidebar-header {
                padding: 12px 12px;
                min-height: 50px;
            }
            .sidebar-logo {
                height: 28px;
            }
            .sidebar-menu li a {
                padding: 10px 12px;
            }
            .sidebar-menu li a i {
                font-size: 1rem;
            }
            .app-header-bar {
                padding: 10px 12px;
                min-height: 50px;
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }
            .header-left {
                flex-wrap: wrap;
                gap: 8px;
                justify-content: center;
            }
            .header-left .brand-title {
                font-size: 0.85rem;
            }
            .top-badge-indicator {
                font-size: 0.6rem;
                padding: 2px 8px;
            }
            .header-right {
                justify-content: center;
            }
            .profile-trigger-zone .company-name {
                display: none;
            }
            .profile-trigger-zone .dropdown-arrow {
                display: none;
            }
            .profile-trigger-zone {
                padding: 3px 6px;
                background: rgba(255,255,255,0.15);
                border-left: none;
            }
            .company-avatar-circle {
                width: 26px;
                height: 26px;
            }
            .page-content {
                padding: 12px;
            }
            .settings-card {
                padding: 16px;
            }
            .settings-card h2 {
                font-size: 1rem;
            }
            .btn-submit {
                font-size: 0.8rem;
                padding: 10px;
            }
            .header-dropdown-card {
                right: 6px;
                top: 48px;
                width: 170px;
            }
            .dropdown-user-info h5 {
                font-size: 0.78rem;
            }
            .dropdown-menu-list li a {
                padding: 8px 14px;
                font-size: 0.78rem;
            }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Hub</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> <span>Profile Manager</span></a></li>
        <li><a href="manage_opportunities.php"><i class="fa-solid fa-briefcase"></i> <span>Manage Opportunity</span></a></li>
        <li><a href="resubmit_requirements.php"><i class="fa-solid fa-pen"></i> <span>Fulfill Requirements</span></a></li>
        
        <?php if ($status === 'Approved'): ?>
            <li><a href="post_opportunity.php"><i class="fa-solid fa-plus-circle"></i> <span>Post Vacancy</span></a></li>
            <li><a href="review_applications.php"><i class="fa-solid fa-folder-open"></i> <span>Applications</span></a></li>
        <?php else: ?>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Unverified companies are blocked from posting jobs to secure IT students from fraud.'); return false;">
                    <i class="fa-solid fa-ban"></i> <span>Post Vacancy</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Access denied until your profile credentials clear validation checkpoints.'); return false;">
                    <i class="fa-solid fa-lock"></i> <span>Applications</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
        <?php endif; ?>
        
        <li><a href="settings.php" class="active-page"><i class="fa-solid fa-gears"></i> <span>Account Settings</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-gears"></i> Account Settings
            </div>
            <?php if($status === 'Approved'): ?>
                <div class="top-badge-indicator" style="background: rgba(16, 185, 129, 0.25); border: 1px solid #10B981;">
                    <i class="fa-solid fa-circle-check" style="color:#10B981;"></i> Verified
                </div>
            <?php elseif($status === 'Action Required'): ?>
                <div class="top-badge-indicator" style="background: rgba(239, 68, 68, 0.25); border: 1px solid #EF4444;">
                    <i class="fa-solid fa-circle-exclamation" style="color:#EF4444;"></i> Action Needed
                </div>
            <?php else: ?>
                <div class="top-badge-indicator" style="background: rgba(245, 158, 11, 0.25); border: 1px solid #F59E0B;">
                    <i class="fa-solid fa-hourglass-start" style="color:#F59E0B;"></i> Pending Review
                </div>
            <?php endif; ?>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $company_avatar; ?>" alt="Company Logo" class="company-avatar-circle">
                <span class="company-name"><?php echo htmlspecialchars($company_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($company_name); ?></h5>
                    <p>Corporate Partner</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> Company Profile</a></li>
                    <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <div class="settings-card">
            <h2><i class="fa-solid fa-user-shield" style="color: var(--softcare-blue);"></i> Corporate Identity Credentials</h2>
            <p class="subtitle">Update authorization links or adjust structural security passwords safely here.</p>
            
            <?php if($msg): ?>
                <div class="alert-box alert-success"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($msg); ?></div>
            <?php endif; ?>
            <?php if($error): ?>
                <div class="alert-box alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label><i class="fa-regular fa-envelope"></i> Corporate Access Email</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($userEmail); ?>" required>
                </div>

                <div class="form-group">
                    <label><i class="fa-solid fa-lock"></i> Current System Password</label>
                    <input type="password" id="old_pass" name="old_password" placeholder="Leave empty if only updating email parameters">
                    <i class="fa-solid fa-eye password-toggle-icon" onclick="toggleMask('old_pass', this)"></i>
                </div>

                <div class="form-group">
                    <label><i class="fa-solid fa-key"></i> New System Password</label>
                    <input type="password" id="new_pass" name="new_password" placeholder="Minimum 8 characters robust hash matrix">
                    <i class="fa-solid fa-eye password-toggle-icon" onclick="toggleMask('new_pass', this)"></i>
                </div>

                <button type="submit" name="update_account" class="btn-submit">
                    <i class="fa-solid fa-save"></i> Apply Settings Verification Tokens
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});

function toggleMask(targetFieldId, triggerIcon) {
    const field = document.getElementById(targetFieldId);
    if (field.type === "password") {
        field.type = "text";
        triggerIcon.classList.remove("fa-eye");
        triggerIcon.classList.add("fa-eye-slash");
    } else {
        field.type = "password";
        triggerIcon.classList.remove("fa-eye-slash");
        triggerIcon.classList.add("fa-eye");
    }
}
</script>
</body>
</html>