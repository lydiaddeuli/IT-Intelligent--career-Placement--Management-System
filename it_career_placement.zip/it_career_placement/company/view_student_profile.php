<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$org_id = $_SESSION['user_id'];

// Get student ID from URL
$student_id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
$app_id = isset($_GET['app_id']) ? (int)$_GET['app_id'] : 0;

if ($student_id <= 0) {
    header("Location: review_applications.php");
    exit();
}

// Fetch student details with profile
$stmt = $pdo->prepare("
    SELECT u.user_id, u.full_name, u.email, u.role,
           sp.placement_type, sp.skills, sp.bio, sp.cv_path, 
           sp.transcript_path, sp.profile_pic
    FROM users u
    LEFT JOIN student_profiles sp ON u.user_id = sp.student_id
    WHERE u.user_id = ? AND u.role = 'student'
");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    header("Location: review_applications.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile View | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            color: var(--pure-black); 
            position: fixed; 
            top: 0;
            bottom: 0;
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex;
            flex-direction: column;
            border-right: 1px solid var(--border-light);
        }
        
        .sidebar-header { 
            padding: 25px 20px; 
            background: var(--white); 
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 900; 
            letter-spacing: -0.5px; 
            font-size: 1.15rem; 
            border-bottom: 2px solid var(--border-light); 
            color: var(--pure-black);
        }

        .sidebar-logo {
            height: 38px;
            width: auto;
            border-radius: 6px;
            background: var(--white);
            padding: 2px;
            border: 1px solid var(--border-light);
        }
        
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1;
            overflow-y: auto;
        }
        .sidebar-menu li { margin-bottom: 4px; }
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            padding: 12px 24px; 
            color: var(--pure-black); 
            text-decoration: none; 
            transition: 0.2s ease-in-out;
            font-weight: 700; 
            font-size: 0.95rem;
        }
        .sidebar-menu li a i { 
            margin-right: 15px; 
            width: 20px; 
            font-size: 1.05rem; 
            text-align: center; 
            color: var(--pure-black); 
        }
        .sidebar-menu li a:hover { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i { color: var(--softcare-blue); }
        .sidebar-menu li a.active-page { 
            color: var(--softcare-blue); 
            background: var(--softcare-light-blue); 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }
        .sidebar-menu li a.active-page i { color: var(--softcare-blue); }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            padding: 30px 40px; 
            box-sizing: border-box; 
            display: flex;
            flex-direction: column;
            background: var(--white);
        }

        .app-header-bar {
            background: var(--softcare-blue);
            border-bottom: none;
            padding: 16px 24px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 12px;
            box-shadow: 0 4px 14px rgba(0, 145, 223, 0.2);
        }

        .header-title-left {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--white);
            letter-spacing: -0.3px;
        }

        .header-title-left i {
            margin-right: 10px;
        }

        .header-controls-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .user-profile-dropdown-wrapper {
            position: relative;
            display: inline-block;
        }

        .user-identity-block {
            border-left: 1px solid rgba(255, 255, 255, 0.3);
            padding-left: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
        }

        .profile-circle-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--white);
            border: 2px solid rgba(255, 255, 255, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--softcare-blue);
            font-size: 1.1rem;
        }

        .profile-settings-overlay {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: var(--white);
            min-width: 200px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            border-radius: 8px;
            border: 1px solid var(--border-light);
            z-index: 600;
            overflow: hidden;
        }

        .user-profile-dropdown-wrapper:hover .profile-settings-overlay { display: block; }

        .profile-settings-overlay a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 600;
            transition: background 0.15s;
            cursor: pointer;
        }

        .profile-settings-overlay a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .profile-settings-overlay .logout-divider {
            border-top: 1px solid var(--border-light);
            color: var(--alert-red);
        }
        .profile-settings-overlay a.logout-divider:hover {
            background: #FEF2F2;
            color: var(--alert-red);
        }

        /* Profile Card Styles - Matching the image you shared */
        .profile-container {
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
        }

        .profile-header-section {
            background: var(--softcare-light-blue);
            padding: 30px 35px;
            border-bottom: 1px solid var(--border-light);
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .profile-avatar-large {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: var(--white);
            border: 4px solid var(--softcare-blue);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: var(--softcare-blue);
            flex-shrink: 0;
        }

        .profile-name-title h2 {
            margin: 0 0 5px 0;
            font-size: 1.5rem;
            color: var(--dark-text);
        }

        .profile-name-title p {
            margin: 0;
            color: var(--muted-text);
            font-size: 0.95rem;
        }

        .profile-name-title .course-tag {
            display: inline-block;
            margin-top: 8px;
            background: var(--softcare-blue);
            color: var(--white);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.78rem;
            font-weight: 700;
        }

        .profile-details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            padding: 25px 35px;
            border-bottom: 1px solid var(--border-light);
        }

        .profile-detail-item {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .profile-detail-item label {
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--muted-text);
            font-weight: 700;
        }

        .profile-detail-item .value {
            font-size: 0.95rem;
            color: var(--dark-text);
            font-weight: 600;
        }

        .profile-detail-item .value i {
            margin-right: 8px;
            color: var(--softcare-blue);
            width: 18px;
        }

        .profile-section-title {
            padding: 20px 35px 10px 35px;
            font-size: 1rem;
            font-weight: 700;
            color: var(--dark-text);
        }

        .profile-section-title i {
            margin-right: 10px;
            color: var(--softcare-blue);
        }

        .profile-bio-section {
            padding: 0 35px 20px 35px;
        }

        .profile-bio-section p {
            margin: 0;
            line-height: 1.7;
            color: var(--dark-text);
        }

        .profile-skills-section {
            padding: 0 35px 20px 35px;
        }

        .skills-tag-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .skill-tag {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 0.82rem;
            font-weight: 700;
        }

        .profile-actions {
            padding: 20px 35px 30px 35px;
            border-top: 1px solid var(--border-light);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn-back {
            background: var(--milky-white);
            color: var(--dark-text);
            padding: 10px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 700;
            border: 1px solid var(--border-light);
            transition: background 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-back:hover {
            background: var(--border-light);
        }

        .btn-accept-profile {
            background: var(--aloe-green);
            color: var(--white);
            padding: 10px 24px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 700;
            transition: background 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-accept-profile:hover {
            background: #006B36;
        }

        .btn-download {
            background: var(--softcare-blue);
            color: var(--white);
            padding: 10px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 700;
            transition: background 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-download:hover {
            background: #0077B8;
        }

        .empty-value {
            color: var(--muted-text);
            font-style: italic;
        }

        @media (max-width: 768px) {
            .profile-details-grid {
                grid-template-columns: 1fr;
            }
            .profile-header-section {
                flex-direction: column;
                text-align: center;
            }
            .profile-actions {
                flex-direction: column;
            }
            .profile-actions a, .profile-actions form {
                width: 100%;
            }
            .profile-actions a, .profile-actions button {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard Hub</a></li>
        <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> Profile Manager</a></li>
        <li><a href="manage_opportunities.php"><i class="fa-solid fa-briefcase"></i> Manage Opportunity</a></li>
        <li><a href="post_opportunity.php"><i class="fa-solid fa-plus-circle"></i> Post Vacancy</a></li>
        <li><a href="review_applications.php" class="active-page"><i class="fa-solid fa-folder-open"></i> Applications Review</a></li>
        <li><a href="resubmit_requirements.php"><i class="fa-solid fa-cloud-arrow-up"></i> Fix Requirements</a></li>
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
    </ul>
</div>

<div class="main-content">
    
    <div class="app-header-bar">
        <div class="header-title-left">
            <i class="fa-solid fa-user-graduate"></i> Student Profile View
        </div>
        
        <div class="header-controls-right">
            <div class="user-profile-dropdown-wrapper">
                <div class="user-identity-block">
                    <div class="profile-circle-avatar">
                        <i class="fa-solid fa-building"></i>
                    </div>
                </div>

                <div class="profile-settings-overlay">
                    <a href="../logout.php" class="logout-divider"><i class="fa-solid fa-power-off"></i> Sign Out</a>
                </div>
            </div>
        </div>
    </div>

    <div class="profile-container">
        <!-- Profile Header -->
        <div class="profile-header-section">
            <div class="profile-avatar-large">
                <i class="fa-solid fa-user"></i>
            </div>
            <div class="profile-name-title">
                <h2><?php echo htmlspecialchars($student['full_name']); ?></h2>
                <p><?php echo htmlspecialchars($student['email']); ?></p>
                <?php if(!empty($student['placement_type'])): ?>
                    <span class="course-tag"><i class="fa-regular fa-graduation-cap"></i> <?php echo htmlspecialchars($student['placement_type']); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <!-- Contact Details Grid -->
        <div class="profile-details-grid">
            <div class="profile-detail-item">
                <label>Full Name</label>
                <div class="value"><i class="fa-regular fa-user"></i> <?php echo htmlspecialchars($student['full_name']); ?></div>
            </div>
            <div class="profile-detail-item">
                <label>Email Address</label>
                <div class="value"><i class="fa-regular fa-envelope"></i> <?php echo htmlspecialchars($student['email']); ?></div>
            </div>
            <div class="profile-detail-item">
                <label>Student ID</label>
                <div class="value"><i class="fa-regular fa-id-card"></i> <?php echo htmlspecialchars($student['user_id']); ?></div>
            </div>
            <div class="profile-detail-item">
                <label>Placement Type</label>
                <div class="value"><i class="fa-regular fa-briefcase"></i> <?php echo htmlspecialchars($student['placement_type'] ?? 'Not specified'); ?></div>
            </div>
        </div>

        <!-- Professional Bio -->
        <div class="profile-section-title"><i class="fa-regular fa-file-lines"></i> Professional Bio</div>
        <div class="profile-bio-section">
            <p><?php echo !empty($student['bio']) ? htmlspecialchars($student['bio']) : '<span class="empty-value">No bio has been added yet.</span>'; ?></p>
        </div>

        <!-- Technical Skills -->
        <div class="profile-section-title"><i class="fa-solid fa-code"></i> Technical Skills</div>
        <div class="profile-skills-section">
            <?php if(!empty($student['skills'])): ?>
                <div class="skills-tag-container">
                    <?php 
                    $skills = explode(',', $student['skills']);
                    foreach($skills as $skill): 
                        $skill = trim($skill);
                        if(!empty($skill)):
                    ?>
                        <span class="skill-tag"><i class="fa-solid fa-tag"></i> <?php echo htmlspecialchars($skill); ?></span>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
            <?php else: ?>
                <p class="empty-value">No technical skills have been added.</p>
            <?php endif; ?>
        </div>

        <!-- Action Buttons -->
        <div class="profile-actions">
            <a href="review_applications.php" class="btn-back">
                <i class="fa-solid fa-arrow-left"></i> Back to Applicants
            </a>
            <?php if($app_id > 0): ?>
                <form action="process_accept.php" method="POST" style="display:inline;">
                    <input type="hidden" name="app_id" value="<?php echo $app_id; ?>">
                    <button type="submit" class="btn-accept-profile">
                        <i class="fa-regular fa-circle-check"></i> Accept Application
                    </button>
                </form>
            <?php endif; ?>
            <?php if(!empty($student['cv_path']) && file_exists($student['cv_path'])): ?>
                <a href="<?php echo htmlspecialchars($student['cv_path']); ?>" class="btn-download" target="_blank">
                    <i class="fa-solid fa-download"></i> Download CV
                </a>
            <?php endif; ?>
        </div>
    </div>

</div>

</body>
</html>