<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$org_id = $_SESSION['user_id'];

// Fetch company details for header
$stmt = $pdo->prepare("SELECT org_name FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$company = $stmt->fetch();
$company_name = $company['org_name'] ?? 'Company';
$company_avatar = 'https://ui-avatars.com/api/?name=' . urlencode($company_name) . '&background=0091DF&color=fff&size=40';

// Fetch company verification status for sidebar
$stmt = $pdo->prepare("SELECT verification_status FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$org = $stmt->fetch();
$status = $org['verification_status'] ?? 'Pending';

// Handle Publish
if (isset($_GET['publish_id'])) {
    $opp_id = intval($_GET['publish_id']);
    $stmt = $pdo->prepare("UPDATE opportunities SET status = 'published' WHERE opp_id = ? AND company_id = ?");
    $stmt->execute([$opp_id, $org_id]);
    $_SESSION['opportunity_success'] = "Opportunity published successfully! It is now visible to students.";
    header("Location: manage_opportunities.php");
    exit();
}

// Handle Delete
if (isset($_GET['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM opportunities WHERE opp_id = ? AND company_id = ?");
    $stmt->execute([intval($_GET['delete_id']), $org_id]);
    $_SESSION['opportunity_success'] = "Opportunity deleted successfully!";
    header("Location: manage_opportunities.php");
    exit();
}

// Handle Block/Unblock
if (isset($_GET['block_id'])) {
    $opp_id = intval($_GET['block_id']);
    $stmt = $pdo->prepare("UPDATE opportunities SET status = 'blocked' WHERE opp_id = ? AND company_id = ?");
    $stmt->execute([$opp_id, $org_id]);
    $_SESSION['opportunity_success'] = "Opportunity blocked successfully! Students cannot apply.";
    header("Location: manage_opportunities.php");
    exit();
}

if (isset($_GET['unblock_id'])) {
    $opp_id = intval($_GET['unblock_id']);
    $stmt = $pdo->prepare("UPDATE opportunities SET status = 'published' WHERE opp_id = ? AND company_id = ?");
    $stmt->execute([$opp_id, $org_id]);
    $_SESSION['opportunity_success'] = "Opportunity unblocked successfully!";
    header("Location: manage_opportunities.php");
    exit();
}

// Fetch opportunities for this specific company
$my_vacancies = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM opportunities WHERE company_id = ? ORDER BY created_at DESC");
    $stmt->execute([$org_id]);
    $my_vacancies = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error fetching data: " . $e->getMessage());
}

// Count statistics
$total_opportunities = count($my_vacancies);
$draft_count = 0;
$published_count = 0;
$blocked_count = 0;

foreach ($my_vacancies as $opp) {
    $opp_status = $opp['status'] ?? 'draft';
    if ($opp_status === 'draft') $draft_count++;
    elseif ($opp_status === 'published') $published_count++;
    elseif ($opp_status === 'blocked') $blocked_count++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Opportunities | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF; 
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;
            --mustard-yellow: #F59E0B; 
            --dark-text: #1C2D42; 
            --muted-text: #64748B;
            --white: #FFFFFF; 
            --milky-white: #F9F9FB; 
            --border-light: #E2E8F0;
            --pure-black: #000000; 
            --alert-red: #EF4444;
        }
        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }
        
        .sidebar-menu li.locked-role a { 
            color: #A0AEC0; 
            cursor: not-allowed; 
        }
        .sidebar-menu li.locked-role a i { 
            color: #CBD5E0; 
        }
        .lock-tag { 
            margin-left: auto; 
            font-size: 0.7rem; 
            background: #FEE2E2; 
            color: var(--alert-red); 
            padding: 2px 10px; 
            border-radius: 4px; 
            font-weight: 700; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }
        
        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }
        
        .top-badge-indicator { 
            display: flex; 
            align-items: center; 
            gap: 6px; 
            font-size: 0.75rem; 
            font-weight: 700; 
            background: rgba(255,255,255,0.15); 
            padding: 4px 14px; 
            border-radius: 20px; 
            border: 1px solid rgba(255,255,255,0.2);
            white-space: nowrap;
        }
        .top-badge-indicator i {
            font-size: 0.7rem;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .company-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .company-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 12px;
        }

        .page-header h2 { 
            margin: 0; 
            font-weight: 800; 
            font-size: 1.3rem; 
        }
        .page-header h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }

        .btn-add { 
            background: var(--softcare-blue); 
            color: white; 
            padding: 8px 18px; 
            border-radius: 6px; 
            text-decoration: none; 
            font-size: 0.85rem; 
            font-weight: 700; 
            display: inline-flex; 
            align-items: center; 
            gap: 6px; 
            transition: background 0.2s; 
            border: none;
        }
        .btn-add:hover { 
            background: #0077b6; 
        }

        .summary-dashboard-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .metric-card-box {
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 10px;
            padding: 14px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
        }

        .metric-card-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.05);
        }

        .metric-card-box .metric-info h5 {
            margin: 0 0 2px 0;
            font-size: 0.65rem;
            color: var(--muted-text);
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
        }

        .metric-card-box .metric-info .metric-val {
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .metric-card-box .metric-icon {
            width: 34px;
            height: 34px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            color: var(--white);
            flex-shrink: 0;
        }

        .metric-card-box .metric-icon.total { background: var(--softcare-blue); }
        .metric-card-box .metric-icon.draft { background: var(--mustard-yellow); }
        .metric-card-box .metric-icon.published { background: var(--aloe-green); }
        .metric-card-box .metric-icon.blocked { background: var(--alert-red); }

        .history-table-container { 
            border: 1px solid var(--border-light); 
            border-radius: 12px; 
            overflow: hidden; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02); 
            background: var(--white);
        }
        .dashboard-list-table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        .dashboard-list-table th { 
            background: var(--milky-white); 
            padding: 12px 18px; 
            text-align: left; 
            font-size: 0.7rem; 
            text-transform: uppercase; 
            color: var(--dark-text); 
            font-weight: 700; 
            letter-spacing: 0.5px; 
        }
        .dashboard-list-table td { 
            padding: 12px 18px; 
            border-bottom: 1px solid var(--border-light); 
            color: var(--dark-text); 
            font-size: 0.88rem; 
            vertical-align: middle;
        }
        .dashboard-list-table tr:last-child td { 
            border-bottom: none; 
        }
        .dashboard-list-table tr:hover td { 
            background: var(--softcare-light-blue); 
        }
        
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 10px;
            border-radius: 16px;
            font-size: 0.68rem;
            font-weight: 700;
        }

        .status-badge.draft {
            background: #FFFBEB;
            color: #B45309;
            border: 1px solid #FCD34D;
        }

        .status-badge.published {
            background: #DCFCE7;
            color: var(--aloe-green);
            border: 1px solid #BBF7D0;
        }

        .status-badge.blocked {
            background: #FEF2F2;
            color: var(--alert-red);
            border: 1px solid #FEE2E2;
        }

        .btn-edit { 
            color: var(--softcare-blue); 
            cursor: pointer; 
            font-weight: 600; 
            text-decoration: none; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            transition: 0.2s;
        }
        .btn-edit:hover { 
            background: var(--softcare-light-blue); 
        }
        .btn-delete { 
            color: var(--alert-red); 
            text-decoration: none; 
            font-weight: 600; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            transition: 0.2s;
        }
        .btn-delete:hover { 
            background: #FEF2F2; 
        }
        .btn-publish { 
            color: var(--aloe-green); 
            text-decoration: none; 
            font-weight: 600; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            transition: 0.2s;
        }
        .btn-publish:hover { 
            background: #DCFCE7; 
        }
        .btn-block { 
            color: var(--mustard-yellow); 
            text-decoration: none; 
            font-weight: 600; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            transition: 0.2s;
        }
        .btn-block:hover { 
            background: #FFFBEB; 
        }
        .btn-unblock { 
            color: var(--aloe-green); 
            text-decoration: none; 
            font-weight: 600; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            transition: 0.2s;
        }
        .btn-unblock:hover { 
            background: #DCFCE7; 
        }

        .action-buttons {
            display: flex;
            align-items: center;
            gap: 2px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: var(--muted-text);
        }
        .empty-state i {
            font-size: 2.5rem;
            color: var(--border-light);
            margin-bottom: 12px;
            display: block;
        }
        .empty-state h4 {
            margin: 0 0 6px 0;
            color: var(--dark-text);
            font-size: 1.1rem;
        }
        .empty-state p {
            font-size: 0.9rem;
        }

        .success-message {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        /* Mobile Responsive */
        @media (max-width: 992px) {
            .summary-dashboard-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar { 
                width: 70px; 
            }
            .sidebar-header span {
                display: none;
            }
            .sidebar-header {
                padding: 14px 16px;
                justify-content: center;
                min-height: 56px;
            }
            .sidebar-logo {
                height: 32px;
            }
            .main-content { 
                margin-left: 70px; 
            }
            .sidebar-menu li a span {
                display: none;
            }
            .sidebar-menu li a {
                padding: 12px 16px;
                justify-content: center;
            }
            .sidebar-menu li a i {
                margin: 0;
                font-size: 1.1rem;
            }
            .sidebar-menu li a.active-page {
                padding-left: 16px;
                border-left: 3px solid var(--softcare-blue);
            }
            .lock-tag {
                display: none;
            }
            .app-header-bar {
                padding: 12px 16px;
                min-height: 56px;
                flex-wrap: wrap;
                gap: 8px;
            }
            .header-left .brand-title {
                font-size: 0.95rem;
            }
            .top-badge-indicator {
                font-size: 0.65rem;
                padding: 3px 10px;
            }
            .profile-trigger-zone .company-name {
                font-size: 0.75rem;
                max-width: 80px;
            }
            .company-avatar-circle {
                width: 28px;
                height: 28px;
            }
            .profile-trigger-zone {
                padding-left: 10px;
                gap: 6px;
            }
            .page-content {
                padding: 16px;
            }
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .page-header h2 {
                font-size: 1.1rem;
            }
            .btn-add {
                width: 100%;
                justify-content: center;
            }
            .summary-dashboard-cards {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
            }
            .metric-card-box {
                padding: 12px 14px;
            }
            .metric-card-box .metric-info .metric-val {
                font-size: 1.1rem;
            }
            .metric-card-box .metric-icon {
                width: 30px;
                height: 30px;
                font-size: 0.8rem;
            }
            .action-buttons {
                flex-direction: column;
                align-items: flex-start;
            }
            .header-dropdown-card {
                right: 10px;
                top: 56px;
                width: 190px;
            }
        }

        @media (max-width: 576px) {
            .sidebar { 
                width: 60px; 
            }
            .main-content { 
                margin-left: 60px; 
            }
            .sidebar-header {
                padding: 12px 12px;
                min-height: 50px;
            }
            .sidebar-logo {
                height: 28px;
            }
            .sidebar-menu li a {
                padding: 10px 12px;
            }
            .sidebar-menu li a i {
                font-size: 1rem;
            }
            .app-header-bar {
                padding: 10px 12px;
                min-height: 50px;
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }
            .header-left {
                flex-wrap: wrap;
                gap: 8px;
                justify-content: center;
            }
            .header-left .brand-title {
                font-size: 0.85rem;
            }
            .top-badge-indicator {
                font-size: 0.6rem;
                padding: 2px 8px;
            }
            .header-right {
                justify-content: center;
            }
            .profile-trigger-zone .company-name {
                display: none;
            }
            .profile-trigger-zone .dropdown-arrow {
                display: none;
            }
            .profile-trigger-zone {
                padding: 3px 6px;
                background: rgba(255,255,255,0.15);
                border-left: none;
            }
            .company-avatar-circle {
                width: 26px;
                height: 26px;
            }
            .page-content {
                padding: 12px;
            }
            .page-header h2 {
                font-size: 1rem;
            }
            .summary-dashboard-cards {
                grid-template-columns: 1fr;
                gap: 8px;
            }
            .metric-card-box {
                padding: 10px 12px;
            }
            .metric-card-box .metric-info .metric-val {
                font-size: 1rem;
            }
            .metric-card-box .metric-icon {
                width: 26px;
                height: 26px;
                font-size: 0.7rem;
            }
            .header-dropdown-card {
                right: 6px;
                top: 48px;
                width: 170px;
            }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Hub</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> <span>Profile Manager</span></a></li>
        <li><a href="manage_opportunities.php" class="active-page"><i class="fa-solid fa-briefcase"></i> <span>Manage Opportunity</span></a></li>
        <li><a href="resubmit_requirements.php"><i class="fa-solid fa-pen"></i> <span>Fulfill Requirements</span></a></li>
        
        <?php if ($status === 'Approved'): ?>
            <li><a href="post_opportunity.php"><i class="fa-solid fa-plus-circle"></i> <span>Post Vacancy</span></a></li>
            <li><a href="review_applications.php"><i class="fa-solid fa-folder-open"></i> <span>Applications</span></a></li>
        <?php else: ?>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Unverified companies are blocked from posting jobs to secure IT students from fraud.'); return false;">
                    <i class="fa-solid fa-ban"></i> <span>Post Vacancy</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Access denied until your profile credentials clear validation checkpoints.'); return false;">
                    <i class="fa-solid fa-lock"></i> <span>Applications</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
        <?php endif; ?>
        
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> <span>Account Settings</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-briefcase"></i> Manage Opportunities
            </div>
            <?php if($status === 'Approved'): ?>
                <div class="top-badge-indicator" style="background: rgba(16, 185, 129, 0.25); border: 1px solid #10B981;">
                    <i class="fa-solid fa-circle-check" style="color:#10B981;"></i> Verified
                </div>
            <?php elseif($status === 'Action Required'): ?>
                <div class="top-badge-indicator" style="background: rgba(239, 68, 68, 0.25); border: 1px solid #EF4444;">
                    <i class="fa-solid fa-circle-exclamation" style="color:#EF4444;"></i> Action Needed
                </div>
            <?php else: ?>
                <div class="top-badge-indicator" style="background: rgba(245, 158, 11, 0.25); border: 1px solid #F59E0B;">
                    <i class="fa-solid fa-hourglass-start" style="color:#F59E0B;"></i> Pending Review
                </div>
            <?php endif; ?>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $company_avatar; ?>" alt="Company Logo" class="company-avatar-circle">
                <span class="company-name"><?php echo htmlspecialchars($company_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($company_name); ?></h5>
                    <p>Corporate Partner</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> Company Profile</a></li>
                    <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <?php if (isset($_SESSION['opportunity_success'])): ?>
            <div class="success-message">
                <i class="fa-solid fa-circle-check"></i> <?php echo $_SESSION['opportunity_success']; unset($_SESSION['opportunity_success']); ?>
            </div>
        <?php endif; ?>

        <div class="page-header">
            <h2><i class="fa-solid fa-briefcase"></i> Manage Opportunities</h2>
            <a href="post_opportunity.php" class="btn-add"><i class="fa-solid fa-plus-circle"></i> Create New</a>
        </div>

        <!-- Status Summary Cards -->
        <div class="summary-dashboard-cards">
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Total</h5>
                    <div class="metric-val"><?php echo $total_opportunities; ?></div>
                </div>
                <div class="metric-icon total">
                    <i class="fa-solid fa-list"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Drafts</h5>
                    <div class="metric-val"><?php echo $draft_count; ?></div>
                </div>
                <div class="metric-icon draft">
                    <i class="fa-solid fa-pen-fancy"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Published</h5>
                    <div class="metric-val"><?php echo $published_count; ?></div>
                </div>
                <div class="metric-icon published">
                    <i class="fa-regular fa-circle-check"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Blocked</h5>
                    <div class="metric-val"><?php echo $blocked_count; ?></div>
                </div>
                <div class="metric-icon blocked">
                    <i class="fa-solid fa-ban"></i>
                </div>
            </div>
        </div>

        <div class="history-table-container">
            <table class="dashboard-list-table">
                <thead>
                    <tr>
                        <th><i class="fa-regular fa-file-lines"></i> Title</th>
                        <th><i class="fa-regular fa-tag"></i> Type</th>
                        <th><i class="fa-regular fa-calendar"></i> Deadline</th>
                        <th><i class="fa-regular fa-circle"></i> Status</th>
                        <th style="text-align:right;"><i class="fa-regular fa-pen-to-square"></i> Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($my_vacancies)): ?>
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">
                                    <i class="fa-regular fa-briefcase"></i>
                                    <h4>No Opportunities Yet</h4>
                                    <p>Create your first opportunity draft by clicking "Create New".</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($my_vacancies as $row): 
                            $opp_status = $row['status'] ?? 'draft';
                            $status_class = $opp_status;
                            $status_icon = $opp_status === 'draft' ? 'fa-pen-fancy' : ($opp_status === 'published' ? 'fa-circle-check' : 'fa-ban');
                        ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($row['title']); ?></strong></td>
                                <td>
                                    <span style="background:var(--softcare-light-blue);padding:2px 10px;border-radius:12px;font-size:0.7rem;font-weight:600;color:var(--softcare-blue);">
                                        <?php echo htmlspecialchars($row['type']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($row['closing_date'])); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $status_class; ?>">
                                        <i class="fa-regular <?php echo $status_icon; ?>"></i>
                                        <?php echo ucfirst($opp_status); ?>
                                    </span>
                                </td>
                                <td style="text-align:right;">
                                    <div class="action-buttons">
                                        <span class="btn-edit" onclick="window.location.href='edit_opportunity.php?id=<?php echo $row['opp_id']; ?>'">
                                            <i class="fa-solid fa-pen"></i> Edit
                                        </span>
                                        
                                        <?php if ($opp_status === 'draft'): ?>
                                            <a href="?publish_id=<?php echo $row['opp_id']; ?>" class="btn-publish" onclick="return confirm('Publish this opportunity? Students will be able to apply.')">
                                                <i class="fa-regular fa-circle-check"></i> Publish
                                            </a>
                                        <?php elseif ($opp_status === 'published'): ?>
                                            <a href="?block_id=<?php echo $row['opp_id']; ?>" class="btn-block" onclick="return confirm('Block this opportunity? Students will not be able to apply.')">
                                                <i class="fa-solid fa-ban"></i> Block
                                            </a>
                                        <?php elseif ($opp_status === 'blocked'): ?>
                                            <a href="?unblock_id=<?php echo $row['opp_id']; ?>" class="btn-unblock" onclick="return confirm('Unblock this opportunity? Students can apply again.')">
                                                <i class="fa-regular fa-circle-check"></i> Unblock
                                            </a>
                                        <?php endif; ?>
                                        
                                        <a href="?delete_id=<?php echo $row['opp_id']; ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this vacancy permanently?')">
                                            <i class="fa-solid fa-trash"></i> Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});
</script>

</body>
</html>