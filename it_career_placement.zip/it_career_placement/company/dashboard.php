<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$org_id = $_SESSION['user_id'];

// Fetch company details for header
$stmt = $pdo->prepare("SELECT org_name FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$company = $stmt->fetch();
$company_name = $company['org_name'] ?? 'Company';
$company_avatar = 'https://ui-avatars.com/api/?name=' . urlencode($company_name) . '&background=0091DF&color=fff&size=40';

// Fetch the verification metrics and compliance reason directly
$stmt = $pdo->prepare("SELECT verification_status, rejection_reason FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$org = $stmt->fetch();
$status = $org['verification_status'] ?? 'Pending';
$rejection_reason = $org['rejection_reason'] ?? '';

$active_openings = 0;
$total_pending_apps = 0;
$total_approved_students = 0;

if ($status === 'Approved') {
    // Count active opportunities
    $stmt_active = $pdo->prepare("SELECT COUNT(*) FROM opportunities WHERE company_id = ?");
    $stmt_active->execute([$org_id]);
    $active_openings = $stmt_active->fetchColumn();

    // Count pending applications
    $stmt_pending_apps = $pdo->prepare("
        SELECT COUNT(*) 
        FROM applications a 
        JOIN opportunities o ON a.opportunity_id = o.opp_id 
        WHERE o.company_id = ? AND a.status = 'Pending'
    ");
    $stmt_pending_apps->execute([$org_id]);
    $total_pending_apps = $stmt_pending_apps->fetchColumn();

    // Count approved/confirmed students (students who have been accepted and confirmed)
    $stmt_approved = $pdo->prepare("
        SELECT COUNT(*) 
        FROM applications a 
        JOIN opportunities o ON a.opportunity_id = o.opp_id 
        WHERE o.company_id = ? AND (a.status = 'Accepted' OR a.status = 'Confirmed')
    ");
    $stmt_approved->execute([$org_id]);
    $total_approved_students = $stmt_approved->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Control Room | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF; 
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;
            --mustard-yellow: #F59E0B; 
            --dark-text: #1C2D42; 
            --muted-text: #64748B;
            --white: #FFFFFF; 
            --milky-white: #F9F9FB; 
            --border-light: #E2E8F0;
            --pure-black: #000000; 
            --alert-red: #EF4444;
        }
        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }
        
        /* --- SIDEBAR - NO HEADER SEPARATION --- */
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        /* SIDEBAR HEADER - BLUE BACKGROUND */
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }
        
        .sidebar-menu li.locked-role a { 
            color: #A0AEC0; 
            cursor: not-allowed; 
        }
        .sidebar-menu li.locked-role a i { 
            color: #CBD5E0; 
        }
        .lock-tag { 
            margin-left: auto; 
            font-size: 0.7rem; 
            background: #FEE2E2; 
            color: var(--alert-red); 
            padding: 2px 10px; 
            border-radius: 4px; 
            font-weight: 700; 
        }

        /* --- MAIN CONTENT --- */
        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }
        
        /* --- TOP HEADER BAR - SAME LEVEL AS SIDEBAR HEADER --- */
        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }
        
        .top-badge-indicator { 
            display: flex; 
            align-items: center; 
            gap: 6px; 
            font-size: 0.75rem; 
            font-weight: 700; 
            background: rgba(255,255,255,0.15); 
            padding: 4px 14px; 
            border-radius: 20px; 
            border: 1px solid rgba(255,255,255,0.2);
            white-space: nowrap;
        }
        .top-badge-indicator i {
            font-size: 0.7rem;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .company-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .company-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        /* Profile Dropdown */
        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        /* --- PAGE CONTENT --- */
        .page-content {
            padding: 30px 35px;
        }

        /* Cards */
        .summary-dashboard-cards { 
            display: grid; 
            grid-template-columns: repeat(3, 1fr); 
            gap: 20px; 
            margin-bottom: 30px; 
        }
        .metric-card-box { 
            background: var(--white); 
            border: 1px solid var(--border-light); 
            border-radius: 12px; 
            padding: 18px 22px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            transition: transform 0.2s, box-shadow 0.2s; 
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }
        .metric-card-box:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06); 
        }
        .metric-card-box.locked-card { 
            background: #F8FAFC; 
            opacity: 0.6; 
        }
        .metric-card-box .metric-info h5 { 
            margin: 0 0 2px 0; 
            font-size: 0.7rem; 
            color: var(--muted-text); 
            text-transform: uppercase; 
            letter-spacing: 0.4px; 
            font-weight: 700; 
        }
        .metric-card-box .metric-info .metric-val { 
            font-size: 1.5rem; 
            font-weight: 800; 
            color: var(--dark-text); 
        }
        .metric-card-box .metric-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: var(--white);
            flex-shrink: 0;
        }
        .metric-card-box .metric-icon.blue { background: var(--softcare-blue); }
        .metric-card-box .metric-icon.yellow { background: var(--mustard-yellow); }
        .metric-card-box .metric-icon.green { background: var(--aloe-green); }
        .metric-card-box .metric-icon.purple { background: #8B5CF6; }

        .feedback-alert-container { 
            background: #FFF5F5; 
            border: 1px solid #FEB2B2; 
            border-left: 5px solid var(--alert-red); 
            padding: 20px 24px; 
            border-radius: 10px; 
            margin-bottom: 30px; 
        }
        .feedback-alert-container h4 { 
            margin: 0 0 6px 0; 
            color: #9B1C1C; 
            font-size: 1rem; 
            font-weight: 800; 
            display: flex; 
            align-items: center; 
            gap: 8px; 
        }
        
        .btn-fix-now { 
            background: var(--alert-red); 
            color: var(--white); 
            padding: 10px 20px; 
            border-radius: 6px; 
            text-decoration: none; 
            font-weight: 700; 
            font-size: 0.85rem; 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
            border: none; 
            transition: 0.2s; 
        }
        .btn-fix-now:hover { 
            background: #DC2626; 
        }

        /* Mobile Responsive */
        @media (max-width: 992px) {
            .summary-dashboard-cards { 
                grid-template-columns: repeat(2, 1fr); 
                gap: 15px; 
            }
        }

        @media (max-width: 768px) {
            .sidebar { 
                width: 70px; 
            }
            .sidebar-header span {
                display: none;
            }
            .sidebar-header {
                padding: 14px 16px;
                justify-content: center;
                min-height: 56px;
            }
            .sidebar-logo {
                height: 32px;
            }
            .main-content { 
                margin-left: 70px; 
            }
            .sidebar-menu li a span {
                display: none;
            }
            .sidebar-menu li a {
                padding: 12px 16px;
                justify-content: center;
            }
            .sidebar-menu li a i {
                margin: 0;
                font-size: 1.1rem;
            }
            .sidebar-menu li a.active-page {
                padding-left: 16px;
                border-left: 3px solid var(--softcare-blue);
            }
            .lock-tag {
                display: none;
            }
            .app-header-bar {
                padding: 12px 16px;
                min-height: 56px;
                flex-wrap: wrap;
                gap: 8px;
            }
            .header-left .brand-title {
                font-size: 0.95rem;
            }
            .top-badge-indicator {
                font-size: 0.65rem;
                padding: 3px 10px;
            }
            .profile-trigger-zone .company-name {
                font-size: 0.75rem;
                max-width: 80px;
            }
            .company-avatar-circle {
                width: 28px;
                height: 28px;
            }
            .profile-trigger-zone {
                padding-left: 10px;
                gap: 6px;
            }
            .page-content {
                padding: 16px;
            }
            .summary-dashboard-cards { 
                grid-template-columns: 1fr 1fr; 
                gap: 12px; 
            }
            .metric-card-box {
                padding: 14px 16px;
            }
            .metric-card-box .metric-info .metric-val {
                font-size: 1.2rem;
            }
            .metric-card-box .metric-icon {
                width: 34px;
                height: 34px;
                font-size: 0.9rem;
            }
            .header-dropdown-card {
                right: 10px;
                top: 56px;
                width: 190px;
            }
        }

        @media (max-width: 576px) {
            .sidebar { 
                width: 60px; 
            }
            .main-content { 
                margin-left: 60px; 
            }
            .sidebar-header {
                padding: 12px 12px;
                min-height: 50px;
            }
            .sidebar-logo {
                height: 28px;
            }
            .sidebar-menu li a {
                padding: 10px 12px;
            }
            .sidebar-menu li a i {
                font-size: 1rem;
            }
            .app-header-bar {
                padding: 10px 12px;
                min-height: 50px;
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }
            .header-left {
                flex-wrap: wrap;
                gap: 8px;
                justify-content: center;
            }
            .header-left .brand-title {
                font-size: 0.85rem;
            }
            .top-badge-indicator {
                font-size: 0.6rem;
                padding: 2px 8px;
            }
            .header-right {
                justify-content: center;
            }
            .profile-trigger-zone .company-name {
                display: none;
            }
            .profile-trigger-zone .dropdown-arrow {
                display: none;
            }
            .profile-trigger-zone {
                padding: 3px 6px;
                background: rgba(255,255,255,0.15);
                border-left: none;
            }
            .company-avatar-circle {
                width: 26px;
                height: 26px;
            }
            .page-content {
                padding: 12px;
            }
            .summary-dashboard-cards { 
                grid-template-columns: 1fr; 
                gap: 10px; 
            }
            .metric-card-box {
                padding: 12px 14px;
            }
            .metric-card-box .metric-info .metric-val {
                font-size: 1.1rem;
            }
            .metric-card-box .metric-icon {
                width: 30px;
                height: 30px;
                font-size: 0.8rem;
            }
            .metric-card-box .metric-info h5 {
                font-size: 0.6rem;
            }
            .feedback-alert-container {
                padding: 14px 16px;
            }
            .feedback-alert-container h4 {
                font-size: 0.85rem;
            }
            .header-dropdown-card {
                right: 6px;
                top: 48px;
                width: 170px;
            }
            .dropdown-user-info h5 {
                font-size: 0.78rem;
            }
            .dropdown-menu-list li a {
                padding: 8px 14px;
                font-size: 0.78rem;
            }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php" class="active-page"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Hub</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> <span>Profile Manager</span></a></li>
        <li><a href="manage_opportunities.php"><i class="fa-solid fa-briefcase"></i> <span>Manage Opportunity</span></a></li>
        <li><a href="resubmit_requirements.php"><i class="fa-solid fa-pen"></i> <span>Fulfill Requirements</span></a></li>
        
        <?php if ($status === 'Approved'): ?>
            <li><a href="post_opportunity.php"><i class="fa-solid fa-plus-circle"></i> <span>Post Vacancy</span></a></li>
            <li><a href="review_applications.php"><i class="fa-solid fa-folder-open"></i> <span>Applications</span></a></li>
        <?php else: ?>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Unverified companies are blocked from posting jobs to secure IT students from fraud.'); return false;">
                    <i class="fa-solid fa-ban"></i> <span>Post Vacancy</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Access denied until your profile credentials clear validation checkpoints.'); return false;">
                    <i class="fa-solid fa-lock"></i> <span>Applications</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
        <?php endif; ?>
        
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> <span>Account Settings</span></a></li>
        <!-- Sign Out removed from sidebar - now only in profile dropdown -->
    </ul>
</aside>

<div class="main-content">
    <!-- TOP HEADER BAR - SAME LEVEL AS SIDEBAR HEADER -->
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-building"></i> Company Board
            </div>
            <?php if($status === 'Approved'): ?>
                <div class="top-badge-indicator" style="background: rgba(16, 185, 129, 0.25); border: 1px solid #10B981;">
                    <i class="fa-solid fa-circle-check" style="color:#10B981;"></i> Verified
                </div>
            <?php elseif($status === 'Action Required'): ?>
                <div class="top-badge-indicator" style="background: rgba(239, 68, 68, 0.25); border: 1px solid #EF4444;">
                    <i class="fa-solid fa-circle-exclamation" style="color:#EF4444;"></i> Action Needed
                </div>
            <?php else: ?>
                <div class="top-badge-indicator" style="background: rgba(245, 158, 11, 0.25); border: 1px solid #F59E0B;">
                    <i class="fa-solid fa-hourglass-start" style="color:#F59E0B;"></i> Pending Review
                </div>
            <?php endif; ?>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $company_avatar; ?>" alt="Company Logo" class="company-avatar-circle">
                <span class="company-name"><?php echo htmlspecialchars($company_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($company_name); ?></h5>
                    <p>Corporate Partner</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> Company Profile</a></li>
                    <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <!-- PAGE CONTENT -->
    <div class="page-content">
        <?php if ($status === 'Action Required'): ?>
            <div class="feedback-alert-container">
                <h4><i class="fa-solid fa-triangle-exclamation"></i> Verification Alert: Missing Requirements Detected</h4>
                <p style="margin: 10px 0 20px 0; font-weight: 600; font-size:0.9rem; color:#7F1D1D;">
                    Admin Review Team left the following rejection logs regarding your company details:
                    <span style="display:block; margin-top:8px; padding:10px; background:#FFF; border-radius:6px; color:var(--alert-red); font-family:monospace; border:1px solid #FEB2B2;">
                        <?php echo htmlspecialchars($rejection_reason); ?>
                    </span>
                </p>
                <a href="resubmit_requirements.php" class="btn-fix-now"><i class="fa-solid fa-wrench"></i> Open Correction Workspace</a>
            </div>
        <?php endif; ?>

        <div class="summary-dashboard-cards">
            <div class="metric-card-box <?php echo ($status !== 'Approved') ? 'locked-card' : ''; ?>">
                <div class="metric-info">
                    <h5>Active Placements</h5>
                    <div class="metric-val"><?php echo $active_openings; ?></div>
                </div>
                <div class="metric-icon blue">
                    <i class="fa-solid fa-briefcase"></i>
                </div>
            </div>
            <div class="metric-card-box <?php echo ($status !== 'Approved') ? 'locked-card' : ''; ?>">
                <div class="metric-info">
                    <h5>Pending Review</h5>
                    <div class="metric-val"><?php echo $total_pending_apps; ?></div>
                </div>
                <div class="metric-icon yellow">
                    <i class="fa-solid fa-hourglass-half"></i>
                </div>
            </div>
            <div class="metric-card-box <?php echo ($status !== 'Approved') ? 'locked-card' : ''; ?>">
                <div class="metric-info">
                    <h5>Approved Students</h5>
                    <div class="metric-val"><?php echo $total_approved_students; ?></div>
                </div>
                <div class="metric-icon purple">
                    <i class="fa-solid fa-user-check"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});
</script>

</body>
</html>