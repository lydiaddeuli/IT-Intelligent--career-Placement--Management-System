<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$company_id = $_SESSION['user_id'];

// Fetch company details for header
$stmt = $pdo->prepare("SELECT org_name FROM organizations WHERE org_id = ?");
$stmt->execute([$company_id]);
$company = $stmt->fetch();
$company_name = $company['org_name'] ?? 'Company';
$company_avatar = 'https://ui-avatars.com/api/?name=' . urlencode($company_name) . '&background=0091DF&color=fff&size=40';

// Fetch company verification status for sidebar
$stmt = $pdo->prepare("SELECT verification_status FROM organizations WHERE org_id = ?");
$stmt->execute([$company_id]);
$org = $stmt->fetch();
$status = $org['verification_status'] ?? 'Pending';

// Handle Accept
if (isset($_GET['accept_id'])) {
    $app_id = intval($_GET['accept_id']);

    // FIX: the UPDATE now joins to opportunities and requires
    // o.company_id = $company_id, so it can only ever touch an
    // application that belongs to THIS company's own vacancy.
    // We then check rowCount() before claiming success — previously
    // the query had no ownership check and no verification that
    // anything actually changed, so a mismatched/invalid app_id would
    // silently update 0 rows while the page still showed "accepted
    // successfully" and fired off the notification anyway, which is
    // exactly the "notification says accepted but status is still
    // Pending" symptom.
    $update = $pdo->prepare("
        UPDATE applications a
        JOIN opportunities o ON a.opportunity_id = o.opp_id
        SET a.status = 'Accepted'
        WHERE a.app_id = ? AND o.company_id = ?
    ");
    $update->execute([$app_id, $company_id]);

    if ($update->rowCount() > 0) {
        $stmt = $pdo->prepare("SELECT student_id, opportunity_id FROM applications WHERE app_id = ?");
        $stmt->execute([$app_id]);
        $app = $stmt->fetch();

        if ($app) {
            $stmt2 = $pdo->prepare("SELECT title FROM opportunities WHERE opp_id = ?");
            $stmt2->execute([$app['opportunity_id']]);
            $opp = $stmt2->fetch();

            $notif_stmt = $pdo->prepare("
                INSERT INTO student_notifications (student_id, title, message, is_read, created_at) 
                VALUES (?, ?, ?, 0, NOW())
            ");
            $title = "Application Accepted! 🎉";
            $message = "Congratulations! Your application for '{$opp['title']}' has been accepted by the company. Please confirm your acceptance to proceed.";
            $notif_stmt->execute([$app['student_id'], $title, $message]);
        }

        $_SESSION['review_success'] = "Student application accepted successfully!";
    } else {
        $_SESSION['review_error'] = "Could not accept application #$app_id — it does not belong to one of your opportunities, or it no longer exists. No status was changed and no notification was sent.";
    }

    header("Location: review_applications.php");
    exit();
}

// Handle Reject
if (isset($_GET['reject_id'])) {
    $app_id = intval($_GET['reject_id']);

    // Same ownership + rowCount fix applied here for consistency.
    $update = $pdo->prepare("
        UPDATE applications a
        JOIN opportunities o ON a.opportunity_id = o.opp_id
        SET a.status = 'Rejected'
        WHERE a.app_id = ? AND o.company_id = ?
    ");
    $update->execute([$app_id, $company_id]);

    if ($update->rowCount() > 0) {
        $stmt = $pdo->prepare("SELECT student_id, opportunity_id FROM applications WHERE app_id = ?");
        $stmt->execute([$app_id]);
        $app = $stmt->fetch();

        if ($app) {
            $stmt2 = $pdo->prepare("SELECT title FROM opportunities WHERE opp_id = ?");
            $stmt2->execute([$app['opportunity_id']]);
            $opp = $stmt2->fetch();

            $notif_stmt = $pdo->prepare("
                INSERT INTO student_notifications (student_id, title, message, is_read, created_at) 
                VALUES (?, ?, ?, 0, NOW())
            ");
            $title = "Application Update";
            $message = "We regret to inform you that your application for '{$opp['title']}' has been declined. We wish you the best in your future endeavors.";
            $notif_stmt->execute([$app['student_id'], $title, $message]);
        }

        $_SESSION['review_success'] = "Student application rejected.";
    } else {
        $_SESSION['review_error'] = "Could not reject application #$app_id — it does not belong to one of your opportunities, or it no longer exists. No status was changed and no notification was sent.";
    }

    header("Location: review_applications.php");
    exit();
}

// Fetch applicants with student profile data
$stmt = $pdo->prepare("
    SELECT a.*, u.full_name, o.title, u.email, 
           sp.cv_path, sp.transcript_path, sp.profile_pic, 
           sp.placement_type,
           sp.summary, sp.education, sp.technical_skills
    FROM applications a
    JOIN users u ON a.student_id = u.user_id
    JOIN opportunities o ON a.opportunity_id = o.opp_id
    LEFT JOIN student_profiles sp ON u.user_id = sp.student_id
    WHERE o.company_id = ? AND a.status != 'Rejected'
    ORDER BY FIELD(a.status, 'Pending', 'Accepted', 'Confirmed'), a.applied_at DESC
");
$stmt->execute([$company_id]);
$applicants = $stmt->fetchAll();

// Count statistics
$pending_count = 0;
$accepted_count = 0;

foreach ($applicants as $app) {
    // Normalize the status - handle any case variations
    $status_raw = trim($app['status'] ?? 'Pending');
    $status_normalized = strtolower($status_raw);
    
    if ($status_normalized === 'pending') {
        $pending_count++;
    } else {
        // Everything else (Accepted, Confirmed, empty, null) counts as Accepted
        $accepted_count++;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Applicants | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF; 
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;
            --mustard-yellow: #F59E0B; 
            --dark-text: #1C2D42; 
            --muted-text: #64748B;
            --white: #FFFFFF; 
            --milky-white: #F9F9FB; 
            --border-light: #E2E8F0;
            --pure-black: #000000; 
            --alert-red: #EF4444;
        }
        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }
        
        .sidebar-menu li.locked-role a { 
            color: #A0AEC0; 
            cursor: not-allowed; 
        }
        .sidebar-menu li.locked-role a i { 
            color: #CBD5E0; 
        }
        .lock-tag { 
            margin-left: auto; 
            font-size: 0.7rem; 
            background: #FEE2E2; 
            color: var(--alert-red); 
            padding: 2px 10px; 
            border-radius: 4px; 
            font-weight: 700; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }
        
        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }
        
        .top-badge-indicator { 
            display: flex; 
            align-items: center; 
            gap: 6px; 
            font-size: 0.75rem; 
            font-weight: 700; 
            background: rgba(255,255,255,0.15); 
            padding: 4px 14px; 
            border-radius: 20px; 
            border: 1px solid rgba(255,255,255,0.2);
            white-space: nowrap;
        }
        .top-badge-indicator i {
            font-size: 0.7rem;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .company-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .company-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 12px;
        }

        .page-header h2 { 
            margin: 0; 
            font-weight: 800; 
            font-size: 1.3rem; 
        }
        .page-header h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }

        .summary-dashboard-cards {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .metric-card-box {
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 10px;
            padding: 14px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
        }

        .metric-card-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.05);
        }

        .metric-card-box .metric-info h5 {
            margin: 0 0 2px 0;
            font-size: 0.65rem;
            color: var(--muted-text);
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
        }

        .metric-card-box .metric-info .metric-val {
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .metric-card-box .metric-icon {
            width: 34px;
            height: 34px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            color: var(--white);
            flex-shrink: 0;
        }

        .metric-card-box .metric-icon.pending { background: var(--mustard-yellow); }
        .metric-card-box .metric-icon.accepted { background: var(--softcare-blue); }
        .metric-card-box .metric-icon.confirmed { background: var(--aloe-green); }

        .history-table-container { 
            border: 1px solid var(--border-light); 
            border-radius: 12px; 
            overflow: hidden; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02); 
            background: var(--white);
        }
        .dashboard-list-table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        .dashboard-list-table th { 
            background: var(--milky-white); 
            padding: 12px 18px; 
            text-align: left; 
            font-size: 0.7rem; 
            text-transform: uppercase; 
            color: var(--dark-text); 
            font-weight: 700; 
            letter-spacing: 0.5px; 
        }
        .dashboard-list-table td { 
            padding: 12px 18px; 
            border-bottom: 1px solid var(--border-light); 
            color: var(--dark-text); 
            font-size: 0.88rem; 
            vertical-align: middle;
        }
        .dashboard-list-table tr:last-child td { 
            border-bottom: none; 
        }
        .dashboard-list-table tr:hover td { 
            background: var(--softcare-light-blue); 
        }
        
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 10px;
            border-radius: 16px;
            font-size: 0.68rem;
            font-weight: 700;
        }

        .status-badge.pending {
            background: #FFFBEB;
            color: #B45309;
            border: 1px solid #FCD34D;
        }

        .status-badge.accepted {
            background: #E6F4FC;
            color: var(--softcare-blue);
            border: 1px solid #BAE0F7;
        }

        .status-badge.confirmed {
            background: #DCFCE7;
            color: var(--aloe-green);
            border: 1px solid #BBF7D0;
        }

        .btn-view { 
            color: var(--softcare-blue); 
            font-weight: 600; 
            text-decoration: none; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            transition: 0.2s;
        }
        .btn-view:hover { 
            background: var(--softcare-light-blue); 
        }
        .btn-accept { 
            background: var(--aloe-green); 
            color: white; 
            padding: 3px 10px; 
            border-radius: 4px; 
            border: none; 
            cursor: pointer; 
            font-weight: 700; 
            font-size: 0.72rem; 
            transition: background 0.2s; 
            text-decoration: none; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .btn-accept:hover { 
            background: #006B36; 
        }
        .btn-reject { 
            background: var(--alert-red); 
            color: white; 
            padding: 3px 10px; 
            border-radius: 4px; 
            border: none; 
            cursor: pointer; 
            font-weight: 700; 
            font-size: 0.72rem; 
            transition: background 0.2s; 
            text-decoration: none; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .btn-reject:hover { 
            background: #DC2626; 
        }

        .action-buttons {
            display: flex;
            align-items: center;
            gap: 4px;
            flex-wrap: wrap;
        }

        .status-text {
            font-size: 0.8rem;
            font-weight: 600;
        }
        .status-text.confirmed { color: var(--aloe-green); }
        .status-text.accepted { color: var(--softcare-blue); }

        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: var(--muted-text);
        }
        .empty-state i {
            font-size: 2.5rem;
            color: var(--border-light);
            margin-bottom: 12px;
            display: block;
        }
        .empty-state h4 {
            margin: 0 0 6px 0;
            color: var(--dark-text);
            font-size: 1.1rem;
        }
        .empty-state p {
            font-size: 0.9rem;
        }

        .success-message {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        .error-message {
            background: #FEF2F2;
            color: var(--alert-red);
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #FECACA;
            margin-bottom: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        /* ===== STUDENT PROFILE MODAL ===== */
        .modal-backdrop { 
            display: none; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.5); 
            z-index: 2000; 
            justify-content: center; 
            align-items: center; 
            backdrop-filter: blur(4px);
        }
        .modal-box { 
            background: var(--white); 
            padding: 0; 
            border-radius: 12px; 
            width: 520px; 
            max-width: 95%; 
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); 
            color: var(--dark-text);
            border-top: 4px solid var(--softcare-blue);
        }
        .modal-box .modal-header {
            padding: 20px 24px 0 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-box .modal-header h3 {
            margin: 0;
            font-weight: 800;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .modal-box .modal-header .close-modal {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--muted-text);
        }
        .modal-box .modal-header .close-modal:hover {
            color: var(--alert-red);
        }

        .modal-body {
            padding: 20px 24px 24px 24px;
        }

        .student-profile-card {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px 20px;
            background: var(--milky-white);
            border-radius: 10px;
            border: 1px solid var(--border-light);
            margin-bottom: 20px;
        }

        .student-avatar-lg {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--softcare-blue);
            background: var(--white);
        }

        .student-avatar-placeholder {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: var(--softcare-light-blue);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--softcare-blue);
            font-size: 1.8rem;
            border: 3px solid var(--softcare-blue);
            flex-shrink: 0;
        }

        .student-info h4 {
            margin: 0 0 2px 0;
            font-size: 1.05rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .student-info .student-email {
            margin: 0;
            font-size: 0.85rem;
            color: var(--muted-text);
        }

        .student-info .student-type {
            display: inline-block;
            margin-top: 4px;
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
            padding: 2px 12px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 700;
        }

        .detail-section {
            margin-bottom: 16px;
        }

        .detail-section:last-child {
            margin-bottom: 0;
        }

        .detail-section .section-label {
            font-size: 0.7rem;
            font-weight: 700;
            color: var(--muted-text);
            text-transform: uppercase;
            letter-spacing: 0.4px;
            margin-bottom: 4px;
            display: block;
        }

        .detail-section .section-content {
            font-size: 0.9rem;
            color: var(--dark-text);
            line-height: 1.6;
        }

        .detail-section .section-content .skill-tag {
            display: inline-block;
            background: var(--milky-white);
            border: 1px solid var(--border-light);
            color: var(--dark-text);
            padding: 2px 12px;
            border-radius: 4px;
            font-size: 0.78rem;
            margin: 2px 4px 2px 0;
        }

        .doc-links {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .doc-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.8rem;
            transition: 0.2s;
            border: 1px solid transparent;
        }

        .doc-link:hover {
            background: var(--softcare-blue);
            color: var(--white);
            border-color: var(--softcare-blue);
        }

        .doc-link i {
            font-size: 0.85rem;
        }

        .doc-link.no-doc {
            background: #FEF2F2;
            color: var(--alert-red);
            cursor: default;
        }

        .doc-link.no-doc:hover {
            background: #FEF2F2;
            color: var(--alert-red);
        }

        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
            padding-top: 16px;
            border-top: 1px solid var(--border-light);
            flex-wrap: wrap;
        }

        .modal-actions .btn-modal {
            padding: 8px 22px;
            border: none;
            border-radius: 6px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
        }

        .modal-actions .btn-secondary {
            background: var(--border-light);
            color: var(--dark-text);
        }
        .modal-actions .btn-secondary:hover {
            background: #CBD5E0;
        }

        .modal-actions .btn-success {
            background: var(--aloe-green);
            color: white;
        }
        .modal-actions .btn-success:hover {
            background: #006B36;
        }

        .modal-actions .btn-danger {
            background: var(--alert-red);
            color: white;
        }
        .modal-actions .btn-danger:hover {
            background: #DC2626;
        }

        .modal-actions .status-msg {
            font-size: 0.85rem;
            font-weight: 600;
            padding: 8px 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .modal-actions .status-msg.confirmed { color: var(--aloe-green); }
        .modal-actions .status-msg.accepted { color: var(--softcare-blue); }

        @media (max-width: 992px) {
            .summary-dashboard-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .main-content { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active-page { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .lock-tag { display: none; }
            .app-header-bar { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .top-badge-indicator { font-size: 0.65rem; padding: 3px 10px; }
            .profile-trigger-zone .company-name { font-size: 0.75rem; max-width: 80px; }
            .company-avatar-circle { width: 28px; height: 28px; }
            .profile-trigger-zone { padding-left: 10px; gap: 6px; }
            .page-content { padding: 16px; }
            .page-header { flex-direction: column; align-items: flex-start; }
            .page-header h2 { font-size: 1.1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr 1fr; gap: 10px; }
            .metric-card-box { padding: 12px 14px; }
            .metric-card-box .metric-info .metric-val { font-size: 1.1rem; }
            .metric-card-box .metric-icon { width: 30px; height: 30px; font-size: 0.8rem; }
            .action-buttons { flex-direction: column; align-items: flex-start; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
            .modal-box { width: 95%; }
            .student-profile-card { flex-direction: column; text-align: center; }
        }

        @media (max-width: 576px) {
            .sidebar { width: 60px; }
            .main-content { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .app-header-bar { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .top-badge-indicator { font-size: 0.6rem; padding: 2px 8px; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .company-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .company-avatar-circle { width: 26px; height: 26px; }
            .page-content { padding: 12px; }
            .page-header h2 { font-size: 1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr; gap: 8px; }
            .metric-card-box { padding: 10px 12px; }
            .metric-card-box .metric-info .metric-val { font-size: 1rem; }
            .metric-card-box .metric-icon { width: 26px; height: 26px; font-size: 0.7rem; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
            .modal-box { padding: 0; }
            .modal-body { padding: 16px; }
            .modal-actions { flex-direction: column; }
            .modal-actions .btn-modal { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Hub</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> <span>Profile Manager</span></a></li>
        <li><a href="manage_opportunities.php"><i class="fa-solid fa-briefcase"></i> <span>Manage Opportunity</span></a></li>
        <li><a href="resubmit_requirements.php"><i class="fa-solid fa-pen"></i> <span>Fulfill Requirements</span></a></li>
        
        <?php if ($status === 'Approved'): ?>
            <li><a href="post_opportunity.php"><i class="fa-solid fa-plus-circle"></i> <span>Post Vacancy</span></a></li>
            <li><a href="review_applications.php" class="active-page"><i class="fa-solid fa-folder-open"></i> <span>Applications</span></a></li>
        <?php else: ?>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Unverified companies are blocked from posting jobs to secure IT students from fraud.'); return false;">
                    <i class="fa-solid fa-ban"></i> <span>Post Vacancy</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Access denied until your profile credentials clear validation checkpoints.'); return false;">
                    <i class="fa-solid fa-lock"></i> <span>Applications</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
        <?php endif; ?>
        
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> <span>Account Settings</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-folder-open"></i> Applications Management
            </div>
            <?php if($status === 'Approved'): ?>
                <div class="top-badge-indicator" style="background: rgba(16, 185, 129, 0.25); border: 1px solid #10B981;">
                    <i class="fa-solid fa-circle-check" style="color:#10B981;"></i> Verified
                </div>
            <?php elseif($status === 'Action Required'): ?>
                <div class="top-badge-indicator" style="background: rgba(239, 68, 68, 0.25); border: 1px solid #EF4444;">
                    <i class="fa-solid fa-circle-exclamation" style="color:#EF4444;"></i> Action Needed
                </div>
            <?php else: ?>
                <div class="top-badge-indicator" style="background: rgba(245, 158, 11, 0.25); border: 1px solid #F59E0B;">
                    <i class="fa-solid fa-hourglass-start" style="color:#F59E0B;"></i> Pending Review
                </div>
            <?php endif; ?>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $company_avatar; ?>" alt="Company Logo" class="company-avatar-circle">
                <span class="company-name"><?php echo htmlspecialchars($company_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($company_name); ?></h5>
                    <p>Corporate Partner</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> Company Profile</a></li>
                    <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <?php if (isset($_SESSION['review_success'])): ?>
            <div class="success-message">
                <i class="fa-solid fa-circle-check"></i> <?php echo $_SESSION['review_success']; unset($_SESSION['review_success']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['review_error'])): ?>
            <div class="error-message">
                <i class="fa-solid fa-circle-exclamation"></i> <?php echo $_SESSION['review_error']; unset($_SESSION['review_error']); ?>
            </div>
        <?php endif; ?>

        <div class="page-header">
            <h2><i class="fa-solid fa-folder-open"></i> Applications Management</h2>
        </div>

        <!-- Status Summary Cards -->
        <div class="summary-dashboard-cards">
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Pending</h5>
                    <div class="metric-val"><?php echo $pending_count; ?></div>
                </div>
                <div class="metric-icon pending">
                    <i class="fa-solid fa-clock"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Accepted</h5>
                    <div class="metric-val"><?php echo $accepted_count; ?></div>
                </div>
                <div class="metric-icon accepted">
                    <i class="fa-regular fa-circle-check"></i>
                </div>
            </div>
        </div>

        <div class="history-table-container">
            <table class="dashboard-list-table">
                <thead>
                    <tr>
                        <th><i class="fa-regular fa-user"></i> Student</th>
                        <th><i class="fa-regular fa-file-lines"></i> Position</th>
                        <th><i class="fa-regular fa-calendar"></i> Date</th>
                        <th><i class="fa-regular fa-circle"></i> Status</th>
                        <th style="text-align:right;"><i class="fa-regular fa-pen-to-square"></i> Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($applicants)): ?>
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">
                                    <i class="fa-regular fa-circle-check"></i>
                                    <h4>No Applications Yet</h4>
                                    <p>Students haven't applied to your opportunities yet. Check back later.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($applicants as $app):
                            $raw_status = strtolower(trim($app['status'] ?? 'Pending'));
                            $is_pending = ($raw_status === 'pending');
                        ?>
                            <tr>
                                <td>
                                    <div style="display:flex; align-items:center; gap:8px;">
                                        <?php if(!empty($app['profile_pic']) && file_exists('../' . $app['profile_pic'])): ?>
                                            <img src="../<?php echo htmlspecialchars($app['profile_pic']); ?>" alt="Avatar" style="width:28px; height:28px; border-radius:50%; object-fit:cover;">
                                        <?php else: ?>
                                            <div style="width:28px; height:28px; border-radius:50%; background:var(--softcare-light-blue); display:flex; align-items:center; justify-content:center; color:var(--softcare-blue); font-size:0.7rem;">
                                                <i class="fa-solid fa-user"></i>
                                            </div>
                                        <?php endif; ?>
                                        <strong><?php echo htmlspecialchars($app['full_name']); ?></strong>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($app['title']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($app['applied_at'])); ?></td>
                                <td>
                                    <?php if ($is_pending): ?>
                                        <span class="status-badge pending">Pending</span>
                                    <?php else: ?>
                                        <span class="status-badge accepted">Accepted &#10003;</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:right;">
                                    <div class="action-buttons" style="justify-content:flex-end;">
                                        <button class="btn-view" onclick="viewStudentDetails(<?php echo htmlspecialchars(json_encode($app)); ?>)">
                                            <i class="fa-solid fa-eye"></i> View
                                        </button>

                                        <?php if ($is_pending): ?>
                                            <a href="?accept_id=<?php echo $app['app_id']; ?>" class="btn-accept" onclick="return confirm('Accept this application?')">
                                                <i class="fa-regular fa-circle-check"></i> Accept
                                            </a>
                                            <a href="?reject_id=<?php echo $app['app_id']; ?>" class="btn-reject" onclick="return confirm('Reject this application?')">
                                                <i class="fa-regular fa-times-circle"></i> Reject
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Student Details Modal -->
<div class="modal-backdrop" id="studentModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa-solid fa-user-graduate" style="color:var(--softcare-blue);"></i> Student Profile</h3>
            <button class="close-modal" onclick="closeStudentModal()">&times;</button>
        </div>
        
        <div class="modal-body">
            <!-- Student Card - populated by JavaScript -->
            <div class="student-profile-card" id="studentCard">
                <div id="avatarContainer">
                    <img id="modalAvatar" src="" alt="Avatar" class="student-avatar-lg" style="display:none;">
                    <div id="modalAvatarFallback" class="student-avatar-placeholder">
                        <i class="fa-solid fa-user"></i>
                    </div>
                </div>
                <div class="student-info">
                    <h4 id="modalName">-</h4>
                    <p class="student-email" id="modalEmail">-</p>
                    <span class="student-type" id="modalPlacement">-</span>
                </div>
            </div>

            <!-- Professional Summary -->
            <div class="detail-section">
                <span class="section-label">Professional Summary</span>
                <div class="section-content" id="modalSummary">No summary provided.</div>
            </div>

            <!-- Education -->
            <div class="detail-section">
                <span class="section-label">Education</span>
                <div class="section-content" id="modalEducation" style="white-space:pre-line;">No education details provided.</div>
            </div>

            <!-- Technical Skills -->
            <div class="detail-section">
                <span class="section-label">Technical Skills</span>
                <div class="section-content" id="modalSkills">
                    <span style="color:var(--muted-text);font-size:0.85rem;">No technical skills listed.</span>
                </div>
            </div>

            <!-- Documents -->
            <div class="detail-section">
                <span class="section-label">Documents</span>
                <div class="doc-links" id="modalDocs">
                    <span style="color:var(--muted-text);font-size:0.85rem;">No documents uploaded</span>
                </div>
            </div>

            <!-- Actions -->
            <div class="modal-actions" id="modalActions">
                <button class="btn-modal btn-secondary" onclick="closeStudentModal()">
                    <i class="fa-regular fa-xmark"></i> Close
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});

function viewStudentDetails(app) {
    console.log('Viewing student:', app);
    
    // Set student info
    document.getElementById('modalName').textContent = app.full_name || '-';
    document.getElementById('modalEmail').textContent = app.email || '-';
    document.getElementById('modalPlacement').textContent = app.placement_type || 'N/A';
    
    // Avatar
    const avatarImg = document.getElementById('modalAvatar');
    const avatarFallback = document.getElementById('modalAvatarFallback');
    if (app.profile_pic && app.profile_pic !== '' && fileExists('../' + app.profile_pic)) {
        avatarImg.src = '../' + app.profile_pic;
        avatarImg.style.display = 'block';
        avatarFallback.style.display = 'none';
    } else {
        avatarImg.style.display = 'none';
        avatarFallback.style.display = 'flex';
    }
    
    // Professional Summary
    document.getElementById('modalSummary').textContent = app.summary || 'No summary provided.';
    
    // Education
    document.getElementById('modalEducation').textContent = app.education || 'No education details provided.';
    
    // Technical Skills
    const skillsContainer = document.getElementById('modalSkills');
    skillsContainer.innerHTML = '';
    if (app.technical_skills && app.technical_skills !== '') {
        const skills = app.technical_skills.split(',').map(s => s.trim()).filter(s => s !== '');
        skills.forEach(skill => {
            const tag = document.createElement('span');
            tag.className = 'skill-tag';
            tag.textContent = skill;
            skillsContainer.appendChild(tag);
        });
    } else {
        skillsContainer.innerHTML = '<span style="color:var(--muted-text);font-size:0.85rem;">No technical skills listed.</span>';
    }

    // Documents
    const docsContainer = document.getElementById('modalDocs');
    docsContainer.innerHTML = '';

    // Check CV (FIXED)
    if (app.cv_path && app.cv_path.trim() !== '') {
        const cvPath = app.cv_path;
        const link = document.createElement('a');
        link.href = cvPath;
        link.target = '_blank';
        link.className = 'doc-link';
        link.innerHTML = '<i class="fa-solid fa-file-pdf"></i> Preview / Download CV';
        docsContainer.appendChild(link);
    } else {
        const noDoc = document.createElement('span');
        noDoc.className = 'doc-link no-doc';
        noDoc.innerHTML = '<i class="fa-solid fa-circle-exclamation"></i> CV Not Found';
        docsContainer.appendChild(noDoc);
    }

    // Check Transcript
    if (app.transcript_path && app.transcript_path !== '') {
        const transcriptPath = '../' + app.transcript_path;
        if (fileExists(transcriptPath)) {
            const link = document.createElement('a');
            link.href = transcriptPath;
            link.target = '_blank';
            link.className = 'doc-link';
            link.innerHTML = '<i class="fa-solid fa-file-lines"></i> Download Transcript';
            docsContainer.appendChild(link);
        }
    }
    
    // Actions
    const actionsContainer = document.getElementById('modalActions');
    actionsContainer.innerHTML = '';
    
    // Close button
    const closeBtn = document.createElement('button');
    closeBtn.className = 'btn-modal btn-secondary';
    closeBtn.innerHTML = '<i class="fa-regular fa-xmark"></i> Close';
    closeBtn.onclick = closeStudentModal;
    actionsContainer.appendChild(closeBtn);
    
    if (app.status === 'Pending') {
        const acceptBtn = document.createElement('a');
        acceptBtn.href = '?accept_id=' + app.app_id;
        acceptBtn.className = 'btn-modal btn-success';
        acceptBtn.innerHTML = '<i class="fa-regular fa-circle-check"></i> Accept';
        acceptBtn.onclick = function(e) {
            if (!confirm('Accept this application?')) {
                e.preventDefault();
            }
        };
        actionsContainer.appendChild(acceptBtn);
        
        const rejectBtn = document.createElement('a');
        rejectBtn.href = '?reject_id=' + app.app_id;
        rejectBtn.className = 'btn-modal btn-danger';
        rejectBtn.innerHTML = '<i class="fa-regular fa-times-circle"></i> Reject';
        rejectBtn.onclick = function(e) {
            if (!confirm('Reject this application?')) {
                e.preventDefault();
            }
        };
        actionsContainer.appendChild(rejectBtn);
    } else if (app.status === 'Accepted') {
        const statusMsg = document.createElement('span');
        statusMsg.className = 'status-msg accepted';
        statusMsg.innerHTML = '<i class="fa-regular fa-clock"></i> Awaiting Student Confirmation';
        actionsContainer.appendChild(statusMsg);
    } else if (app.status === 'Confirmed') {
        const statusMsg = document.createElement('span');
        statusMsg.className = 'status-msg confirmed';
        statusMsg.innerHTML = '<i class="fa-regular fa-circle-check"></i> Student Has Confirmed ✓';
        actionsContainer.appendChild(statusMsg);
    }
    
    document.getElementById('studentModal').style.display = 'flex';
}

function fileExists(path) {
    var xhr = new XMLHttpRequest();
    xhr.open('HEAD', path, false);
    try {
        xhr.send();
        return xhr.status === 200;
    } catch(e) {
        return false;
    }
}

function closeStudentModal() {
    document.getElementById('studentModal').style.display = 'none';
}

window.onclick = function(event) {
    if (event.target.classList.contains('modal-backdrop')) {
        event.target.style.display = 'none';
    }
}
</script>
</body>
</html>