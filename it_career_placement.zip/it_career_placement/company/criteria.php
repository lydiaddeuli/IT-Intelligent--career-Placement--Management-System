<?php
session_start();
include('../includes/db_connect.php');

// Security Check: Enforce explicit Company authentication layer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$org_id = $_SESSION['user_id'];
$msg = ""; $error = "";

// Handle Configuration and Access Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_gateway_rules'])) {
        $allow_interns = isset($_POST['allow_interns']) ? 1 : 0;
        $allow_field_study = isset($_POST['allow_field_study']) ? 1 : 0;
        $qualification_rules = trim($_POST['qualification_rules']);
        $selection_limit = intval($_POST['selection_limit']);
        $application_deadline = !empty($_POST['application_deadline']) ? $_POST['application_deadline'] : null;

        $stmt = $pdo->prepare("UPDATE organizations SET allow_interns = ?, allow_field_study = ?, qualification_rules = ?, selection_limit = ?, application_deadline = ? WHERE org_id = ?");
        if ($stmt->execute([$allow_interns, $allow_field_study, $qualification_rules, $selection_limit, $application_deadline, $org_id])) {
            $msg = "Application gateway access protocols updated successfully.";
        } else {
            $error = "Failed to update gateway rules.";
        }
    } 
    unset($_POST); 
}

// Pull existing parameter state values
$currentSettings = $pdo->prepare("SELECT allow_interns, allow_field_study, qualification_rules, selection_limit, application_deadline FROM organizations WHERE org_id = ?");
$currentSettings->execute([$org_id]);
$config = $currentSettings->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Placement Criteria | Company Portal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #fdfbf7; display: flex; }
        
        .sidebar { width: 280px; background: #1A1A1B; color: #ffffff; min-height: 100vh; position: fixed; }
        .sidebar-header { padding: 40px 20px; background: #5C4033; color: #E1AD01; text-align: center; font-weight: 900; letter-spacing: 1px; font-size: 1.2rem; border-bottom: 3px solid #E1AD01; }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; }
        .sidebar-menu li a { display: flex; align-items: center; padding: 15px 30px; color: #87CEEB; text-decoration: none; transition: 0.3s; font-weight: bold; }
        .sidebar-menu li a i { margin-right: 18px; width: 24px; font-size: 1.1rem; text-align: center; }
        .sidebar-menu li a:hover { background: rgba(225, 173, 1, 0.1); color: #E1AD01; }

        .main-content { flex: 1; margin-left: 280px; box-sizing: border-box; display: flex; flex-direction: column; }
        .dashboard-header-container { padding: 40px 40px 20px 40px; }
        .dashboard-header-container h1 { margin: 0; color: #1A1A1B; font-weight: 800; font-size: 2.2rem; }
        
        .dashboard-body { padding: 20px 40px 40px 40px; box-sizing: border-box; }
        
        /* ENLARGED FULL-WIDTH CARD DESIGN */
        .settings-card { background: #fff; padding: 45px; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.03); border-top: 6px solid #5C4033; width: 100%; box-sizing: border-box; }
        .settings-card h2 { margin-top: 0; margin-bottom: 30px; font-size: 1.5rem; color: #1A1A1B; font-weight: 800; display: flex; align-items: center; gap: 12px; }
        
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px; margin-bottom: 25px; }
        .form-group { margin-bottom: 20px; }
        .form-group.full-width { grid-column: 1 / -1; }
        
        label { display: block; font-weight: 700; margin-bottom: 10px; color: #5C4033; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.5px; }
        input[type="number"], input[type="date"], textarea { 
            width: 100%; padding: 14px; border: 2px solid #f5f2eb; border-radius: 8px; box-sizing: border-box; font-size: 0.95rem; background: #faf9f5; transition: 0.3s;
        }
        input:focus, textarea:focus { border-color: #E1AD01; outline: none; background: #fff; }
        
        /* Toggle Grid Configurations */
        .toggle-container-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 30px; }
        .toggle-group { display: flex; align-items: center; justify-content: space-between; background: #faf9f5; padding: 20px; border-radius: 8px; border: 1px solid #f0eeee; }
        
        .switch { position: relative; display: inline-block; width: 50px; height: 26px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #5C4033; }
        input:checked + .slider:before { transform: translateX(24px); }
        
        .btn-submit { display: block; width: 100%; padding: 16px; background: #E1AD01; color: #1A1A1B; border: none; text-align: center; border-radius: 8px; font-weight: 800; cursor: pointer; text-transform: uppercase; letter-spacing: 0.5px; transition: 0.3s; font-size: 0.9rem; }
        .btn-submit:hover { background: #1A1A1B; color: #E1AD01; }
        
        .alert-box { padding: 15px; border-radius: 6px; font-weight: 600; margin-bottom: 25px; }
        .alert-success { background: #eef9f0; color: #2b7a43; border-left: 5px solid #2b7a43; }
        .alert-danger { background: #fdf3f2; color: #c9302c; border-left: 5px solid #c9302c; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header"><i class="fa-solid fa-building"></i> COMPANY PORTAL</div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-gauge-high"></i> Overview Hub</a></li>
        <li><a href="criteria.php" style="color: #E1AD01;"><i class="fa-solid fa-sliders"></i> Placement Criteria</a></li>
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
        <li><a href="../logout.php"><i class="fa-solid fa-power-off"></i> Logout</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="dashboard-header-container">
        <h1>Placement Access Routing</h1>
    </div>

    <div class="dashboard-body">
        <?php if($msg): ?><div class="alert-box alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert-box alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <div class="settings-card">
            <h2><i class="fa-solid fa-sliders" style="color: #5C4033;"></i> Expanded Recruitment Channel Controls</h2>
            <p style="color: #666; margin-bottom: 35px; font-size: 0.95rem;">Configure application channels, deadlocks, maximum capacities, and student verification guidelines globally below.</p>
            
            <form method="POST">
                <div class="toggle-container-grid">
                    <div class="toggle-group">
                        <div>
                            <strong style="color: #1A1A1B; display: block; font-size: 1rem; margin-bottom: 4px;">Accept Internship Tracks</strong>
                            <span style="font-size: 0.8rem; color: #777;">Toggle availability for direct internship seekers.</span>
                        </div>
                        <label class="switch">
                            <input type="checkbox" name="allow_interns" <?php echo ($config['allow_interns'] == 1) ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </div>

                    <div class="toggle-group">
                        <div>
                            <strong style="color: #1A1A1B; display: block; font-size: 1rem; margin-bottom: 4px;">Accept Field Study Tracks</strong>
                            <span style="font-size: 0.8rem; color: #777;">Allow entry applications for university tracking workflows.</span>
                        </div>
                        <label class="switch">
                            <input type="checkbox" name="allow_field_study" <?php echo ($config['allow_field_study'] == 1) ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label>Maximum Placement Seats Limit</label>
                        <input type="number" name="selection_limit" min="1" value="<?php echo htmlspecialchars($config['selection_limit'] ?? 10); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Application Close Deadline Date</label>
                        <input type="date" name="application_deadline" value="<?php echo htmlspecialchars($config['application_deadline'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-group full-width">
                    <label>Candidate Qualification Rules & Evaluation Prerequisites</label>
                    <textarea name="qualification_rules" style="height: 140px; resize: vertical;" placeholder="Specify mandatory technical stacks, minimum GPA, or preferred tracks..."><?php echo htmlspecialchars($config['qualification_rules'] ?? ''); ?></textarea>
                </div>

                <button type="submit" name="update_gateway_rules" class="btn-submit">Commit Recruitment Rules</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>