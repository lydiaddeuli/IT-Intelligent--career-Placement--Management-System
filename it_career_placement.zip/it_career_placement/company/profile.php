<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$org_id = $_SESSION['user_id'];

// Fetch company verification status for sidebar
$stmt = $pdo->prepare("SELECT verification_status FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$org = $stmt->fetch();
$status = $org['verification_status'] ?? 'Pending';

// Fetch company details from organizations table (registration data)
$stmt = $pdo->prepare("SELECT org_name, contact_email, location, industry, website, tin_number, reg_number FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$org_data = $stmt->fetch();

// Check if profile_pic column exists in company_profiles table
try {
    $check_column = $pdo->query("SHOW COLUMNS FROM company_profiles LIKE 'profile_pic'");
    if ($check_column->rowCount() == 0) {
        $pdo->exec("ALTER TABLE company_profiles ADD COLUMN profile_pic VARCHAR(255) DEFAULT NULL");
    }
} catch (PDOException $e) {
    // Table might not exist yet
}

// Check if company_profiles table exists, create if not
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'company_profiles'");
    if ($check_table->rowCount() == 0) {
        $pdo->exec("CREATE TABLE company_profiles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            name VARCHAR(255) DEFAULT NULL,
            year_established VARCHAR(10) DEFAULT NULL,
            company_size VARCHAR(100) DEFAULT NULL,
            location VARCHAR(255) DEFAULT NULL,
            contact_person VARCHAR(255) DEFAULT NULL,
            website VARCHAR(255) DEFAULT NULL,
            social_links TEXT DEFAULT NULL,
            intern_benefits TEXT DEFAULT NULL,
            about TEXT DEFAULT NULL,
            profile_pic VARCHAR(255) DEFAULT NULL,
            status VARCHAR(50) DEFAULT 'Not Started',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
    }
} catch (PDOException $e) {}

// Fetch company profile data
$stmt = $pdo->prepare("SELECT * FROM company_profiles WHERE company_id = ?");
$stmt->execute([$org_id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

$is_new_profile = ($data === false);

if ($is_new_profile) {
    $data = [
        'id' => null,
        'company_id' => $org_id,
        'name' => $org_data['org_name'] ?? '',
        'year_established' => '', 
        'company_size' => '', 
        'location' => $org_data['location'] ?? '',
        'contact_person' => '', 
        'website' => $org_data['website'] ?? '',
        'social_links' => '', 
        'intern_benefits' => '', 
        'about' => '', 
        'status' => 'Not Started',
        'profile_pic' => ''
    ];
}

// Handle Profile Update
$msg = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $year = trim($_POST['year']);
    $size = trim($_POST['size']);
    $location = trim($_POST['location']);
    $contact_person = trim($_POST['contact_person']);
    $website = trim($_POST['website']);
    $social = trim($_POST['social']);
    $intern_benefits = trim($_POST['intern_benefits']);
    $about = trim($_POST['about']);
    
    // Handle logo upload
    $profile_pic_path = $data['profile_pic'] ?? '';
    
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === 0) {
        $file = $_FILES['logo'];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_ext, $allowed)) {
            $upload_dir = '../uploads/company_logos/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $new_filename = 'company_' . $org_id . '_' . time() . '.' . $file_ext;
            $target_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                $profile_pic_path = 'uploads/company_logos/' . $new_filename;
            }
        }
    }
    
    try {
        // Check if profile exists
        $check = $pdo->prepare("SELECT company_id FROM company_profiles WHERE company_id = ?");
        $check->execute([$org_id]);
        
        if ($check->fetch()) {
            // Update existing profile
            $update = $pdo->prepare("UPDATE company_profiles SET 
                name = ?, year_established = ?, company_size = ?, location = ?, 
                contact_person = ?, website = ?, social_links = ?, 
                intern_benefits = ?, about = ?, profile_pic = ? 
                WHERE company_id = ?");
            $update->execute([$name, $year, $size, $location, $contact_person, 
                $website, $social, $intern_benefits, $about, $profile_pic_path, $org_id]);
        } else {
            // Insert new profile
            $insert = $pdo->prepare("INSERT INTO company_profiles 
                (company_id, name, year_established, company_size, location, 
                contact_person, website, social_links, intern_benefits, about, profile_pic) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $insert->execute([$org_id, $name, $year, $size, $location, $contact_person, 
                $website, $social, $intern_benefits, $about, $profile_pic_path]);
        }
        
        // Update organizations table if needed
        if (!empty($website)) {
            $update_org = $pdo->prepare("UPDATE organizations SET website = ? WHERE org_id = ?");
            $update_org->execute([$website, $org_id]);
        }
        
        $msg = "Profile updated successfully!";
        
        // Refresh data
        $stmt = $pdo->prepare("SELECT * FROM company_profiles WHERE company_id = ?");
        $stmt->execute([$org_id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$data) {
            $data = [
                'id' => null,
                'company_id' => $org_id,
                'name' => $org_data['org_name'] ?? '',
                'year_established' => '', 
                'company_size' => '', 
                'location' => $org_data['location'] ?? '',
                'contact_person' => '', 
                'website' => $org_data['website'] ?? '',
                'social_links' => '', 
                'intern_benefits' => '', 
                'about' => '', 
                'status' => 'Not Started',
                'profile_pic' => ''
            ];
        }
        
    } catch (PDOException $e) {
        $error = "Error updating profile: " . $e->getMessage();
    }
}

// Generate avatar if no profile pic
$company_avatar = !empty($data['profile_pic']) ? '../' . $data['profile_pic'] : 'https://ui-avatars.com/api/?name=' . urlencode($data['name'] ?? $org_data['org_name'] ?? 'Company') . '&background=0091DF&color=fff&size=80';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Profile Manager | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF; 
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;
            --mustard-yellow: #F59E0B; 
            --dark-text: #1C2D42; 
            --muted-text: #64748B;
            --white: #FFFFFF; 
            --milky-white: #F9F9FB; 
            --border-light: #E2E8F0;
            --pure-black: #000000; 
            --alert-red: #EF4444;
        }
        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }
        
        /* --- SIDEBAR - NO HEADER SEPARATION --- */
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }
        
        .sidebar-menu li.locked-role a { 
            color: #A0AEC0; 
            cursor: not-allowed; 
        }
        .sidebar-menu li.locked-role a i { 
            color: #CBD5E0; 
        }
        .lock-tag { 
            margin-left: auto; 
            font-size: 0.7rem; 
            background: #FEE2E2; 
            color: var(--alert-red); 
            padding: 2px 10px; 
            border-radius: 4px; 
            font-weight: 700; 
        }

        /* --- MAIN CONTENT --- */
        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }
        
        /* --- TOP HEADER BAR - SAME LEVEL AS SIDEBAR HEADER --- */
        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }
        
        .top-badge-indicator { 
            display: flex; 
            align-items: center; 
            gap: 6px; 
            font-size: 0.75rem; 
            font-weight: 700; 
            background: rgba(255,255,255,0.15); 
            padding: 4px 14px; 
            border-radius: 20px; 
            border: 1px solid rgba(255,255,255,0.2);
            white-space: nowrap;
        }
        .top-badge-indicator i {
            font-size: 0.7rem;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .company-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .company-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        /* Profile Dropdown */
        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        /* --- PAGE CONTENT --- */
        .page-content {
            padding: 30px 35px;
        }

        .card { 
            background: var(--white); 
            padding: 30px; 
            border-radius: 12px; 
            border: 1px solid var(--border-light); 
            max-width: 900px; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02); 
        }

        /* Alert Messages */
        .alert-success {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 14px 20px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-error {
            background: #FEF2F2;
            color: var(--alert-red);
            padding: 14px 20px;
            border-radius: 8px;
            border: 1px solid #FEE2E2;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card h2 { 
            margin-top: 0; 
            color: var(--dark-text); 
            font-weight: 800;
        }
        .card .status-badge { 
            display: inline-block; 
            padding: 4px 14px; 
            border-radius: 20px; 
            font-size: 0.8rem; 
            font-weight: 700; 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }

        /* Profile Header with Avatar */
        .profile-header {
            display: flex;
            align-items: center;
            gap: 24px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--border-light);
            margin-bottom: 24px;
        }

        .profile-avatar-large {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--softcare-blue);
        }

        .profile-header-info h3 {
            margin: 0 0 4px 0;
            font-size: 1.3rem;
            font-weight: 800;
        }

        .profile-header-info p {
            margin: 0;
            color: var(--muted-text);
            font-size: 0.9rem;
        }

        .profile-header-info .email-text {
            color: var(--softcare-blue);
            font-weight: 600;
        }
        
        .form-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 20px; 
        }
        .full-width { 
            grid-column: span 2; 
        }
        .form-group { 
            display: flex; 
            flex-direction: column; 
        }
        .form-group label { 
            font-size: 0.82rem; 
            font-weight: 700; 
            color: var(--dark-text); 
            margin-bottom: 4px; 
        }
        .form-group label i {
            margin-right: 6px;
            color: var(--softcare-blue);
        }
        .form-group input, 
        .form-group textarea { 
            padding: 12px; 
            border: 1px solid var(--border-light); 
            border-radius: 8px; 
            box-sizing: border-box; 
            font-family: inherit; 
            font-size: 0.95rem; 
            background: var(--milky-white); 
            transition: border-color 0.2s; 
        }
        .form-group input:focus, 
        .form-group textarea:focus { 
            outline: none; 
            border-color: var(--softcare-blue); 
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }
        .form-group textarea { 
            resize: vertical; 
            min-height: 80px; 
        }
        
        .btn-submit { 
            background: var(--softcare-blue); 
            color: white; 
            padding: 12px 30px; 
            border: none; 
            border-radius: 8px; 
            cursor: pointer; 
            font-weight: 700; 
            font-size: 1rem; 
            transition: background 0.2s; 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
            margin-top: 10px;
        }
        .btn-submit:hover { 
            background: #0077b6; 
        }

        /* Read-only fields */
        .form-group .readonly-field {
            background: #F1F5F9;
            color: var(--muted-text);
            padding: 12px;
            border: 1px solid var(--border-light);
            border-radius: 8px;
            font-weight: 600;
        }

        /* Logo upload preview */
        .logo-upload-wrapper {
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }

        .logo-upload-wrapper .logo-preview {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--border-light);
        }

        /* Mobile Responsive */
        @media (max-width: 992px) {
            .form-grid { 
                grid-template-columns: 1fr 1fr; 
            }
        }

        @media (max-width: 768px) {
            .sidebar { 
                width: 70px; 
            }
            .sidebar-header span {
                display: none;
            }
            .sidebar-header {
                padding: 14px 16px;
                justify-content: center;
                min-height: 56px;
            }
            .sidebar-logo {
                height: 32px;
            }
            .main-content { 
                margin-left: 70px; 
            }
            .sidebar-menu li a span {
                display: none;
            }
            .sidebar-menu li a {
                padding: 12px 16px;
                justify-content: center;
            }
            .sidebar-menu li a i {
                margin: 0;
                font-size: 1.1rem;
            }
            .sidebar-menu li a.active-page {
                padding-left: 16px;
                border-left: 3px solid var(--softcare-blue);
            }
            .lock-tag {
                display: none;
            }
            .app-header-bar {
                padding: 12px 16px;
                min-height: 56px;
                flex-wrap: wrap;
                gap: 8px;
            }
            .header-left .brand-title {
                font-size: 0.95rem;
            }
            .top-badge-indicator {
                font-size: 0.65rem;
                padding: 3px 10px;
            }
            .profile-trigger-zone .company-name {
                font-size: 0.75rem;
                max-width: 80px;
            }
            .company-avatar-circle {
                width: 28px;
                height: 28px;
            }
            .profile-trigger-zone {
                padding-left: 10px;
                gap: 6px;
            }
            .page-content {
                padding: 16px;
            }
            .card {
                padding: 20px;
            }
            .form-grid { 
                grid-template-columns: 1fr; 
            }
            .full-width { 
                grid-column: span 1; 
            }
            .profile-header {
                flex-direction: column;
                text-align: center;
            }
            .profile-avatar-large {
                width: 60px;
                height: 60px;
            }
            .header-dropdown-card {
                right: 10px;
                top: 56px;
                width: 190px;
            }
        }

        @media (max-width: 576px) {
            .sidebar { 
                width: 60px; 
            }
            .main-content { 
                margin-left: 60px; 
            }
            .sidebar-header {
                padding: 12px 12px;
                min-height: 50px;
            }
            .sidebar-logo {
                height: 28px;
            }
            .sidebar-menu li a {
                padding: 10px 12px;
            }
            .sidebar-menu li a i {
                font-size: 1rem;
            }
            .app-header-bar {
                padding: 10px 12px;
                min-height: 50px;
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }
            .header-left {
                flex-wrap: wrap;
                gap: 8px;
                justify-content: center;
            }
            .header-left .brand-title {
                font-size: 0.85rem;
            }
            .top-badge-indicator {
                font-size: 0.6rem;
                padding: 2px 8px;
            }
            .header-right {
                justify-content: center;
            }
            .profile-trigger-zone .company-name {
                display: none;
            }
            .profile-trigger-zone .dropdown-arrow {
                display: none;
            }
            .profile-trigger-zone {
                padding: 3px 6px;
                background: rgba(255,255,255,0.15);
                border-left: none;
            }
            .company-avatar-circle {
                width: 26px;
                height: 26px;
            }
            .page-content {
                padding: 12px;
            }
            .card {
                padding: 16px;
            }
            .profile-avatar-large {
                width: 50px;
                height: 50px;
            }
            .profile-header-info h3 {
                font-size: 1.1rem;
            }
            .btn-submit {
                width: 100%;
                justify-content: center;
            }
            .header-dropdown-card {
                right: 6px;
                top: 48px;
                width: 170px;
            }
            .dropdown-user-info h5 {
                font-size: 0.78rem;
            }
            .dropdown-menu-list li a {
                padding: 8px 14px;
                font-size: 0.78rem;
            }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Hub</span></a></li>
        <li><a href="profile.php" class="active-page"><i class="fa-solid fa-building-user"></i> <span>Profile Manager</span></a></li>
        <li><a href="manage_opportunities.php"><i class="fa-solid fa-briefcase"></i> <span>Manage Opportunity</span></a></li>
        <li><a href="resubmit_requirements.php"><i class="fa-solid fa-pen"></i> <span>Fulfill Requirements</span></a></li>
        
        <?php if ($status === 'Approved'): ?>
            <li><a href="post_opportunity.php"><i class="fa-solid fa-plus-circle"></i> <span>Post Vacancy</span></a></li>
            <li><a href="review_applications.php"><i class="fa-solid fa-folder-open"></i> <span>Applications</span></a></li>
        <?php else: ?>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Unverified companies are blocked from posting jobs to secure IT students from fraud.'); return false;">
                    <i class="fa-solid fa-ban"></i> <span>Post Vacancy</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Access denied until your profile credentials clear validation checkpoints.'); return false;">
                    <i class="fa-solid fa-lock"></i> <span>Applications</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
        <?php endif; ?>
        
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> <span>Account Settings</span></a></li>
        <!-- Sign Out removed from sidebar -->
    </ul>
</aside>

<div class="main-content">
    <!-- TOP HEADER BAR - SAME LEVEL AS SIDEBAR HEADER -->
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-building-user"></i> Profile Manager
            </div>
            <?php if($status === 'Approved'): ?>
                <div class="top-badge-indicator" style="background: rgba(16, 185, 129, 0.25); border: 1px solid #10B981;">
                    <i class="fa-solid fa-circle-check" style="color:#10B981;"></i> Verified
                </div>
            <?php elseif($status === 'Action Required'): ?>
                <div class="top-badge-indicator" style="background: rgba(239, 68, 68, 0.25); border: 1px solid #EF4444;">
                    <i class="fa-solid fa-circle-exclamation" style="color:#EF4444;"></i> Action Needed
                </div>
            <?php else: ?>
                <div class="top-badge-indicator" style="background: rgba(245, 158, 11, 0.25); border: 1px solid #F59E0B;">
                    <i class="fa-solid fa-hourglass-start" style="color:#F59E0B;"></i> Pending Review
                </div>
            <?php endif; ?>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $company_avatar; ?>" alt="Company Logo" class="company-avatar-circle">
                <span class="company-name"><?php echo htmlspecialchars($data['name'] ?? $org_data['org_name'] ?? 'Company'); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($data['name'] ?? $org_data['org_name'] ?? 'Company'); ?></h5>
                    <p>Corporate Partner</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> Company Profile</a></li>
                    <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <!-- PAGE CONTENT -->
    <div class="page-content">
        <div class="card">
            <!-- Alert Messages -->
            <?php if (!empty($msg)): ?>
                <div class="alert-success">
                    <i class="fa-solid fa-circle-check"></i> <?php echo $msg; ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($error)): ?>
                <div class="alert-error">
                    <i class="fa-solid fa-circle-exclamation"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Profile Header with Avatar -->
            <div class="profile-header">
                <img src="<?php echo $company_avatar; ?>" alt="Company Logo" class="profile-avatar-large">
                <div class="profile-header-info">
                    <h3><?php echo htmlspecialchars($data['name'] ?? $org_data['org_name'] ?? 'Company'); ?></h3>
                    <p><span class="email-text"><?php echo htmlspecialchars($org_data['contact_email'] ?? ''); ?></span></p>
                    <p><i class="fa-regular fa-location-dot"></i> <?php echo htmlspecialchars($data['location'] ?? $org_data['location'] ?? 'Not set'); ?></p>
                    <?php if (!empty($org_data['industry'])): ?>
                        <p><i class="fa-regular fa-industry"></i> <?php echo htmlspecialchars($org_data['industry']); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <h2><i class="fa-solid fa-building-user" style="color:var(--softcare-blue);"></i> Company Profile Manager</h2>
            <p style="color:var(--muted-text); margin-bottom:20px;">Status: <span class="status-badge"><?php echo htmlspecialchars($data['status'] ?? 'Not Started'); ?></span></p>

            <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-grid">
                    <!-- Read-only fields from registration -->
                    <div class="form-group">
                        <label><i class="fa-regular fa-building"></i> Company Name</label>
                        <div class="readonly-field"><?php echo htmlspecialchars($org_data['org_name'] ?? ''); ?></div>
                        <input type="hidden" name="name" value="<?php echo htmlspecialchars($org_data['org_name'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-envelope"></i> Email Address</label>
                        <div class="readonly-field"><?php echo htmlspecialchars($org_data['contact_email'] ?? ''); ?></div>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-location-dot"></i> Location</label>
                        <input type="text" name="location" value="<?php echo htmlspecialchars($data['location'] ?? $org_data['location'] ?? ''); ?>" placeholder="City, District">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-globe"></i> Official Website</label>
                        <input type="url" name="website" value="<?php echo htmlspecialchars($data['website'] ?? $org_data['website'] ?? ''); ?>" placeholder="https://www.yourcompany.com">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-calendar"></i> Year Established</label>
                        <input type="number" name="year" value="<?php echo htmlspecialchars($data['year_established'] ?? ''); ?>" placeholder="e.g., 2010">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-users"></i> Company Size</label>
                        <input type="text" name="size" value="<?php echo htmlspecialchars($data['company_size'] ?? ''); ?>" placeholder="e.g., 50-100 employees">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-user"></i> Contact Person</label>
                        <input type="text" name="contact_person" value="<?php echo htmlspecialchars($data['contact_person'] ?? ''); ?>" placeholder="Full name">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-id-card"></i> TIN Number</label>
                        <div class="readonly-field"><?php echo htmlspecialchars($org_data['tin_number'] ?? 'Not set'); ?></div>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-file-lines"></i> BRELA Registration</label>
                        <div class="readonly-field"><?php echo htmlspecialchars($org_data['reg_number'] ?? 'Not set'); ?></div>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-image"></i> Company Logo</label>
                        <div class="logo-upload-wrapper">
                            <img src="<?php echo $company_avatar; ?>" alt="Logo Preview" class="logo-preview" id="logoPreview">
                            <input type="file" name="logo" accept="image/*" onchange="previewLogo(this)" style="flex:1;">
                        </div>
                        <small style="color:var(--muted-text); margin-top:4px;">Upload JPG, PNG or GIF (max 2MB)</small>
                    </div>
                    <div class="form-group full-width">
                        <label><i class="fa-regular fa-share-nodes"></i> Social Media Links</label>
                        <input type="text" name="social" value="<?php echo htmlspecialchars($data['social_links'] ?? ''); ?>" placeholder="LinkedIn, Twitter, Facebook URLs">
                    </div>
                    <div class="form-group full-width">
                        <label><i class="fa-regular fa-gift"></i> Internship/Field Study Benefits</label>
                        <textarea name="intern_benefits" placeholder="List the benefits students will receive during placement..."><?php echo htmlspecialchars($data['intern_benefits'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group full-width">
                        <label><i class="fa-regular fa-file-lines"></i> About Company</label>
                        <textarea name="about" placeholder="Describe your company, mission, and values..."><?php echo htmlspecialchars($data['about'] ?? ''); ?></textarea>
                    </div>
                </div>
                <button type="submit" name="update_profile" class="btn-submit">
                    <i class="fa-regular fa-floppy-disk"></i> Save Profile
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});

function previewLogo(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('logoPreview').src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

</body>
</html>