<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$org_id = $_SESSION['user_id'];
$success_msg = "";
$error_msg = "";

// Fetch company details for header
$stmt = $pdo->prepare("SELECT org_name FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$company = $stmt->fetch();
$company_name = $company['org_name'] ?? 'Company';
$company_avatar = 'https://ui-avatars.com/api/?name=' . urlencode($company_name) . '&background=0091DF&color=fff&size=40';

// Fetch current details from database
$stmt = $pdo->prepare("SELECT * FROM organizations WHERE org_id = ?");
$stmt->execute([$org_id]);
$org = $stmt->fetch();

if (!$org) {
    die("Corporate organization profile not found.");
}

$status = $org['verification_status'] ?? 'Pending';
$rejection_reason = $org['rejection_reason'] ?? '';

// Form processing block
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resubmit_compliance'])) {
    $tin_number = trim($_POST['tin_number']);
    $reg_number = trim($_POST['reg_number']);
    $company_website = trim($_POST['company_website']);
    $payment_description = trim($_POST['payment_description']);
    
    $dest_path = $org['verification_documents']; 

    if (isset($_FILES['compliance_doc']) && $_FILES['compliance_doc']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['compliance_doc']['tmp_name'];
        $file_name = $_FILES['compliance_doc']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        if (in_array($file_ext, $allowed)) {
            $upload_dir = '../uploads/compliance_docs/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $new_name = 'org_' . $org_id . '_fix_' . time() . '.' . $file_ext;
            $dest_path = 'uploads/compliance_docs/' . $new_name;
            move_uploaded_file($file_tmp, '../' . $dest_path);
        } else {
            $error_msg = "Validation Error: System only supports PDF, PNG, or JPEG formats.";
        }
    }

    if (empty($error_msg)) {
        try {
            $update = $pdo->prepare("UPDATE organizations SET 
                tin_number = ?, 
                reg_number = ?, 
                company_website = ?, 
                payment_description = ?, 
                verification_documents = ?, 
                verification_status = 'Pending' 
                WHERE org_id = ?");
            
            $update->execute([$tin_number, $reg_number, $company_website, $payment_description, $dest_path, $org_id]);
            
            $success_msg = "Corrections successfully routed! Your changes have been sent back to the administration team for review.";
            $status = 'Pending';
            $rejection_reason = ''; 
        } catch (PDOException $e) {
            $error_msg = "Execution Failure: " . $e->getMessage();
        }
    }
}

// Professional Parsing logic to separate Checked Items from Custom Admin Notes
$parsed_items = [];
$parsed_notes = "";

if (!empty($rejection_reason)) {
    if (strpos($rejection_reason, 'Administrative Notes:') !== false) {
        $parts = explode('. Administrative Notes:', $rejection_reason);
        $items_part = str_replace('Missing/Incorrect Items: ', '', $parts[0]);
        $parsed_notes = trim($parts[1]);
        $parsed_items = array_map('trim', explode(',', $items_part));
    } else {
        $items_part = str_replace('Missing/Incorrect Items: ', '', $rejection_reason);
        $parsed_items = array_map('trim', explode(',', $items_part));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fulfill Requirements | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF; 
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;
            --mustard-yellow: #F59E0B; 
            --dark-text: #1C2D42; 
            --muted-text: #64748B;
            --white: #FFFFFF; 
            --milky-white: #F9F9FB; 
            --border-light: #E2E8F0;
            --pure-black: #000000; 
            --alert-red: #EF4444;
        }
        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }
        
        .sidebar-menu li.locked-role a { 
            color: #A0AEC0; 
            cursor: not-allowed; 
        }
        .sidebar-menu li.locked-role a i { 
            color: #CBD5E0; 
        }
        .lock-tag { 
            margin-left: auto; 
            font-size: 0.7rem; 
            background: #FEE2E2; 
            color: var(--alert-red); 
            padding: 2px 10px; 
            border-radius: 4px; 
            font-weight: 700; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }
        
        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }
        
        .top-badge-indicator { 
            display: flex; 
            align-items: center; 
            gap: 6px; 
            font-size: 0.75rem; 
            font-weight: 700; 
            background: rgba(255,255,255,0.15); 
            padding: 4px 14px; 
            border-radius: 20px; 
            border: 1px solid rgba(255,255,255,0.2);
            white-space: nowrap;
        }
        .top-badge-indicator i {
            font-size: 0.7rem;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .company-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .company-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .professional-alert-box { 
            background: var(--white); 
            border: 1px solid var(--border-light); 
            border-left: 5px solid var(--alert-red); 
            border-radius: 12px; 
            padding: 22px 25px; 
            margin-bottom: 30px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.02); 
        }
        .alert-title-area { 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            margin-bottom: 12px; 
            border-bottom: 1px solid var(--border-light); 
            padding-bottom: 10px; 
        }
        .alert-title-area h3 { 
            margin: 0; 
            color: #9B1C1C; 
            font-weight: 800; 
            font-size: 1.05rem; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
        }
        
        .flagged-items-wrapper { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 8px; 
            margin: 10px 0; 
        }
        .flag-badge { 
            background: #FFF5F5; 
            border: 1px solid #FEB2B2; 
            color: #C53030; 
            padding: 4px 12px; 
            border-radius: 6px; 
            font-size: 0.82rem; 
            font-weight: 700; 
            display: inline-flex; 
            align-items: center; 
            gap: 6px; 
        }
        
        .admin-note-blockquote { 
            background: #F8FAFC; 
            border-left: 4px solid var(--muted-text); 
            padding: 12px 16px; 
            border-radius: 0 8px 8px 0; 
            font-size: 0.9rem; 
            font-weight: 600; 
            color: #334155; 
            margin: 12px 0 0 0; 
            font-style: italic; 
        }

        .container-box { 
            background: var(--white); 
            border-radius: 12px; 
            padding: 30px 35px; 
            border: 1px solid var(--border-light); 
            box-shadow: 0 4px 20px rgba(0,0,0,0.01); 
            max-width: 800px;
        }
        .container-box h2 { 
            margin-top: 0; 
            font-weight: 800; 
            font-size: 1.25rem; 
            display: flex; 
            align-items: center; 
            gap: 8px; 
        }
        .container-box .subtitle { 
            color: var(--muted-text); 
            margin-bottom: 20px; 
            font-weight: 500; 
            font-size: 0.88rem; 
        }
        
        .grid-form { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 18px; 
            margin-bottom: 18px; 
        }
        .field-block { 
            display: flex; 
            flex-direction: column; 
            gap: 5px; 
        }
        .field-block label { 
            font-weight: 700; 
            font-size: 0.8rem; 
            color: var(--dark-text); 
        }
        .field-block label i { 
            margin-right: 6px; 
            color: var(--softcare-blue); 
        }
        .input-box, .text-area { 
            border: 1px solid var(--border-light); 
            padding: 10px 12px; 
            border-radius: 8px; 
            font-family: inherit; 
            font-size: 0.9rem; 
            background: var(--milky-white); 
            outline: none; 
            transition: 0.2s; 
            width: 100%; 
            box-sizing: border-box; 
        }
        .input-box:focus, .text-area:focus { 
            border-color: var(--softcare-blue); 
            background: white; 
            box-shadow: 0 0 0 4px var(--softcare-light-blue); 
        }
        .text-area { 
            min-height: 80px; 
            resize: vertical; 
        }
        
        .banner { 
            padding: 12px 18px; 
            border-radius: 8px; 
            font-weight: 700; 
            margin-bottom: 18px; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 0.9rem;
        }
        .banner.success { 
            background: #DCFCE7; 
            color: var(--aloe-green); 
            border: 1px solid #BBF7D0; 
        }
        .banner.error { 
            background: #FEF2F2; 
            color: var(--alert-red); 
            border: 1px solid #FEE2E2; 
        }
        .banner.pending { 
            background: #FFFBEB; 
            color: #B45309; 
            border-left: 5px solid var(--mustard-yellow); 
            margin-bottom: 25px; 
        }
        
        .btn-send { 
            background: var(--softcare-blue); 
            color: white; 
            padding: 12px 28px; 
            border: none; 
            border-radius: 8px; 
            font-weight: 700; 
            cursor: pointer; 
            font-size: 0.9rem; 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
            transition: 0.2s; 
            width: 100%;
            justify-content: center;
        }
        .btn-send:hover { 
            background: #0077B8; 
        }
        
        .preview-overlay { 
            display: none; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.5); 
            z-index: 2000; 
            justify-content: center; 
            align-items: center; 
            backdrop-filter: blur(4px); 
        }
        .preview-box { 
            background: var(--white); 
            width: 80%; 
            height: 85%; 
            border-radius: 12px; 
            display: flex; 
            flex-direction: column; 
            overflow: hidden; 
            box-shadow: 0 12px 30px rgba(0,0,0,0.2); 
        }
        .preview-header { 
            padding: 15px 25px; 
            background: var(--milky-white); 
            border-bottom: 1px solid var(--border-light); 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .preview-header h3 { 
            margin: 0; 
            font-weight: 800; 
            font-size: 1.1rem; 
            color: var(--dark-text); 
        }
        .preview-body { 
            flex: 1; 
            background: #525659; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
        }
        .preview-frame { 
            width: 100%; 
            height: 100%; 
            border: none; 
        }
        .btn-close-preview { 
            background: var(--border-light); 
            border: none; 
            padding: 8px 16px; 
            font-weight: 700; 
            border-radius: 6px; 
            cursor: pointer; 
            transition: 0.2s; 
        }
        .btn-close-preview:hover { 
            background: #CBD5E0; 
        }

        @media (max-width: 768px) {
            .sidebar { 
                width: 70px; 
            }
            .sidebar-header span {
                display: none;
            }
            .sidebar-header {
                padding: 14px 16px;
                justify-content: center;
                min-height: 56px;
            }
            .sidebar-logo {
                height: 32px;
            }
            .main-content { 
                margin-left: 70px; 
            }
            .sidebar-menu li a span {
                display: none;
            }
            .sidebar-menu li a {
                padding: 12px 16px;
                justify-content: center;
            }
            .sidebar-menu li a i {
                margin: 0;
                font-size: 1.1rem;
            }
            .sidebar-menu li a.active-page {
                padding-left: 16px;
                border-left: 3px solid var(--softcare-blue);
            }
            .lock-tag {
                display: none;
            }
            .app-header-bar {
                padding: 12px 16px;
                min-height: 56px;
                flex-wrap: wrap;
                gap: 8px;
            }
            .header-left .brand-title {
                font-size: 0.95rem;
            }
            .top-badge-indicator {
                font-size: 0.65rem;
                padding: 3px 10px;
            }
            .profile-trigger-zone .company-name {
                font-size: 0.75rem;
                max-width: 80px;
            }
            .company-avatar-circle {
                width: 28px;
                height: 28px;
            }
            .profile-trigger-zone {
                padding-left: 10px;
                gap: 6px;
            }
            .page-content {
                padding: 16px;
            }
            .container-box {
                padding: 20px;
            }
            .grid-form { 
                grid-template-columns: 1fr; 
            }
            .header-dropdown-card {
                right: 10px;
                top: 56px;
                width: 190px;
            }
            .professional-alert-box {
                padding: 16px 18px;
            }
            .preview-box {
                width: 95%;
                height: 90%;
            }
        }

        @media (max-width: 576px) {
            .sidebar { 
                width: 60px; 
            }
            .main-content { 
                margin-left: 60px; 
            }
            .sidebar-header {
                padding: 12px 12px;
                min-height: 50px;
            }
            .sidebar-logo {
                height: 28px;
            }
            .sidebar-menu li a {
                padding: 10px 12px;
            }
            .sidebar-menu li a i {
                font-size: 1rem;
            }
            .app-header-bar {
                padding: 10px 12px;
                min-height: 50px;
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }
            .header-left {
                flex-wrap: wrap;
                gap: 8px;
                justify-content: center;
            }
            .header-left .brand-title {
                font-size: 0.85rem;
            }
            .top-badge-indicator {
                font-size: 0.6rem;
                padding: 2px 8px;
            }
            .header-right {
                justify-content: center;
            }
            .profile-trigger-zone .company-name {
                display: none;
            }
            .profile-trigger-zone .dropdown-arrow {
                display: none;
            }
            .profile-trigger-zone {
                padding: 3px 6px;
                background: rgba(255,255,255,0.15);
                border-left: none;
            }
            .company-avatar-circle {
                width: 26px;
                height: 26px;
            }
            .page-content {
                padding: 12px;
            }
            .container-box {
                padding: 16px;
            }
            .container-box h2 {
                font-size: 1.05rem;
            }
            .header-dropdown-card {
                right: 6px;
                top: 48px;
                width: 170px;
            }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Hub</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> <span>Profile Manager</span></a></li>
        <li><a href="manage_opportunities.php"><i class="fa-solid fa-briefcase"></i> <span>Manage Opportunity</span></a></li>
        <li><a href="resubmit_requirements.php" class="active-page"><i class="fa-solid fa-pen"></i> <span>Fulfill Requirements</span></a></li>
        
        <?php if ($status === 'Approved'): ?>
            <li><a href="post_opportunity.php"><i class="fa-solid fa-plus-circle"></i> <span>Post Vacancy</span></a></li>
            <li><a href="review_applications.php"><i class="fa-solid fa-folder-open"></i> <span>Applications</span></a></li>
        <?php else: ?>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Unverified companies are blocked from posting jobs to secure IT students from fraud.'); return false;">
                    <i class="fa-solid fa-ban"></i> <span>Post Vacancy</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Access denied until your profile credentials clear validation checkpoints.'); return false;">
                    <i class="fa-solid fa-lock"></i> <span>Applications</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
        <?php endif; ?>
        
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> <span>Account Settings</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-pen-to-square"></i> Fulfill Requirements
            </div>
            <?php if($status === 'Approved'): ?>
                <div class="top-badge-indicator" style="background: rgba(16, 185, 129, 0.25); border: 1px solid #10B981;">
                    <i class="fa-solid fa-circle-check" style="color:#10B981;"></i> Verified
                </div>
            <?php elseif($status === 'Action Required' || $status === 'Rejected'): ?>
                <div class="top-badge-indicator" style="background: rgba(239, 68, 68, 0.25); border: 1px solid #EF4444;">
                    <i class="fa-solid fa-circle-exclamation" style="color:#EF4444;"></i> Action Needed
                </div>
            <?php else: ?>
                <div class="top-badge-indicator" style="background: rgba(245, 158, 11, 0.25); border: 1px solid #F59E0B;">
                    <i class="fa-solid fa-hourglass-start" style="color:#F59E0B;"></i> Pending Review
                </div>
            <?php endif; ?>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $company_avatar; ?>" alt="Company Logo" class="company-avatar-circle">
                <span class="company-name"><?php echo htmlspecialchars($company_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($company_name); ?></h5>
                    <p>Corporate Partner</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> Company Profile</a></li>
                    <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <?php if(!empty($success_msg)): ?>
            <div class="banner success"><i class="fa-solid fa-circle-check"></i> <?php echo $success_msg; ?></div>
        <?php endif; ?>
        <?php if(!empty($error_msg)): ?>
            <div class="banner error"><i class="fa-solid fa-circle-exclamation"></i> <?php echo $error_msg; ?></div>
        <?php endif; ?>

        <?php if(!empty($rejection_reason)): ?>
            <div class="professional-alert-box">
                <div class="alert-title-area">
                    <h3><i class="fa-solid fa-triangle-exclamation" style="color: var(--alert-red);"></i> Account Verification Audit Review</h3>
                    <span style="background: rgba(239, 64, 64, 0.1); color: var(--alert-red); padding: 4px 12px; border-radius: 50px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase;">
                        Action Required
                    </span>
                </div>
                
                <p style="margin: 0 0 8px 0; color: var(--muted-text); font-size: 0.88rem; font-weight: 600;">
                    The compliance team has flagged specific anomalies with your registration assets. Please resolve the specified badges below:
                </p>

                <div class="flagged-items-wrapper">
                    <?php if(!empty($parsed_items)): ?>
                        <?php foreach($parsed_items as $item): if(empty($item)) continue; ?>
                            <span class="flag-badge"><i class="fa-solid fa-circle-xmark"></i> <?php echo htmlspecialchars($item); ?></span>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <span class="flag-badge"><i class="fa-solid fa-circle-xmark"></i> General Registration Discrepancy</span>
                    <?php endif; ?>
                </div>

                <?php if(!empty($parsed_notes)): ?>
                    <div class="admin-note-blockquote">
                        <strong style="color: var(--dark-text); font-style: normal; display: block; margin-bottom: 4px; font-size: 0.82rem; text-transform: uppercase; letter-spacing: 0.5px;">
                            <i class="fa-solid fa-comment-dots"></i> Direct Admin Inspector Note:
                        </strong>
                        "<?php echo htmlspecialchars($parsed_notes); ?>"
                    </div>
                <?php endif; ?>
            </div>
        <?php elseif($status === 'Pending'): ?>
            <div class="banner pending">
                <i class="fa-solid fa-clock-rotate-left fa-spin"></i>
                <div>
                    <strong>Verification Profile Under Review:</strong> Your modified data bundle was successfully updated. Form fields remain locked while our operations group checks changes.
                </div>
            </div>
        <?php endif; ?>

        <div class="container-box">
            <h2><i class="fa-solid fa-pen-to-square" style="color: var(--softcare-blue);"></i> Resubmission Setup Desk</h2>
            <p class="subtitle">Please recheck inputs, append adjustments referenced by audit metrics logs, and commit changes for re-validation.</p>

            <form method="POST" enctype="multipart/form-data">
                <div class="grid-form">
                    <div class="field-block">
                        <label><i class="fa-solid fa-hashtag"></i> Tax Identification Number (TIN)</label>
                        <input type="text" name="tin_number" class="input-box" value="<?php echo htmlspecialchars($org['tin_number'] ?? ''); ?>" required>
                    </div>
                    <div class="field-block">
                        <label><i class="fa-solid fa-building"></i> BRELA Registration Number</label>
                        <input type="text" name="reg_number" class="input-box" value="<?php echo htmlspecialchars($org['reg_number'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="field-block" style="margin-bottom:18px;">
                    <label><i class="fa-solid fa-globe"></i> Official Corporate Website Domain</label>
                    <input type="url" name="company_website" class="input-box" value="<?php echo htmlspecialchars($org['company_website'] ?? ''); ?>" placeholder="https://company.co.tz">
                </div>

                <div class="field-block" style="margin-bottom:18px;">
                    <label><i class="fa-solid fa-money-bill"></i> Stipend / Student Payment Structure Matrix Details</label>
                    <textarea name="payment_description" class="text-area" required><?php echo htmlspecialchars($org['payment_description'] ?? ''); ?></textarea>
                </div>

                <div class="field-block" style="margin-bottom:25px;">
                    <label><i class="fa-solid fa-file-upload"></i> Upload Missing/Corrected Certificates Bundle (PDF, PNG, or JPEG)</label>
                    <input type="file" name="compliance_doc" class="input-box" style="background:transparent; padding:5px 0;">
                    <?php if(!empty($org['verification_documents'])): ?>
                        <small style="margin-top:6px; font-weight:600; color: var(--muted-text); display: block; font-size:0.8rem;">
                            <i class="fa-solid fa-paperclip"></i> Currently Uploaded Archive: 
                            <button type="button" onclick="previewDocument('../<?php echo htmlspecialchars($org['verification_documents']); ?>')" style="background: none; border: none; color: var(--softcare-blue); font-weight: 700; cursor: pointer; padding: 0; font-size: 0.8rem; text-decoration: underline;">
                                Review Stored Certificates Bundle
                            </button>
                        </small>
                    <?php endif; ?>
                </div>

                <button type="submit" name="resubmit_compliance" class="btn-send">
                    <i class="fa-solid fa-paper-plane"></i> Apply System Updates & Resend to Admin
                </button>
            </form>
        </div>
    </div>
</div>

<div class="preview-overlay" id="docPreviewModal">
    <div class="preview-box">
        <div class="preview-header">
            <h3><i class="fa-solid fa-shield-halved" style="color:var(--softcare-blue);"></i> Internal Compliance Document Viewer</h3>
            <button type="button" onclick="closePreview()" class="btn-close-preview">
                <i class="fa-solid fa-xmark"></i> Close Viewer
            </button>
        </div>
        <div class="preview-body">
            <iframe id="previewIframe" class="preview-frame" src=""></iframe>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});

function previewDocument(fileUrl) {
    document.getElementById('previewIframe').src = fileUrl;
    document.getElementById('docPreviewModal').style.display = 'flex';
}

function closePreview() {
    document.getElementById('docPreviewModal').style.display = 'none';
    document.getElementById('previewIframe').src = '';
}
</script>
</body>
</html>