<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: ../login.php");
    exit();
}

$company_id = $_SESSION['user_id'];
$opp_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($opp_id <= 0) {
    header("Location: manage_opportunities.php");
    exit();
}

// Fetch company details for header
$stmt = $pdo->prepare("SELECT org_name FROM organizations WHERE org_id = ?");
$stmt->execute([$company_id]);
$company = $stmt->fetch();
$company_name = $company['org_name'] ?? 'Company';
$company_avatar = 'https://ui-avatars.com/api/?name=' . urlencode($company_name) . '&background=0091DF&color=fff&size=40';

// Fetch company verification status for sidebar
$stmt = $pdo->prepare("SELECT verification_status FROM organizations WHERE org_id = ?");
$stmt->execute([$company_id]);
$org = $stmt->fetch();
$status = $org['verification_status'] ?? 'Pending';

// Fetch opportunity details
$stmt = $pdo->prepare("SELECT * FROM opportunities WHERE opp_id = ? AND company_id = ?");
$stmt->execute([$opp_id, $company_id]);
$opportunity = $stmt->fetch();

if (!$opportunity) {
    header("Location: manage_opportunities.php");
    exit();
}

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $type = $_POST['type'];
    $closing_date = $_POST['closing_date'];
    $slots = intval($_POST['slots']);
    $required_gpa = floatval($_POST['required_gpa']);
    $responsibilities = trim($_POST['core_responsibilities']);
    $qualifications = trim($_POST['qualifications']);
    $status_action = $_POST['status_action'] ?? 'draft';

    if (empty($title) || empty($closing_date) || empty($responsibilities) || empty($qualifications)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            $sql = "UPDATE opportunities SET 
                    title = ?, type = ?, closing_date = ?, slots = ?, 
                    required_gpa = ?, core_responsibilities = ?, requirements = ? 
                    WHERE opp_id = ? AND company_id = ?";
            $stmt = $pdo->prepare($sql);
            
            if($stmt->execute([$title, $type, $closing_date, $slots, $required_gpa, 
                              $responsibilities, $qualifications, $opp_id, $company_id])) {
                if ($status_action === 'publish') {
                    $publish = $pdo->prepare("UPDATE opportunities SET status = 'published' WHERE opp_id = ?");
                    $publish->execute([$opp_id]);
                    $_SESSION['opportunity_success'] = "Opportunity updated and published!";
                } else {
                    $_SESSION['opportunity_success'] = "Opportunity updated successfully!";
                }
                header("Location: manage_opportunities.php");
                exit();
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Opportunity | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }
        
        .sidebar-menu li.locked-role a { 
            color: #A0AEC0; 
            cursor: not-allowed; 
        }
        .sidebar-menu li.locked-role a i { 
            color: #CBD5E0; 
        }
        .lock-tag { 
            margin-left: auto; 
            font-size: 0.7rem; 
            background: #FEE2E2; 
            color: var(--alert-red); 
            padding: 2px 10px; 
            border-radius: 4px; 
            font-weight: 700; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }
        
        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }
        
        .top-badge-indicator { 
            display: flex; 
            align-items: center; 
            gap: 6px; 
            font-size: 0.75rem; 
            font-weight: 700; 
            background: rgba(255,255,255,0.15); 
            padding: 4px 14px; 
            border-radius: 20px; 
            border: 1px solid rgba(255,255,255,0.2);
            white-space: nowrap;
        }
        .top-badge-indicator i {
            font-size: 0.7rem;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .company-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .company-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.85rem;
            margin-bottom: 18px;
            background: var(--milky-white);
            color: var(--dark-text);
            border: 1px solid var(--border-light);
            transition: 0.2s;
        }
        .btn-back:hover {
            background: var(--border-light);
        }

        .form-card {
            background: var(--white);
            padding: 35px;
            border-radius: 12px;
            border: 1px solid var(--border-light);
            max-width: 800px;
            width: 100%;
            box-sizing: border-box;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
        }
        .form-card h2 { 
            margin: 0 0 4px 0; 
            color: var(--dark-text); 
            font-weight: 800; 
            font-size: 1.3rem; 
        }
        .form-card h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }
        .form-card p.subtitle { 
            color: var(--muted-text); 
            font-size: 0.88rem; 
            margin: 0 0 25px 0; 
            font-weight: 500; 
        }
        
        label { 
            display: block; 
            font-weight: 700; 
            margin-bottom: 5px; 
            color: var(--dark-text); 
            font-size: 0.78rem; 
            text-transform: uppercase; 
            letter-spacing: 0.4px; 
        }
        label i {
            margin-right: 6px;
            color: var(--softcare-blue);
        }
        
        input[type="text"], input[type="date"], input[type="number"], select, textarea { 
            width: 100%; 
            padding: 10px 14px; 
            border: 1px solid var(--border-light); 
            border-radius: 8px; 
            margin-bottom: 18px; 
            box-sizing: border-box; 
            font-size: 0.92rem; 
            background: var(--milky-white); 
            color: var(--dark-text);
            transition: all 0.2s ease-in-out;
            font-family: inherit;
        }
        input:focus, select:focus, textarea:focus { 
            border-color: var(--softcare-blue); 
            outline: none; 
            background: var(--white); 
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1); 
        }

        .form-row-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 18px; 
        }
        
        textarea { 
            resize: vertical; 
            min-height: 100px; 
            line-height: 1.5; 
        }
        
        .btn-submit { 
            background: var(--softcare-blue); 
            color: var(--white); 
            border: none; 
            padding: 13px; 
            width: 100%; 
            border-radius: 8px; 
            font-weight: 700; 
            cursor: pointer; 
            text-transform: uppercase; 
            letter-spacing: 0.5px; 
            transition: background 0.2s; 
            font-size: 0.88rem; 
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex: 1;
        }
        .btn-submit:hover { 
            background: #0077b6; 
        }
        .btn-submit.btn-success {
            background: var(--aloe-green);
        }
        .btn-submit.btn-success:hover {
            background: #006B36;
        }
        
        .alert-box { 
            padding: 12px 16px; 
            border-radius: 8px; 
            font-weight: 600; 
            margin-bottom: 20px; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 0.88rem;
        }
        .alert-box.danger {
            background: #FEF2F2; 
            color: var(--alert-red); 
            border: 1px solid #FEE2E2; 
        }

        .button-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 5px;
        }
        .button-group .btn-submit {
            flex: 1;
            min-width: 140px;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar { 
                width: 70px; 
            }
            .sidebar-header span {
                display: none;
            }
            .sidebar-header {
                padding: 14px 16px;
                justify-content: center;
                min-height: 56px;
            }
            .sidebar-logo {
                height: 32px;
            }
            .main-content { 
                margin-left: 70px; 
            }
            .sidebar-menu li a span {
                display: none;
            }
            .sidebar-menu li a {
                padding: 12px 16px;
                justify-content: center;
            }
            .sidebar-menu li a i {
                margin: 0;
                font-size: 1.1rem;
            }
            .sidebar-menu li a.active-page {
                padding-left: 16px;
                border-left: 3px solid var(--softcare-blue);
            }
            .lock-tag {
                display: none;
            }
            .app-header-bar {
                padding: 12px 16px;
                min-height: 56px;
                flex-wrap: wrap;
                gap: 8px;
            }
            .header-left .brand-title {
                font-size: 0.95rem;
            }
            .top-badge-indicator {
                font-size: 0.65rem;
                padding: 3px 10px;
            }
            .profile-trigger-zone .company-name {
                font-size: 0.75rem;
                max-width: 80px;
            }
            .company-avatar-circle {
                width: 28px;
                height: 28px;
            }
            .profile-trigger-zone {
                padding-left: 10px;
                gap: 6px;
            }
            .page-content {
                padding: 16px;
            }
            .form-card {
                padding: 20px;
            }
            .form-row-grid { 
                grid-template-columns: 1fr; 
                gap: 0;
            }
            .button-group {
                flex-direction: column;
            }
            .button-group .btn-submit {
                width: 100%;
            }
            .header-dropdown-card {
                right: 10px;
                top: 56px;
                width: 190px;
            }
        }

        @media (max-width: 576px) {
            .sidebar { 
                width: 60px; 
            }
            .main-content { 
                margin-left: 60px; 
            }
            .sidebar-header {
                padding: 12px 12px;
                min-height: 50px;
            }
            .sidebar-logo {
                height: 28px;
            }
            .sidebar-menu li a {
                padding: 10px 12px;
            }
            .sidebar-menu li a i {
                font-size: 1rem;
            }
            .app-header-bar {
                padding: 10px 12px;
                min-height: 50px;
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }
            .header-left {
                flex-wrap: wrap;
                gap: 8px;
                justify-content: center;
            }
            .header-left .brand-title {
                font-size: 0.85rem;
            }
            .top-badge-indicator {
                font-size: 0.6rem;
                padding: 2px 8px;
            }
            .header-right {
                justify-content: center;
            }
            .profile-trigger-zone .company-name {
                display: none;
            }
            .profile-trigger-zone .dropdown-arrow {
                display: none;
            }
            .profile-trigger-zone {
                padding: 3px 6px;
                background: rgba(255,255,255,0.15);
                border-left: none;
            }
            .company-avatar-circle {
                width: 26px;
                height: 26px;
            }
            .page-content {
                padding: 12px;
            }
            .form-card {
                padding: 16px;
            }
            .form-card h2 {
                font-size: 1.1rem;
            }
            .btn-submit {
                font-size: 0.82rem;
                padding: 12px;
            }
            .header-dropdown-card {
                right: 6px;
                top: 48px;
                width: 170px;
            }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Hub</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> <span>Profile Manager</span></a></li>
        <li><a href="manage_opportunities.php" class="active-page"><i class="fa-solid fa-briefcase"></i> <span>Manage Opportunity</span></a></li>
        <li><a href="resubmit_requirements.php"><i class="fa-solid fa-pen"></i> <span>Fulfill Requirements</span></a></li>
        
        <?php if ($status === 'Approved'): ?>
            <li><a href="post_opportunity.php"><i class="fa-solid fa-plus-circle"></i> <span>Post Vacancy</span></a></li>
            <li><a href="review_applications.php"><i class="fa-solid fa-folder-open"></i> <span>Applications</span></a></li>
        <?php else: ?>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Unverified companies are blocked from posting jobs to secure IT students from fraud.'); return false;">
                    <i class="fa-solid fa-ban"></i> <span>Post Vacancy</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
            <li class="locked-role">
                <a href="#" onclick="alert('Security Guard Check: Access denied until your profile credentials clear validation checkpoints.'); return false;">
                    <i class="fa-solid fa-lock"></i> <span>Applications</span> <span class="lock-tag">Locked</span>
                </a>
            </li>
        <?php endif; ?>
        
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> <span>Account Settings</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-pen-to-square"></i> Edit Opportunity
            </div>
            <?php if($status === 'Approved'): ?>
                <div class="top-badge-indicator" style="background: rgba(16, 185, 129, 0.25); border: 1px solid #10B981;">
                    <i class="fa-solid fa-circle-check" style="color:#10B981;"></i> Verified
                </div>
            <?php elseif($status === 'Action Required'): ?>
                <div class="top-badge-indicator" style="background: rgba(239, 68, 68, 0.25); border: 1px solid #EF4444;">
                    <i class="fa-solid fa-circle-exclamation" style="color:#EF4444;"></i> Action Needed
                </div>
            <?php else: ?>
                <div class="top-badge-indicator" style="background: rgba(245, 158, 11, 0.25); border: 1px solid #F59E0B;">
                    <i class="fa-solid fa-hourglass-start" style="color:#F59E0B;"></i> Pending Review
                </div>
            <?php endif; ?>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $company_avatar; ?>" alt="Company Logo" class="company-avatar-circle">
                <span class="company-name"><?php echo htmlspecialchars($company_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($company_name); ?></h5>
                    <p>Corporate Partner</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="profile.php"><i class="fa-solid fa-building-user"></i> Company Profile</a></li>
                    <li><a href="settings.php"><i class="fa-solid fa-gears"></i> Account Settings</a></li>
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <a href="manage_opportunities.php" class="btn-back">
            <i class="fa-solid fa-arrow-left"></i> Back to Opportunities
        </a>

        <div class="form-card">
            <h2><i class="fa-solid fa-pen-to-square"></i> Edit: <?php echo htmlspecialchars($opportunity['title']); ?></h2>
            <p class="subtitle">Update the opportunity details below. You can save as draft or publish directly.</p>
            
            <?php if(!empty($error)): ?>
                <div class="alert-box danger">
                    <i class="fa-solid fa-circle-exclamation"></i> 
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <label><i class="fa-regular fa-file-lines"></i> Opportunity / Job Title</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($opportunity['title']); ?>" required>

                <label><i class="fa-regular fa-tag"></i> Category Placement Track</label>
                <select name="type" required>
                    <option value="Internship" <?php echo $opportunity['type'] == 'Internship' ? 'selected' : ''; ?>>Internship Placement</option>
                    <option value="Field Study" <?php echo $opportunity['type'] == 'Field Study' ? 'selected' : ''; ?>>Field Study Track</option>
                </select>

                <div class="form-row-grid">
                    <div>
                        <label><i class="fa-regular fa-calendar"></i> Closing Date</label>
                        <input type="date" name="closing_date" value="<?php echo htmlspecialchars($opportunity['closing_date']); ?>" required>
                    </div>
                    <div>
                        <label><i class="fa-regular fa-users"></i> Offers Available (Slots)</label>
                        <input type="number" name="slots" min="1" value="<?php echo htmlspecialchars($opportunity['slots']); ?>" required>
                    </div>
                </div>

                <label><i class="fa-regular fa-star"></i> Minimum Required GPA</label>
                <input type="number" name="required_gpa" step="0.01" min="0.00" max="4.00" value="<?php echo htmlspecialchars($opportunity['required_gpa']); ?>" required>

                <label><i class="fa-regular fa-list-check"></i> Core Responsibilities & Scope</label>
                <textarea name="core_responsibilities" rows="4" required><?php echo htmlspecialchars($opportunity['core_responsibilities']); ?></textarea>

                <label><i class="fa-regular fa-code"></i> Required Qualifications & Tech Stack</label>
                <textarea name="qualifications" rows="3" required><?php echo htmlspecialchars($opportunity['requirements']); ?></textarea>

                <div class="button-group">
                    <button type="submit" name="status_action" value="draft" class="btn-submit">
                        <i class="fa-solid fa-floppy-disk"></i> Update Draft
                    </button>
                    <button type="submit" name="status_action" value="publish" class="btn-submit btn-success" onclick="return confirm('Publish this opportunity after updating?')">
                        <i class="fa-regular fa-circle-check"></i> Update & Publish
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});
</script>

</body>
</html>