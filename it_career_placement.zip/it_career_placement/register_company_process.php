<?php
session_start();
include('includes/db_connect.php');

// Initialize messaging variables
$success_msg = "";
$error_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Gather and clean standard incoming form values
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $org_name = trim($_POST['org_name']);
    $industry = trim($_POST['industry']);
    $location = trim($_POST['location']);

    // Basic Input Validation
    if (empty($username) || empty($email) || empty($password) || empty($org_name)) {
        $error_msg = "Please fill in all required setup configuration fields.";
    } else {
        try {
            // Begin a transaction to ensure both user login and company profile insert or fail together
            $pdo->beginTransaction();

            // 2. Security Check: Check if Username or Email already exists in the primary users table
            $check_user = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
            $check_user->execute([$username, $email]);
            
            if ($check_user->fetchColumn() > 0) {
                $error_msg = "The chosen account credentials or email link are already registered.";
                $pdo->rollBack();
            } else {
                // 3. Encrypt password safely matching secure password toggles architecture
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                // 4. Insert into primary `users` table first to establish system login profile
                $insert_user = $pdo->prepare("INSERT INTO users (username, password, email, role, full_name) VALUES (?, ?, ?, 'company', ?)");
                $insert_user->execute([$username, $hashed_password, $email, $org_name]);
                
                // Fetch the auto-generated user_id to map into the organizations tracking table
                $new_user_id = $pdo->lastInsertId();

                // 5. FIXED: Insert into `organizations` linking org_id explicitly to user_id 
                // Uses our true database matching column: `verification_status` set to 'Pending'
                $insert_org = $pdo->prepare("INSERT INTO organizations (org_id, org_name, industry, location, contact_email, verification_status) VALUES (?, ?, ?, ?, ?, 'Pending')");
                $insert_org->execute([$new_user_id, $org_name, $industry, $location, $email]);

                // Everything succeeded! Commit the transaction changes safely to storage
                $pdo->commit();
                $success_msg = "Company registration application submitted! Waiting for Administrator verification approval.";
            }
        } catch (PDOException $e) {
            // Roll back all changes if an unexpected database issue drops down
            $pdo->rollBack();
            $error_msg = "System Registration Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Corporate Partner Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #fdfbf7; margin: 0; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .reg-box { background: #fff; width: 100%; max-width: 500px; padding: 40px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); border-top: 6px solid #E1AD01; box-sizing: border-box; }
        h2 { color: #1A1A1B; margin-top: 0; font-weight: 900; text-align: center; }
        .form-group { margin-bottom: 20px; position: relative; }
        .form-group label { display: block; font-weight: bold; margin-bottom: 8px; color: #333; font-size: 0.85rem; text-transform: uppercase; }
        .form-group input, .form-group select { width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; background: #fff; font-size: 0.95rem; }
        .form-group input:focus { border-color: #E1AD01; outline: none; }
        .btn-reg { width: 100%; padding: 15px; background: #1A1A1B; color: #E1AD01; border: none; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; border-radius: 6px; cursor: pointer; transition: 0.3s; margin-top: 10px; }
        .btn-reg:hover { background: #E1AD01; color: #1A1A1B; }
        .alert { padding: 15px; border-radius: 6px; font-size: 0.9rem; font-weight: bold; margin-bottom: 20px; }
        .alert-error { background: #fff5f5; color: #ff4d4f; border: 1px solid #ffccc7; }
        .alert-success { background: #e6fffa; color: #2c7a7b; border: 1px solid #b2f5ea; }
        .toggle-pass { position: absolute; right: 15px; top: 38px; cursor: pointer; color: #999; }
    </style>
</head>
<body>

<div class="reg-box">
    <h2><i class="fa-solid fa-building" style="color: #E1AD01;"></i> Company Registration</h2>
    <p style="text-align: center; color: #666; font-size: 0.9rem; margin-bottom: 30px;">Apply to register your corporate division with the career deployment tracking engine.</p>

    <?php if(!empty($error_msg)): ?>
        <div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation"></i> <?php echo $error_msg; ?></div>
    <?php endif; ?>
    <?php if(!empty($success_msg)): ?>
        <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> <?php echo $success_msg; ?></div>
    <?php endif; ?>

    <form action="register_company_process.php" method="POST">
        <div class="form-group">
            <label>Enterprise / Company Name</label>
            <input type="text" name="org_name" required placeholder="e.g. TTCL Corporation">
        </div>
        <div class="form-group">
            <label>Industry Classification</label>
            <input type="text" name="industry" required placeholder="e.g. Telecommunications & IT">
        </div>
        <div class="form-group">
            <label>Location Hub HQ</label>
            <input type="text" name="location" required placeholder="e.g. Dar es Salaam">
        </div>
        <hr style="border: 0; border-top: 1px solid #eee; margin: 25px 0;">
        <div class="form-group">
            <label>Portal Username</label>
            <input type="text" name="username" required placeholder="For portal sign-in operations">
        </div>
        <div class="form-group">
            <label>Official HR/Contact Email</label>
            <input type="email" name="email" required placeholder="hr@yourcompany.co.tz">
        </div>
        <div class="form-group">
            <label>Secure Sign-In Password</label>
            <input type="password" id="password" name="password" required placeholder="••••••••">
            <i class="fa-solid fa-eye toggle-pass" id="toggleIcon" onclick="togglePasswordVisibility()"></i>
        </div>

        <button type="submit" class="btn-reg">Submit Application</button>
    </form>
    
    <p style="text-align: center; margin-top: 20px; font-size: 0.85rem;">
        <a href="login.php" style="color: #87CEEB; text-decoration: none; font-weight: bold;">Return to Portal Login</a>
    </p>
</div>

<script>
function togglePasswordVisibility() {
    var passInput = document.getElementById('password');
    var icon = document.getElementById('toggleIcon');
    if (passInput.type === 'password') {
        passInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>

</body>
</html>