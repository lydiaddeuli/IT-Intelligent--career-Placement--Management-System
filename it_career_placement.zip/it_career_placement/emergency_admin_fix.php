<?php
// Force session clearing to prevent ghost session variables from trapping you
session_start();
session_unset();
session_destroy();

include('includes/db_connect.php');

$admin_email = "admin@placement.com";
$raw_password = "admin123";
// This creates the exact 60-character string PHP password_verify needs
$secure_hash = password_hash($raw_password, PASSWORD_DEFAULT);
$admin_name = "System Administrator";
$admin_role = "admin";

try {
    // 1. Clear out any existing, corrupted admin records using this email
    $delete = $pdo->prepare("DELETE FROM users WHERE email = ?");
    $delete->execute([$admin_email]);

    // 2. Insert a fresh, properly hashed admin user record
    $insert = $pdo->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)");
    $insert->execute([$admin_name, $admin_email, $secure_hash, $admin_role]);

    echo "<div style='padding: 20px; font-family: Arial; max-width: 500px; margin: 50px auto; background: #f6ffed; border: 1px solid #b7eb8f; border-radius: 8px;'>";
    echo "<h2 style='color: #52c41a; margin-top: 0;'>Database Fixed!</h2>";
    echo "<p>The account has been written to your database with a clean cryptographic hash.</p>";
    echo "<p><strong>Email:</strong> <span style='font-family: monospace;'>admin@placement.com</span></p>";
    echo "<p><strong>Password:</strong> <span style='font-family: monospace;'>admin123</span></p>";
    echo "<hr style='border: 0; border-top: 1px solid #d9d9d9;'>";
    echo "<p style='margin-bottom: 0;'><a href='login.php' style='color: #1890ff; font-weight: bold; text-decoration: none;'>Go to Login Page &rarr;</a></p>";
    echo "</div>";

} catch (PDOException $e) {
    echo "<div style='padding: 20px; font-family: Arial; max-width: 500px; margin: 50px auto; background: #fff2f0; border: 1px solid #ffccc7; color: #ff4d4f;'>";
    echo "<strong>Database Error:</strong> " . $e->getMessage();
    echo "</div>";
}
?>