<?php
session_start();
include('includes/db_connect.php');

$account_id = $_GET['account_id'] ?? null;

if (!$account_id) {
    header("Location: register.php");
    exit();
}

// Fetch the organization details dynamically
$stmt = $pdo->prepare("SELECT * FROM organizations WHERE org_id = ?");
$stmt->execute([$account_id]);
$org = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$org) {
    die("System Error: Organization profile not found.");
}

// Decode the dynamic fee arrays
$fees_json = json_encode(['registration_fee' => 0, 'direct_field_cost' => 0]);
$fees = json_decode($org['fee_amounts_json'] ?? $fees_json, true);

$reg_fee = floatval($fees['registration_fee'] ?? 0);
$direct_cost = floatval($fees['direct_field_cost'] ?? 0);
$total_fee = $reg_fee + $direct_cost;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification Invoice | CareerConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           
            --border-light: #E2E8F0;
        }

        body { 
            margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--cream-bg); 
            display: flex; flex-direction: column; min-height: 100vh; color: var(--dark-text);
        }
        
        .global-header {
            background: var(--white); border-bottom: 3px solid var(--softcare-blue);
            padding: 0 25px; height: 80px; display: flex; align-items: center;
        }

        .brand-logo { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 900; color: #000; text-decoration: none; }
        .brand-logo-img { height: 80px; width: auto; }

        .main-workspace { flex: 1; display: flex; justify-content: center; align-items: center; padding: 40px 20px; }
        
        .invoice-card { 
            background: var(--white); width: 100%; max-width: 550px; margin: auto; 
            border-radius: 16px; box-shadow: 0 10px 30px rgba(28, 45, 66, 0.04); 
            overflow: hidden; border-top: 6px solid var(--mustard-yellow); 
        }

        .invoice-header { padding: 30px; text-align: center; border-bottom: 1px dashed var(--border-light); }
        .invoice-body { padding: 40px; }

        .msg-alert { background: #E6F4FC; color: var(--softcare-blue); padding: 15px; border-radius: 8px; font-size: 0.9rem; font-weight: 600; margin-bottom: 25px; border-left: 4px solid var(--softcare-blue); }
        .msg-warning { background: #FEF3C7; color: #B45309; padding: 15px; border-radius: 8px; font-size: 0.9rem; font-weight: 600; margin-bottom: 25px; border-left: 4px solid var(--mustard-yellow); }
        
        .invoice-details { background: var(--cream-bg); padding: 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid var(--border-light); }
        .invoice-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid rgba(0,0,0,0.05); }
        .invoice-row:last-child { border-bottom: none; font-weight: bold; font-size: 1.15rem; color: var(--dark-text); padding-top: 15px; border-top: 2px solid var(--border-light); }

        .reason-box { background: #F8FAFC; border: 1px solid var(--border-light); padding: 15px; border-radius: 8px; margin-bottom: 30px; font-size: 0.9rem; }

        .btn-proceed { 
            background: var(--softcare-blue); color: var(--white); border: none; padding: 16px; 
            width: 100%; border-radius: 8px; font-weight: 800; font-size: 1.05rem; cursor: pointer; 
            text-transform: uppercase; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 10px;
        }
        .btn-proceed:hover { background: var(--dark-text); }
    </style>
</head>
<body>

<header class="global-header">
    <a href="index.php" class="brand-logo">
        <img src="images/logo.jpeg" alt="Logo" class="brand-logo-img"> CareerConnect
    </a>
</header>

<div class="main-workspace">
    <div class="invoice-card">
        <div class="invoice-header">
            <h3 style="margin:0; text-transform: uppercase; letter-spacing: 1px;">Profile Framework Summary</h3>
            <p style="color: var(--muted-text); margin: 5px 0 0 0;">Company Profile Reference: #<?php echo htmlspecialchars($account_id); ?></p>
        </div>
        
        <div class="invoice-body">
            
            <?php if($total_fee > 0): ?>
                <div class="msg-warning">
                    <i class="fa-solid fa-triangle-exclamation"></i> Profile Initialized. Your structured corporate fee parameters have been locked for administrator evaluation.
                </div>
            <?php else: ?>
                <div class="msg-alert">
                    <i class="fa-solid fa-circle-check"></i> Profile Initialized. Your organization is registered as a 100% Free Placement structure.
                </div>
            <?php endif; ?>

            <div class="invoice-details">
                <div class="invoice-row"><span>Organization:</span> <strong><?php echo htmlspecialchars($org['org_name']); ?></strong></div>
                <div class="invoice-row"><span>Fee Type Profile:</span> <span style="color:var(--softcare-blue); font-weight:700;"><?php echo htmlspecialchars($org['has_fees']); ?></span></div>
                <div class="invoice-row"><span>Registration Fee:</span> <span><?php echo number_format($reg_fee, 2); ?> TZS</span></div>
                <div class="invoice-row"><span>Direct Field Cost:</span> <span><?php echo number_format($direct_cost, 2); ?> TZS</span></div>
                <div class="invoice-row"><span>Total Fees Structure:</span> <span style="color: var(--mustard-yellow);"><?php echo number_format($total_fee, 2); ?> TZS</span></div>
            </div>

            <?php if($total_fee > 0 && !empty($org['fee_reason'])): ?>
                <div class="reason-box">
                    <strong style="display:block; margin-bottom:5px; color: var(--dark-text);"><i class="fa-solid fa-comment-dots"></i> Stated Justification Reason:</strong>
                    <p style="margin:0; color: var(--muted-text); line-height:1.4;"><?php echo nl2br(htmlspecialchars($org['fee_reason'])); ?></p>
                </div>
            <?php endif; ?>

            <a href="login.php?msg=Awaiting review" class="btn-proceed">
                Go to Login Gateway <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
    </div>
</div>

</body>
</html>