<?php
session_start();
include('includes/db_connect.php');

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    
    // Check if user exists (fetching user_id and full_name for context)
    $stmt = $pdo->prepare("SELECT user_id, full_name FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        $otp = rand(100000, 999999);
        
        // Custom descriptive log message so the Administrator sees who requested it
        $message = "User " . $user['full_name'] . " (" . $email . ") requested a secure account recovery link. Verification code generated: " . $otp;
        
        // Inserts directly into notifications table for Admin dashboard visibility
        $stmt = $pdo->prepare("INSERT INTO system_notifications (user_id, message, type, otp_code) VALUES (?, ?, 'reset_request', ?)");
        $stmt->execute([$user['user_id'], $message, $otp]);
        
        // Store session data for the next OTP verification script view
        $_SESSION['reset_user_id'] = $user['user_id'];
        $_SESSION['generated_otp_simulation'] = $otp; 
        
        header("Location: verify_otp.php");
        exit();
    } else {
        $error = "The provided email address does not exist in our ecosystem.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Recovery | CareerConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --softcare-blue: #0091DF;      /* Primary Corporate Blue */
            --softcare-light-blue: #E6F4FC;/* Clean Fresh Accent Tint */
            --mustard-yellow: #F59E0B;     /* Sharp Contrast Structural Border Color */
            --dark-text: #1C2D42;          /* Deep Slate Grey Text */
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           /* Modern Workspace Canvas Background */
            --border-light: #E2E8F0;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            flex-direction: column;
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        /* --- NAVIGATION HEADER --- */
        .global-header {
            background: var(--white);
            border-bottom: 3px solid var(--softcare-blue);
            box-shadow: 0 4px 20px rgba(0, 145, 223, 0.06);
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
            box-sizing: border-box;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 900;
            color: #000000;
            text-decoration: none;
            letter-spacing: -0.5px;
        }

        .brand-logo-img {
            height: 80px;
            width: auto;
            object-fit: contain;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 15px;
        }

        .nav-menu li a {
            color: var(--dark-text);
            text-decoration: none;
            font-weight: 700;
            font-size: 0.95rem;
            padding: 10px 18px;
            border-radius: 8px;
            transition: 0.2s ease-in-out;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-menu li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        /* --- CARD WORKSPACE --- */
        .main-workspace {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 60px 20px;
            box-sizing: border-box;
        }
        
        .recovery-container { 
            background: var(--white); 
            width: 100%;
            max-width: 450px; 
            margin: auto; 
            border-radius: 16px; 
            box-shadow: 0 10px 30px rgba(28, 45, 66, 0.04); 
            overflow: hidden; 
            border-top: 6px solid var(--mustard-yellow); 
        }

        .recovery-header { 
            padding: 40px 40px 15px 40px; 
            background: var(--white); 
            text-align: center; 
        }

        .recovery-header h2 { 
            margin: 0; 
            color: var(--dark-text); 
            font-size: 1.6rem; 
            font-weight: 900; 
            letter-spacing: -0.5px;
        }

        .recovery-header span { 
            color: var(--softcare-blue); 
            font-weight: 800; 
            font-size: 0.85rem; 
            text-transform: uppercase; 
            letter-spacing: 1.5px; 
            display: block;
            margin-bottom: 8px;
        }

        .recovery-body { padding: 15px 40px 40px 40px; }

        .form-group { margin-bottom: 24px; position: relative; }

        .form-group > i { 
            position: absolute; 
            left: 16px; 
            top: 44px; 
            color: var(--muted-text); 
            z-index: 5; 
            font-size: 1.05rem;
        }
        
        label { 
            display: block; 
            font-weight: 700; 
            margin-bottom: 9px; 
            color: var(--dark-text); 
            font-size: 0.85rem; 
            text-transform: uppercase; 
            letter-spacing: 0.3px;
        }

        input { 
            width: 100%; 
            padding: 14px 16px 14px 45px; 
            border: 2px solid var(--border-light); 
            border-radius: 8px; 
            box-sizing: border-box; 
            font-size: 1rem; 
            background: var(--cream-bg); 
            color: var(--dark-text); 
            transition: 0.2s ease-in-out;
        }

        input:focus { 
            border-color: var(--softcare-blue); 
            outline: none; 
            background: var(--white); 
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }

        .btn-submit { 
            background: var(--softcare-blue); 
            color: var(--white); 
            border: none; 
            padding: 16px; 
            width: 100%; 
            border-radius: 8px; 
            font-weight: 800; 
            font-size: 1.05rem; 
            cursor: pointer; 
            transition: 0.2s ease-in-out; 
            margin-top: 10px; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
            box-shadow: 0 4px 12px rgba(0, 145, 223, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-submit:hover { 
            background: var(--dark-text); 
            box-shadow: 0 4px 12px rgba(28, 45, 66, 0.2);
        }

        .error-box { 
            background: #FFF5F5; 
            color: #E53E3E; 
            padding: 14px; 
            border-radius: 8px; 
            margin-bottom: 25px; 
            font-weight: 600; 
            border: 1px solid #FED7D7;
            border-left: 5px solid #E53E3E; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 0.9rem;
        }

        .back-link {
            text-align: center;
            margin-top: 25px;
            font-size: 0.95rem;
        }

        .back-link a {
            color: var(--softcare-blue);
            text-decoration: none;
            font-weight: 700;
        }

        .back-link a:hover {
            text-decoration: underline;
        }

        /* --- SYSTEM FOOTER --- */
        .system-footer {
            background: var(--dark-text);
            color: #94A3B8;
            padding: 40px 25px 30px 25px;
            border-top: 4px solid var(--mustard-yellow);
            width: 100%;
            box-sizing: border-box;
        }

        .footer-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
        }

        .footer-column h5 {
            color: var(--white);
            font-size: 1.1rem;
            margin: 0 0 15px 0;
            font-weight: 700;
        }

        .footer-column p {
            font-size: 0.9rem;
            line-height: 1.6;
            margin: 0;
        }

        .footer-base {
            max-width: 1200px;
            margin: 30px auto 0 auto;
            border-top: 1px solid #2E3E52;
            padding-top: 20px;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 600;
        }
    </style>
</head>
<body>

<header class="global-header">
    <div class="nav-container">
        <a href="index.php" class="brand-logo">
            <img src="images/logo.jpeg" alt="CareerConnect Logo" class="brand-logo-img"> CareerConnect
        </a>
        <ul class="nav-menu">
            <li><a href="index.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="login.php"><i class="fa-solid fa-right-to-bracket"></i> Login</a></li>
            <li><a href="register.php"><i class="fa-solid fa-user-plus"></i> Register</a></li>
        </ul>
    </div>
</header>

<div class="main-workspace">
    <div class="recovery-container">
        <div class="recovery-header">
            <span>Security Verification Gateway</span>
            <h2>Account Recovery</h2>
        </div>
        
        <div class="recovery-body">
            <?php if(!empty($error)): ?>
                <div class='error-box'><i class='fa-solid fa-circle-exclamation'></i> <?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>Registered Email Address</label>
                    <i class="fa-solid fa-envelope"></i>
                    <input type="email" name="email" placeholder="name@domain.com" required>
                </div>

                <button type="submit" class="btn-submit">
                    <i class="fa-solid fa-key"></i> Generate Verification OTP
                </button>
            </form>

            <div class="back-link">
                <a href="login.php"><i class="fa-solid fa-arrow-left"></i> Return to Sign In</a>
            </div>
        </div>
    </div>
</div>

<footer id="feedback-section" class="system-footer">
    <div class="footer-inner">
        <div class="footer-column">
            <h5>About CareerConnect</h5>
            <p>Our centralized management architecture handles seamless, automated verification parameters connecting academic talent directly with corporate structures.</p>
        </div>
        <div class="footer-column">
            <h5>Technical Desk Support</h5>
            <p>Encountering user access restrictions or database profile lockouts? Connect directly with support teams at info@softcareplacement.co.tz.</p>
        </div>
    </div>
    <div class="footer-base">
        &copy; 2026 Softcare Intelligent Career Placement System. All Rights Reserved.
    </div>
</footer>

</body>
</html>