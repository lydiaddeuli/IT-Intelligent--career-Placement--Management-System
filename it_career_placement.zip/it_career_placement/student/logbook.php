<?php
session_start();
include('../includes/db_connect.php');

// Enforce active student sessions strictly
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php"); 
    exit();
}

$user_id = $_SESSION['user_id'];
$msg = ""; 
$error = "";

// --- DYNAMIC CONTROL GATEWAY CHECK ---
// Fetch state configuration parameter from settings database
$stmtGate = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'allow_logbook_submission'");
$stmtGate->execute();
$logbook_gate = $stmtGate->fetchColumn();

// If not defined in the settings database table yet, fall back to default enabled status
if ($logbook_gate === false) {
    $logbook_gate = '1'; 
}

// Handle Logbook Form Entry Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Hard security check block on the backend processing layer
    if ($logbook_gate !== '1') {
        $error = "Submission Rejected: The logbook entry submission portal has been closed by administration.";
    } else {
        $week = intval($_POST['week_number']);
        $activities = trim($_POST['activities_done']);
        $lessons = trim($_POST['lessons_learned']);

        if(empty($activities) || empty($lessons)) {
            $error = "All log fields are mandatory to satisfy university compliance rules.";
        } else {
            // Prevent duplicate entries for the same week
            $check = $pdo->prepare("SELECT log_id FROM student_logbooks WHERE student_id = ? AND week_number = ?");
            $check->execute([$user_id, $week]);
            if($check->fetch()) {
                $error = "Week " . $week . " details have already been submitted!";
            } else {
                $ins = $pdo->prepare("INSERT INTO student_logbooks (student_id, week_number, activities_done, lessons_learned) VALUES (?, ?, ?, ?)");
                $ins->execute([$user_id, $week, $activities, $lessons]);
                $msg = "Week " . $week . " logbook entry recorded successfully.";
            }
        }
    }
}

// Fetch historical entries for display archive tracking loop
$logs = $pdo->prepare("SELECT * FROM student_logbooks WHERE student_id = ? ORDER BY week_number DESC");
$logs->execute([$user_id]);
$my_logs = $logs->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly Logbook | Field Study Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #fdfbf7; display: flex; }
        
        /* UNIFIED BRAND PALETTE CONTROL SYSTEM */
        .sidebar { width: 280px; background: #1A1A1B; color: #ffffff; min-height: 100vh; position: fixed; box-shadow: 4px 0 10px rgba(0,0,0,0.1); }
        .sidebar-header { padding: 40px 20px; background: #5C4033; color: #E1AD01; text-align: center; font-weight: 900; font-size: 1.3rem; border-bottom: 3px solid #E1AD01; letter-spacing: 0.5px; }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; }
        .sidebar-menu li a { display: flex; align-items: center; padding: 15px 30px; color: #87CEEB; text-decoration: none; transition: 0.3s; font-weight: bold; }
        .sidebar-menu li a i { margin-right: 15px; width: 20px; text-align: center; }
        .sidebar-menu li a:hover { background: rgba(225, 173, 1, 0.1); color: #E1AD01; }

        .main-content { flex: 1; margin-left: 280px; padding: 40px; box-sizing: border-box; }
        .container { background: #fff; padding: 35px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); border-top: 6px solid #5C4033; }
        
        .form-group { margin-bottom: 20px; }
        label { display: block; font-weight: 700; margin-bottom: 8px; color: #5C4033; font-size: 0.85rem; text-transform: uppercase; }
        input, select, textarea { width: 100%; padding: 12px; border: 1px solid #e1ddded; border-radius: 6px; box-sizing: border-box; font-size: 0.95rem; background: #faf9f5; color: #1A1A1B; }
        input:focus, select:focus, textarea:focus { border-color: #E1AD01; outline: none; background: #fff; }
        textarea { height: 110px; resize: vertical; font-family: inherit; }
        
        /* Interactive submission state elements */
        .btn-submit { background: #E1AD01; color: #1A1A1B; border: none; padding: 14px 30px; border-radius: 6px; font-weight: 800; cursor: pointer; text-transform: uppercase; transition: 0.3s; letter-spacing: 0.5px; }
        .btn-submit:hover { background: #1A1A1B; color: #E1AD01; }
        .btn-submit:disabled { background: #ccc; color: #666; cursor: not-allowed; }

        .log-item { background: #fffdf9; border-left: 4px solid #5C4033; padding: 25px; margin-top: 20px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.02); border: 1px solid #f5f2eb; border-left: 5px solid #5C4033; }
        
        /* Alert Banners Config */
        .alert-box { padding: 15px 20px; border-radius: 8px; font-weight: 600; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; font-size: 0.95rem; }
        .alert-success { background: #eef9f0; color: #2b7a43; border-left: 5px solid #2b7a43; }
        .alert-danger { background: #fdf3f2; color: #c9302c; border-left: 5px solid #c9302c; }
        .gateway-closed-banner { background: #fff5f5; color: #c9302c; border: 1px dashed #c9302c; padding: 20px; border-radius: 8px; text-align: center; font-weight: bold; font-size: 1.05rem; margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header"><i class="fa-solid fa-graduation-cap"></i> PLACEMENT</div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-arrow-left"></i> Back to Overview</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="container">
        <h2 style="margin-top: 0; font-weight: 800; color: #1A1A1B; font-size: 1.8rem;">
            <i class="fa-solid fa-book" style="color: #5C4033; margin-right: 5px;"></i> Field Study Logbook Desk
        </h2>
        <p style="color: #666; margin-bottom: 30px;">Document your weekly organizational workflow milestones for academic supervisor sign-off.</p>
        
        <?php if($msg): ?>
            <div class="alert-box alert-success"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($msg); ?></div>
        <?php endif; ?>
        <?php if($error): ?>
            <div class="alert-box alert-danger"><i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($logbook_gate !== '1'): ?>
            <div class="gateway-closed-banner">
                <i class="fa-solid fa-lock" style="font-size: 1.5rem; margin-bottom: 8px; display: block;"></i>
                Submission Portal Paused: The window for updating or adding field training logbooks is currently locked by administration.
            </div>
        <?php else: ?>
            <form method="POST" style="background: #ffffff; padding: 25px; border-radius: 12px; margin-bottom: 40px; border: 1px solid #f0eeee;">
                <div class="form-group">
                    <label>Target Academic Week</label>
                    <select name="week_number" required style="width: 180px;">
                        <?php for($i=1; $i<=12; $i++) echo "<option value='$i'>Week $i</option>"; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Summary of Core Production Activities Performed</label>
                    <textarea name="activities_done" placeholder="What tasks did you complete at the organization this week?" required></textarea>
                </div>
                <div class="form-group">
                    <label>Key Insights / Core Lessons Mastered</label>
                    <textarea name="lessons_learned" placeholder="What technical or professional insights did you pick up?" required></textarea>
                </div>
                <button type="submit" class="btn-submit"><i class="fa-solid fa-paper-plane"></i> Commit Week Journal</button>
            </form>
        <?php endif; ?>

        <h3 style="color: #1A1A1B; font-weight: 800; border-bottom: 2px solid #f5f2eb; padding-bottom: 10px; margin-top: 40px;">
            <i class="fa-solid fa-clock-rotate-left" style="color: #666; font-size: 1.1rem;"></i> Submitted Logs Archive
        </h3>
        
        <?php if (empty($my_logs)): ?>
            <p style="color: #999; font-style: italic; text-align: center; padding: 30px 0;">No logs found. Your submitted records will list right here.</p>
        <?php else: ?>
            <?php foreach($my_logs as $log): ?>
                <div class="log-item">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <h4 style="margin: 0; color: #5C4033; font-weight: 800; font-size: 1.1rem;">WEEK <?php echo $log['week_number']; ?> ENTRY</h4>
                        <span style="font-size: 0.8rem; color: #888; background: #f5f2eb; padding: 4px 10px; border-radius: 20px; font-weight: 600;">
                            <i class="fa-regular fa-calendar-days"></i> <?php echo date('M d, Y', strtotime($log['submitted_at'])); ?>
                        </span>
                    </div>
                    <p style="margin: 0 0 10px 0; font-size: 0.95rem; line-height: 1.5;">
                        <strong style="color: #1A1A1B; display: block; margin-bottom: 4px;"><i class="fa-solid fa-list-check" style="color: #E1AD01;"></i> Tasks Done:</strong>
                        <span style="color:#555;"><?php echo nl2br(htmlspecialchars($log['activities_done'])); ?></span>
                    </p>
                    <p style="margin: 0; font-size: 0.95rem; line-height: 1.5;">
                        <strong style="color: #1A1A1B; display: block; margin-bottom: 4px;"><i class="fa-solid fa-lightbulb" style="color: #E1AD01;"></i> Lessons Learned:</strong>
                        <span style="color:#555;"><?php echo nl2br(htmlspecialchars($log['lessons_learned'])); ?></span>
                    </p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
</body>
</html>