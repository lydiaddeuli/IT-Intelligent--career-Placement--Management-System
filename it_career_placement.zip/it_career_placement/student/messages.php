<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$success_msg = "";
$error_msg = "";

// Dynamic Placement Fallback Track check 
$profile_stmt = $pdo->prepare("SELECT placement_type FROM student_profiles WHERE student_id = ?");
$profile_stmt->execute([$student_id]);
$profile_data = $profile_stmt->fetch();
$placement_type = $profile_data['placement_type'] ?? 'Internship';

// Redirect to Logbook if they are on a Field Study track instead of Messaging
if ($placement_type === 'Field Study') {
    header("Location: logbook.php");
    exit();
}

// Handle Message Outgoing Submission Form
if (isset($_POST['send_message'])) {
    $message_text = trim($_POST['message_text']);
    
    if (!empty($message_text)) {
        // Automatically route message array baseline logs to systemic placement coordinator desk
        $insert_stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, sender_role, message_text, created_at) VALUES (?, 1, 'student', ?, NOW())");
        if ($insert_stmt->execute([$student_id, $message_text])) {
            $success_msg = "Message broadcasted into communication data arrays successfully!";
        } else {
            $error_msg = "Database network write processing execution failed.";
        }
    } else {
        $error_msg = "Cannot transmit an empty message payload.";
    }
}

// Fetch Continuous History Dialogue Loop logs between this specific student and Coordinator/Admin (ID: 1)
$chat_stmt = $pdo->prepare("SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = 1) OR (sender_id = 1 AND receiver_id = ?) ORDER BY created_at ASC");
$chat_stmt->execute([$student_id, $student_id]);
$chat_history = $chat_stmt->fetchAll(PDO::FETCH_ASSOC);

$student_name = $_SESSION['username'] ?? 'Candidate Student';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Direct Support Messaging Console | CareerConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }

        body { margin: 0; font-family: 'Segoe UI', sans-serif; display: flex; min-height: 100vh; color: var(--dark-text); }
        
        /* SIDEBAR */
        .sidebar { width: 280px; background: var(--milky-white); position: fixed; top: 0; bottom: 0; box-shadow: 1px 0 10px rgba(0,0,0,0.05); border-right: 1px solid var(--border-light); display: flex; flex-direction: column; }
        .sidebar-header { padding: 25px 20px; display: flex; align-items: center; gap: 12px; font-weight: 900; border-bottom: 2px solid var(--border-light); }
        .sidebar-logo { height: 38px; }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; }
        .sidebar-menu li a { display: flex; align-items: center; padding: 12px 24px; color: var(--pure-black); text-decoration: none; font-weight: 700; font-size: 0.95rem; }
        .sidebar-menu li a i { margin-right: 15px; width: 20px; text-align: center; }
        .sidebar-menu li a.active-page { color: var(--softcare-blue); background: var(--softcare-light-blue); border-left: 4px solid var(--softcare-blue); }

        /* CONTENT */
        .main-content { flex: 1; margin-left: 280px; padding: 30px 40px; display: flex; flex-direction: column; background: var(--white); }
        .app-header-bar { border-bottom: 1px solid var(--border-light); padding: 14px 0px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
        .header-title-left { font-size: 1.3rem; font-weight: 700; }

        /* CHAT WINDOW INTERFACE MATRIX */
        .chat-layout-card { border: 1px solid var(--border-light); border-radius: 12px; display: flex; flex-direction: column; height: 60vh; background: var(--milky-white); overflow: hidden; }
        .chat-header { background: var(--white); padding: 15px 20px; border-bottom: 1px solid var(--border-light); font-weight: 700; display: flex; align-items: center; gap: 10px; }
        
        .chat-body-feed { flex: 1; padding: 20px; overflow-y: auto; display: flex; flex-direction: column; gap: 15px; }
        
        .msg-bubble { max-width: 65%; padding: 12px 16px; border-radius: 12px; line-height: 1.4; font-size: 0.92rem; position: relative; }
        .msg-bubble.student { background: var(--softcare-blue); color: var(--white); align-self: flex-end; border-bottom-right-radius: 2px; }
        .msg-bubble.coordinator { background: var(--white); color: var(--dark-text); align-self: flex-start; border-bottom-left-radius: 2px; border: 1px solid var(--border-light); }
        
        .msg-timestamp { font-size: 0.68rem; display: block; margin-top: 5px; opacity: 0.8; text-align: right; }
        
        .chat-footer-form { background: var(--white); padding: 15px 20px; border-top: 1px solid var(--border-light); display: flex; gap: 15px; }
        .chat-input-box { flex: 1; padding: 12px; border: 1px solid var(--border-light); border-radius: 8px; font-family: inherit; font-size: 0.95rem; background: var(--milky-white); }
        .chat-input-box:focus { outline: none; border-color: var(--softcare-blue); background: var(--white); }
        
        .btn-send-message { background: var(--softcare-blue); color: var(--white); border: none; padding: 0 25px; border-radius: 8px; font-weight: 700; cursor: pointer; transition: background 0.2s; }
        .btn-send-message:hover { background: #0077b6; }
        
        .alert-toast { padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 0.9rem; font-weight: 600; }
        .alert-toast.success { background: #DCFCE7; color: #008543; }
        .alert-toast.error { background: #FEE2E2; color: var(--alert-red); }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
        <li><a href="profile.php"><i class="fa-solid fa-user-circle"></i> My Profile</a></li>
        <li><a href="upload_docs.php"><i class="fa-solid fa-cloud-arrow-up"></i> Upload Documents</a></li>
        <li><a href="cv_manager.php"><i class="fa-solid fa-file-invoice"></i> Build & Upload CV</a></li>
        
        <li><a href="opportunities.php"><i class="fa-solid fa-building-user"></i> View Vacancies</a></li>
        <li><a href="applications.php"><i class="fa-solid fa-route"></i> My Applications</a></li>
        <li><a href="messages.php" class="active-page"><i class="fa-solid fa-comments"></i> Direct Messaging</a></li>
        <li><a href="details.php"><i class="fa-solid fa-print"></i> Allocation Letter</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="app-header-bar">
        <div class="header-title-left">Placement Support Communication Line</div>
        <div><strong>Active Track:</strong> <?php echo htmlspecialchars($placement_type); ?></div>
    </div>

    <?php if(!empty($success_msg)): ?>
        <div class="alert-toast success"><?php echo $success_msg; ?></div>
    <?php endif; ?>
    <?php if(!empty($error_msg)): ?>
        <div class="alert-toast error"><?php echo $error_msg; ?></div>
    <?php endif; ?>

    <div class="chat-layout-card">
        <div class="chat-header">
            <i class="fa-solid fa-headset" style="color: var(--softcare-blue);"></i>
            <span>Placement Officer Desk (Admin Support)</span>
        </div>
        
        <div class="chat-body-feed" id="chatFeed">
            <?php if(empty($chat_history)): ?>
                <div style="text-align: center; color: var(--muted-text); margin-top: 50px; font-size: 0.9rem;">
                    No communications indexed yet. Dispatch a message to initialize telemetry with the coordinator.
                </div>
            <?php else: ?>
                <?php foreach($chat_history as $msg): ?>
                    <?php $is_student = ($msg['sender_role'] === 'student'); ?>
                    <div class="msg-bubble <?php echo $is_student ? 'student' : 'coordinator'; ?>">
                        <strong><?php echo $is_student ? 'You' : 'Coordinator'; ?>:</strong>
                        <div style="margin-top: 4px;"><?php echo htmlspecialchars($msg['message_text']); ?></div>
                        <span class="msg-timestamp"><?php echo date('M d, h:i A', strtotime($msg['created_at'])); ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <form action="messages.php" method="POST" class="chat-footer-form">
            <input type="text" name="message_text" class="chat-input-box" placeholder="Type structural system inquiry here..." required autocomplete="off">
            <button type="submit" name="send_message" class="btn-send-message">
                <i class="fa-solid fa-paper-plane"></i> Transmit
            </button>
        </form>
    </div>
</div>

<script>
    // System automation: Lock layout scrolling feed to bottom row matrix entry on load
    var chatFeed = document.getElementById('chatFeed');
    chatFeed.scrollTop = chatFeed.scrollHeight;
</script>
</body>
</html>