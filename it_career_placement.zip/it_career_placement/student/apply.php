<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

// Fetch student details for header
$stmt = $pdo->prepare("SELECT full_name FROM users WHERE user_id = ?");
$stmt->execute([$student_id]);
$user = $stmt->fetch();
$student_name = $user['full_name'] ?? 'Student';

// --- AVATAR UPLOAD HANDLING ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['ajax_profile_pic'])) {
    $file = $_FILES['ajax_profile_pic'];
    $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($file_ext, $allowed_exts) && $file['error'] === 0) {
        $upload_dir = '../uploads/avatars/';
        if (!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }
        $new_filename = 'avatar_' . $student_id . '_' . time() . '.' . $file_ext;
        $target_path = $upload_dir . $new_filename;
        if (move_uploaded_file($file['tmp_name'], $target_path)) {
            $update_stmt = $pdo->prepare("UPDATE student_profiles SET profile_pic = ? WHERE student_id = ?");
            $update_stmt->execute([$target_path, $student_id]);
            header("Location: apply.php");
            exit();
        }
    }
}

// Fetch student profile
$stmt = $pdo->prepare("SELECT placement_type, cv_path, profile_pic FROM student_profiles WHERE student_id = ?");
$stmt->execute([$student_id]);
$profile = $stmt->fetch();
$track = $profile['placement_type'] ?? 'Internship';
$profile_pic = $profile['profile_pic'] ?? '';
$student_avatar = !empty($profile_pic) ? '../' . $profile_pic : 'https://ui-avatars.com/api/?name=' . urlencode($student_name) . '&background=0091DF&color=fff&size=40';
$cv_path = $profile['cv_path'] ?? '';
$is_cv_complete = !empty($cv_path);   // FIXED: removed unreliable file_exists()

// FIXED: Accept opportunity ID from both POST and GET
$opp_id = 0;
if (isset($_POST['id'])) {
    $opp_id = intval($_POST['id']);
} elseif (isset($_GET['id'])) {
    $opp_id = intval($_GET['id']);
}
if ($opp_id == 0) { 
    header("Location: opportunities.php"); 
    exit(); 
}

// Fetch opportunity details
$stmt = $pdo->prepare("
    SELECT o.*, org.org_name 
    FROM opportunities o 
    LEFT JOIN organizations org ON o.company_id = org.org_id 
    WHERE o.opp_id = ?
");
$stmt->execute([$opp_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) { die("Opportunity not found."); }

// Fetch notifications
$notif_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_notifications WHERE student_id = ? AND is_read = 0");
$notif_stmt->execute([$student_id]);
$unread_notifications_count = $notif_stmt->fetchColumn();

$feed_stmt = $pdo->prepare("SELECT title, message, created_at FROM student_notifications WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
$feed_stmt->execute([$student_id]);
$recent_notifications = $feed_stmt->fetchAll();

// Handle CV upload
$upload_msg = "";
$upload_error = "";
$cv_uploaded = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_cv'])) {
    if (isset($_FILES['cv_file']) && $_FILES['cv_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['cv_file']['tmp_name'];
        $file_name = $_FILES['cv_file']['name'];
        $file_size = $_FILES['cv_file']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed = ['pdf', 'doc', 'docx'];
        if (!in_array($file_ext, $allowed)) {
            $upload_error = "Invalid file format. Please upload PDF, DOC, or DOCX.";
        } elseif ($file_size > 5 * 1024 * 1024) {
            $upload_error = "File size exceeds 5MB limit.";
        } else {
            $target_dir = "../uploads/cvs/";
            if (!is_dir($target_dir)) { mkdir($target_dir, 0777, true); }
            $new_file_name = "CV_STUDENT_" . $student_id . "_" . time() . "." . $file_ext;
            $target_file = $target_dir . $new_file_name;

            if (move_uploaded_file($file_tmp, $target_file)) {
                $update_stmt = $pdo->prepare("UPDATE student_profiles SET cv_path = ? WHERE student_id = ?");
                $update_stmt->execute([$target_file, $student_id]);
                $upload_msg = "CV uploaded successfully!";
                $cv_uploaded = true;
                $is_cv_complete = true;
                $cv_path = $target_file;
                
                // Refresh profile
                $stmt = $pdo->prepare("SELECT cv_path FROM student_profiles WHERE student_id = ?");
                $stmt->execute([$student_id]);
                $profile = $stmt->fetch();
                $cv_path = $profile['cv_path'] ?? '';
                $is_cv_complete = !empty($cv_path);
            } else {
                $upload_error = "Failed to upload CV. Please try again.";
            }
        }
    } else {
        $upload_error = "Please select a file to upload.";
    }
}

// Check if already applied
$applied_stmt = $pdo->prepare("SELECT COUNT(*) FROM applications WHERE student_id = ? AND opportunity_id = ?");
$applied_stmt->execute([$student_id, $opp_id]);
$already_applied = $applied_stmt->fetchColumn() > 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }

        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            margin-bottom: 30px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-radius: 12px; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
            box-shadow: 0 4px 14px rgba(0, 145, 223, 0.25);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .bell-dropdown-wrapper {
            position: relative;
            display: inline-block;
        }

        .bell-trigger-btn {
            background: none;
            border: none;
            color: var(--white);
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            padding: 5px;
            display: flex;
            align-items: center;
        }
        .bell-trigger-btn:hover { opacity: 0.85; }

        .bell-badge-counter {
            position: absolute;
            top: 0px;
            right: -2px;
            background: var(--alert-red);
            color: var(--white);
            font-size: 0.62rem;
            font-weight: 800;
            min-width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--softcare-blue);
        }

        .bell-overlay-panel {
            display: none;
            position: absolute;
            right: -10px;
            top: 140%;
            background: var(--white);
            min-width: 320px;
            max-width: 360px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            border-radius: 10px;
            border: 1px solid var(--border-light);
            z-index: 500;
            overflow: hidden;
        }
        .bell-dropdown-wrapper:hover .bell-overlay-panel { display: block; }

        .bell-panel-header {
            background: var(--milky-white);
            padding: 12px 16px;
            font-size: 0.82rem;
            font-weight: 800;
            color: var(--dark-text);
            border-bottom: 1px solid var(--border-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .bell-feed-scroll { max-height: 280px; overflow-y: auto; }
        
        .bell-item-row {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.15s;
            text-decoration: none;
            display: block;
        }
        .bell-item-row:last-child { border-bottom: none; }
        .bell-item-row:hover { background: var(--softcare-light-blue); }
        .bell-item-row h6 { margin: 0 0 3px 0; font-size: 0.82rem; color: var(--dark-text); font-weight: 700; }
        .bell-item-row p { margin: 0; font-size: 0.76rem; color: var(--muted-text); line-height: 1.35; }
        .bell-item-row span { font-size: 0.68rem; color: #94A3B8; display: block; margin-top: 4px; }
        .bell-empty-state { padding: 20px; text-align: center; color: var(--muted-text); font-size: 0.85rem; }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .student-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .student-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .header-dropdown-card.show {
            display: block;
        }

        .dropdown-user-info {
            padding: 16px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.92rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.72rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li {
            display: block;
        }

        .dropdown-menu-list li a,
        .dropdown-menu-list li label {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            transition: 0.2s;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
            border: none;
            background: none;
            font-family: inherit;
            text-align: left;
        }

        .dropdown-menu-list li a:hover,
        .dropdown-menu-list li label:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.85rem;
            margin-bottom: 20px;
            background: var(--milky-white);
            color: var(--dark-text);
            border: 1px solid var(--border-light);
            transition: 0.2s;
        }

        .btn-back:hover {
            background: var(--border-light);
        }

        .card { 
            background: var(--white); 
            padding: 30px 35px; 
            border-radius: 12px; 
            border: 1px solid var(--border-light); 
            max-width: 800px; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02); 
        }

        .card .job-title {
            margin: 0 0 2px 0;
            font-size: 1.4rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .card .company-name {
            color: var(--muted-text);
            font-weight: 600;
            font-size: 0.95rem;
            margin-bottom: 20px;
        }

        /* Requirements List */
        .requirements-list {
            background: var(--milky-white);
            border: 1px solid var(--border-light);
            border-radius: 8px;
            padding: 0;
            margin: 20px 0;
            list-style: none;
        }

        .requirements-list li {
            padding: 10px 18px;
            border-bottom: 1px solid var(--border-light);
            display: flex;
            font-size: 0.92rem;
            line-height: 1.6;
        }

        .requirements-list li:last-child {
            border-bottom: none;
        }

        .requirements-list .req-label {
            font-weight: 700;
            color: var(--dark-text);
            min-width: 120px;
            flex-shrink: 0;
        }

        .requirements-list .req-value {
            color: var(--dark-text);
        }

        .requirements-list .req-value .skill-tag {
            display: inline-block;
            background: var(--milky-white);
            border: 1px solid var(--border-light);
            color: var(--dark-text);
            padding: 1px 10px;
            border-radius: 4px;
            font-size: 0.8rem;
            margin: 2px 4px 2px 0;
        }

        /* CV Section */
        .cv-section {
            margin: 20px 0;
            padding: 20px;
            background: var(--milky-white);
            border: 1px solid var(--border-light);
            border-radius: 8px;
        }

        .cv-section .section-title {
            font-weight: 700;
            font-size: 0.95rem;
            color: var(--dark-text);
            margin-bottom: 12px;
            display: block;
        }

        .cv-status {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            background: #DCFCE7;
            border-radius: 6px;
            border: 1px solid #BBF7D0;
            margin-bottom: 12px;
            font-weight: 600;
            color: var(--aloe-green);
            font-size: 0.9rem;
        }

        .cv-upload-box {
            background: var(--white);
            border: 2px dashed var(--border-light);
            border-radius: 6px;
            padding: 16px;
            text-align: center;
            margin-bottom: 12px;
            transition: border-color 0.2s;
        }

        .cv-upload-box:hover {
            border-color: var(--softcare-blue);
        }

        .cv-upload-box input[type="file"] {
            display: block;
            margin: 8px auto;
            padding: 8px;
            font-size: 0.85rem;
            border: 1px solid var(--border-light);
            border-radius: 4px;
            background: var(--white);
            width: auto;
            cursor: pointer;
        }

        .cv-upload-box .hint {
            font-size: 0.75rem;
            color: var(--muted-text);
        }

        .btn-upload { 
            background: var(--softcare-blue); 
            color: white; 
            padding: 10px 24px; 
            border: none; 
            border-radius: 6px; 
            font-weight: 700; 
            font-size: 0.9rem; 
            cursor: pointer; 
            transition: background 0.2s; 
            text-decoration: none; 
            display: inline-flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            justify-content: center;
        }

        .btn-upload:hover { 
            background: #0077b6; 
        }

        .btn-submit { 
            background: var(--aloe-green); 
            color: white; 
            padding: 12px 28px; 
            border: none; 
            border-radius: 6px; 
            font-weight: 700; 
            font-size: 0.95rem; 
            cursor: pointer; 
            transition: background 0.2s; 
            text-decoration: none; 
            display: inline-flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            justify-content: center;
            margin-top: 8px;
        }

        .btn-submit:hover { 
            background: #006B36; 
        }

        .btn-secondary {
            background: var(--milky-white);
            color: var(--dark-text);
            padding: 10px 20px;
            border: 1px solid var(--border-light);
            border-radius: 6px;
            font-weight: 700;
            font-size: 0.85rem;
            cursor: pointer;
            transition: 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            flex: 1;
            justify-content: center;
        }

        .btn-secondary:hover {
            background: var(--border-light);
        }

        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 12px;
            flex-wrap: wrap;
        }

        .btn-group .btn-secondary {
            flex: 1;
            min-width: 120px;
        }

        .success-banner { 
            background: #DCFCE7; 
            color: var(--aloe-green); 
            padding: 12px 18px; 
            border-radius: 6px; 
            border: 1px solid #BBF7D0; 
            margin-bottom: 18px; 
            font-weight: 600; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 0.9rem;
        }

        .alert-box { 
            background: #FEF2F2; 
            color: var(--alert-red); 
            padding: 16px 20px; 
            border-radius: 6px; 
            border: 1px solid #FEE2E2; 
            margin-bottom: 18px;
        }

        .alert-box .alert-title { 
            margin: 0 0 6px 0; 
            font-weight: 700;
            font-size: 0.95rem;
        }

        .alert-box p {
            margin: 0 0 4px 0;
            font-size: 0.9rem;
        }

        .form-section {
            margin-top: 20px;
            border-top: 1px solid var(--border-light);
            padding-top: 20px;
        }

        .form-section label {
            display: block;
            font-weight: 700;
            font-size: 0.9rem;
            color: var(--dark-text);
            margin-bottom: 6px;
        }

        .form-section textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid var(--border-light);
            border-radius: 6px;
            min-height: 100px;
            box-sizing: border-box;
            background: var(--milky-white);
            font-family: inherit;
            font-size: 0.95rem;
            transition: border-color 0.2s;
            resize: vertical;
        }

        .form-section textarea:focus {
            outline: none;
            border-color: var(--softcare-blue);
        }

        .already-applied {
            background: #E6F4FC;
            border: 1px solid #BAE0F7;
            border-radius: 6px;
            padding: 16px 20px;
            text-align: center;
            font-weight: 600;
            color: var(--softcare-blue);
            font-size: 0.95rem;
        }

        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .main-content { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active-page { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .app-header-bar { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .student-name { font-size: 0.75rem; max-width: 80px; }
            .student-avatar-circle { width: 28px; height: 28px; }
            .page-content { padding: 16px; }
            .card { padding: 20px; }
            .card .job-title { font-size: 1.2rem; }
            .requirements-list li { flex-direction: column; padding: 8px 14px; }
            .requirements-list .req-label { min-width: auto; margin-bottom: 2px; }
            .btn-group { flex-direction: column; }
            .btn-group .btn-secondary { flex: 1; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
        }

        @media (max-width: 576px) {
            .sidebar { width: 60px; }
            .main-content { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .app-header-bar { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .student-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .student-avatar-circle { width: 26px; height: 26px; }
            .page-content { padding: 12px; }
            .card { padding: 16px; }
            .card .job-title { font-size: 1rem; }
            .cv-section { padding: 14px; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<!-- Hidden form for avatar upload -->
<form id="avatarUploadForm" action="apply.php" method="POST" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="ajax_profile_pic" name="ajax_profile_pic" accept="image/*" onchange="document.getElementById('avatarUploadForm').submit();">
</form>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-user-circle"></i> <span>My Profile</span></a></li>
        <li><a href="upload_docs.php"><i class="fa-solid fa-cloud-arrow-up"></i> <span>Upload Documents</span></a></li>
        <li><a href="cv_manager.php"><i class="fa-solid fa-file-invoice"></i> <span>Build & Upload CV</span></a></li>
        <li><a href="opportunities.php" class="active-page"><i class="fa-solid fa-building-user"></i> <span>View Vacancies</span></a></li>
        <li><a href="applications.php"><i class="fa-solid fa-route"></i> <span>My Applications</span></a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> <span>Change Password</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-regular fa-paper-plane"></i> Apply for Position
            </div>
        </div>
        
        <div class="header-right">
            <div class="bell-dropdown-wrapper">
                <button class="bell-trigger-btn" title="System Alerts">
                    <i class="fa-solid fa-bell"></i>
                    <?php if($unread_notifications_count > 0): ?>
                        <span class="bell-badge-counter"><?php echo $unread_notifications_count; ?></span>
                    <?php endif; ?>
                </button>
                <div class="bell-overlay-panel">
                    <div class="bell-panel-header">System Alerts</div>
                    <div class="bell-feed-scroll">
                        <?php if(empty($recent_notifications)): ?>
                            <div class="bell-empty-state">No real-time alert updates indexed.</div>
                        <?php else: foreach($recent_notifications as $notif): ?>
                            <a href="notifications.php" class="bell-item-row">
                                <h6><?php echo htmlspecialchars($notif['title']); ?></h6>
                                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                <span><i class="fa-regular fa-clock"></i> <?php echo date('M d, g:i A', strtotime($notif['created_at'])); ?></span>
                            </a>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>

            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $student_avatar; ?>" alt="Profile" class="student-avatar-circle">
                <span class="student-name"><?php echo htmlspecialchars($student_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($student_name); ?></h5>
                    <p><?php echo htmlspecialchars($track); ?></p>
                </div>
                <ul class="dropdown-menu-list">
                    <li>
                        <label for="ajax_profile_pic">
                            <i class="fa-solid fa-camera"></i> Upload Picture
                        </label>
                    </li>
                    <li>
                        <a href="../logout.php" class="logout-item">
                            <i class="fa-solid fa-right-from-bracket"></i> Sign Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <!-- Back Button -->
        <a href="opportunities.php" class="btn-back">
            <i class="fa-solid fa-arrow-left"></i> Back to Vacancies
        </a>

        <?php if (isset($_SESSION['apply_success'])): ?>
            <div class="success-banner">
                <i class="fa-solid fa-circle-check"></i> <?php echo $_SESSION['apply_success']; unset($_SESSION['apply_success']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($upload_msg)): ?>
            <div class="success-banner">
                <i class="fa-solid fa-circle-check"></i> <?php echo $upload_msg; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($upload_error)): ?>
            <div class="alert-box">
                <div class="alert-title">Upload Error</div>
                <p><?php echo $upload_error; ?></p>
            </div>
        <?php endif; ?>

        <div class="card">
            <h1 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h1>
            <div class="company-name"><?php echo htmlspecialchars($job['org_name'] ?? 'N/A'); ?></div>

            <!-- Requirements List -->
            <ul class="requirements-list">
                <li>
                    <span class="req-label">GPA Target</span>
                    <span class="req-value"><?php echo htmlspecialchars($job['required_gpa'] ?? 'N/A'); ?></span>
                </li>
                <li>
                    <span class="req-label">Type</span>
                    <span class="req-value"><?php echo htmlspecialchars($job['type'] ?? 'Internship'); ?></span>
                </li>
                <?php if (!empty($job['slots'])): ?>
                <li>
                    <span class="req-label">Slots Available</span>
                    <span class="req-value"><?php echo htmlspecialchars($job['slots']); ?></span>
                </li>
                <?php endif; ?>
                <?php if (!empty($job['closing_date'])): ?>
                <li>
                    <span class="req-label">Closing Date</span>
                    <span class="req-value"><?php echo date('F d, Y', strtotime($job['closing_date'])); ?></span>
                </li>
                <?php endif; ?>
                <?php if (!empty($job['required_skills'])): ?>
                <li>
                    <span class="req-label">Required Skills</span>
                    <span class="req-value">
                        <?php 
                        $skills = explode(',', $job['required_skills']);
                        foreach($skills as $skill):
                            $skill = trim($skill);
                            if(!empty($skill)):
                        ?>
                            <span class="skill-tag"><?php echo htmlspecialchars($skill); ?></span>
                        <?php 
                            endif;
                        endforeach; 
                        ?>
                    </span>
                </li>
                <?php endif; ?>
                <?php if (!empty($job['core_responsibilities'])): ?>
                <li>
                    <span class="req-label">Responsibilities</span>
                    <span class="req-value"><?php echo nl2br(htmlspecialchars($job['core_responsibilities'])); ?></span>
                </li>
                <?php endif; ?>
            </ul>

            <?php if ($already_applied): ?>
                <div class="already-applied">
                    <i class="fa-regular fa-circle-check"></i> You have already applied for this position.
                </div>
            <?php else: ?>
                <!-- CV Upload Section -->
                <div class="cv-section">
                    <span class="section-title">Upload Your CV</span>
                    
                  <?php if ($is_cv_complete): ?>
    <div class="cv-status">
        <i class="fa-regular fa-circle-check"></i> CV uploaded successfully.
        <?php if (!empty($cv_path)): ?>
            <span style="font-weight:400;font-size:0.8rem;color:var(--muted-text);margin-left:4px;">
                (<?php echo basename($cv_path); ?>)
            </span>
            <a href="<?php echo htmlspecialchars($cv_path); ?>" 
               target="_blank" 
               style="margin-left:14px; color:var(--aloe-green); font-weight:700; text-decoration:none; font-size:0.85rem;">
                <i class="fa-solid fa-eye"></i> Preview CV
            </a>
        <?php endif; ?>
    </div>
<?php endif; ?>

                    <form method="POST" enctype="multipart/form-data">
                        <!-- FIXED: Hidden field so the page stays on the same opportunity after upload -->
                        <input type="hidden" name="id" value="<?php echo $opp_id; ?>">

                        <div class="cv-upload-box">
                            <input type="file" name="cv_file" accept=".pdf,.doc,.docx">
                            <div class="hint">Supported formats: PDF, DOC, DOCX (Max 5MB)</div>
                        </div>
                        
                        <div class="btn-group">
                            <button type="submit" name="upload_cv" class="btn-upload">
                                <i class="fa-solid fa-upload"></i> Upload CV
                            </button>
                            <a href="cv_manager.php" class="btn-secondary">
                                <i class="fa-regular fa-pen-to-square"></i> Build CV
                            </a>
                            <a href="applications.php" class="btn-secondary">
                                <i class="fa-regular fa-list"></i> My Applications
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Application Form -->
                <?php if ($is_cv_complete): ?>
                    <div class="form-section">
                        <form action="process_apply.php" method="POST">
                            <input type="hidden" name="opp_id" value="<?php echo $opp_id; ?>">
                            <label>Cover Letter</label>
                            <textarea name="cover_letter" required placeholder="Explain why you are a good fit for this position..."></textarea>
                            <button type="submit" class="btn-submit">
                                <i class="fa-regular fa-paper-plane"></i> Submit Application
                            </button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="alert-box">
                        <div class="alert-title">Action Required</div>
                        <p>You cannot submit an application because your CV has not been uploaded.</p>
                        <p style="font-size:0.85rem;color:var(--muted-text);margin-top:4px;">Please upload your CV above to proceed with your application.</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('profileDropdown');
    const trigger = document.querySelector('.profile-trigger-zone');
    if (!trigger.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});
</script>
</body>
</html>