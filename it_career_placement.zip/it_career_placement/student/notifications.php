<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle AJAX Request for marking notification read in background
if (isset($_GET['action']) && $_GET['action'] === 'read' && isset($_GET['id'])) {
    $notif_id = intval($_GET['id']);
    $update = $pdo->prepare("UPDATE student_notifications SET is_read = 1 WHERE notif_id = ? AND student_id = ?");
    $update->execute([$notif_id, $user_id]);
    echo json_encode(['status' => 'success']);
    exit();
}

// Fetch total notification alerts history
$stmt = $pdo->prepare("SELECT * FROM student_notifications WHERE student_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Notifications | Student Desk</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #fdfbf7; display: flex; }
        
        .sidebar { width: 280px; background: #1A1A1B; color: #ffffff; min-height: 100vh; position: fixed; }
        .sidebar-header { padding: 40px 20px; background: #E1AD01; color: #1A1A1B; text-align: center; font-weight: 900; }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; }
        .sidebar-menu li a { display: flex; align-items: center; padding: 15px 30px; color: #87CEEB; text-decoration: none; transition: 0.3s; }
        .sidebar-menu li a:hover { background: rgba(255,255,255,0.05); color: #E1AD01; }

        .main-content { flex: 1; margin-left: 280px; padding: 40px; }
        .container { background: #fff; padding: 35px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); border-top: 6px solid #1A1A1B; }
        
        /* Notification card rows layout profiles */
        .notif-card { background: #fff; border: 1px solid #eee; border-left: 5px solid #ccc; padding: 20px; border-radius: 6px; margin-bottom: 15px; position: relative; transition: 0.3s; cursor: pointer; }
        .notif-card:hover { transform: translateX(3px); box-shadow: 0 4px 10px rgba(0,0,0,0.03); }
        
        /* Highlight state style definitions for completely unread indicators */
        .unread { border-left-color: #E1AD01; background: #fffdf6; }
        .unread .notif-title::after { content: 'NEW'; background: #ff4d4f; color: #fff; font-size: 0.65rem; font-weight: bold; padding: 2px 6px; border-radius: 4px; margin-left: 10px; vertical-align: middle; }
        
        .notif-title { font-size: 1.05rem; font-weight: bold; color: #1A1A1B; margin: 0 0 5px 0; }
        .notif-time { font-size: 0.78rem; color: #999; margin-bottom: 10px; font-family: monospace; }
        .notif-body { color: #555; font-size: 0.92rem; line-height: 1.5; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">STUDENT PORTAL</div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-arrow-left"></i> Back to Overview</a></li>
        <li><a href="notifications.php" style="color: #E1AD01;"><i class="fa-solid fa-bell"></i> Notifications</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="container">
        <h2><i class="fa-solid fa-bell" style="color: #E1AD01;"></i> Operational Activity Alerts</h2>
        <p style="color: #666;">Track systematic timeline log logs pushed down by system administrators and tracking processes.</p>
        
        <div style="margin-top: 25px;">
            <?php foreach ($notifications as $n): ?>
                <div class="notif-card <?php echo $n['is_read'] ? '' : 'unread'; ?>" 
                     id="notif-<?php echo $n['notif_id']; ?>" 
                     onclick="markAsRead(<?php echo $n['notif_id']; ?>)">
                    
                    <h3 class="notif-title">
                        <i class="fa-solid <?php echo $n['is_read'] ? 'fa-envelope-open' : 'fa-envelope'; ?>" style="color: #999; margin-right: 8px;"></i>
                        <?php echo htmlspecialchars($n['title']); ?>
                    </h3>
                    <div class="notif-time"><?php echo date('Y-m-d H:i:s', strtotime($n['created_at'])); ?></div>
                    <div class="notif-body"><?php echo nl2br(htmlspecialchars($n['message'])); ?></div>
                </div>
            <?php endforeach; ?>

            <?php if (empty($notifications)): ?>
                <div style="text-align: center; color: #999; padding: 50px 0;">
                    <i class="fa-solid fa-bell-slash" style="font-size: 3rem; color: #ddd; display: block; margin-bottom: 15px;"></i>
                    Your activity log execution streams are entirely clear right now.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function markAsRead(id) {
    var card = document.getElementById('notif-' + id);
    if (card.classList.contains('unread')) {
        // Send background processing string request to clean database metrics parameters
        fetch('notifications.php?action=read&id=' + id)
        .then(response => response.json())
        .then(data => {
            if(data.status === 'success') {
                card.classList.remove('unread');
                // Change icon style dynamically inside the header loop
                var icon = card.querySelector('.notif-title i');
                icon.classList.remove('fa-envelope');
                icon.classList.add('fa-envelope-open');
            }
        });
    }
}
</script>

</body>
</html>