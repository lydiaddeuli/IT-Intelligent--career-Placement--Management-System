<?php
include('../includes/db_connect.php');

// Retrieve secure lookup parameter token tracking values
$token = $_GET['token'] ?? '';
if (empty($token)) {
    die("<div style='text-align:center; margin-top:50px; font-family:sans-serif;'><h2>Invalid token parameters.</h2><p>Access configuration arguments missing from core path string context.</p></div>");
}

// Fetch recommendation tracking elements and verify against your exact primary key: a.app_id
$stmt = $pdo->prepare("
    SELECT r.*, a.referee_name, a.referee_designation, s.fullname as student_name, o.title as job_title 
    FROM referee_recommendations r
    JOIN applications a ON r.application_id = a.app_id
    JOIN student_profiles s ON a.student_id = s.student_id
    JOIN company_opportunities o ON a.opportunity_id = o.id OR a.opportunity_id = o.opp_id
    WHERE r.secure_token = ?
    LIMIT 1
");
$stmt->execute([$token]);
$recommendation = $stmt->fetch();

if (!$recommendation) {
    die("<div style='text-align:center; margin-top:50px; font-family:sans-serif;'><h2>Authentication failed.</h2><p>No valid assignment references matching this token configuration exist inside active databases.</p></div>");
}

// Evaluate if referee tracking responses have already been saved to the database lines previously
$already_submitted = !empty($recommendation['submitted_at']);
$success_msg = "";

// Handle recommendation form submission requests tracking loops
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_recommendation']) && !$already_submitted) {
    $text = trim($_POST['recommendation_text']);
    $rating = $_POST['rating'] ?? 'Highly Recommended';

    // Commit assessment structural blocks directly to table spaces
    $stmt_update = $pdo->prepare("
        UPDATE referee_recommendations 
        SET recommendation_text = ?, rating = ?, submitted_at = NOW() 
        WHERE secure_token = ?
    ");
    $stmt_update->execute([$text, $rating, $token]);
    
    // Switch tracking status context dynamically to show verification dashboard views smoothly
    $already_submitted = true;
    $success_msg = "Thank you! Your reference evaluation parameters have been compiled securely into the candidate's validation profile.";
    
    // Refresh dataset values dynamically to show updated metrics inside read-only template structures
    $recommendation['recommendation_text'] = $text;
    $recommendation['rating'] = $rating;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Endorsement Engine | CareerConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;
            --dark-text: #1C2D42;
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;
            --border-light: #E2E8F0;
        }
        body { font-family: 'Segoe UI', sans-serif; background: var(--milky-white); margin: 0; padding: 40px 20px; display: flex; justify-content: center; color: var(--dark-text); }
        .box-wrapper { background: var(--white); width: 100%; max-width: 580px; padding: 40px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); border-top: 8px solid var(--softcare-blue); box-sizing: border-box; }
        .form-control { width: 100%; padding: 12px; border: 1px solid var(--border-light); border-radius: 8px; font-size: 0.95rem; margin-top: 6px; box-sizing: border-box; font-family: inherit; }
        .form-control:focus { outline: none; border-color: var(--softcare-blue); }
        .btn-send { background: var(--softcare-blue); color: var(--white); border: none; padding: 14px; width:100%; border-radius: 8px; font-weight: 700; cursor: pointer; text-transform: uppercase; margin-top: 15px; font-size: 0.95rem; }
        .success-banner { background: #DCFCE7; color: #008543; padding: 15px; border-radius: 8px; font-weight: 600; margin-bottom: 20px; border: 1px solid #BBF7D0; line-height: 1.4; }
    </style>
</head>
<body>

<div class="box-wrapper">
    <div style="text-align: center; margin-bottom: 25px;">
        <i class="fa-solid fa-shield-halved" style="font-size: 2.5rem; color: var(--softcare-blue);"></i>
        <h2 style="margin: 10px 0 5px 0;">Student Placement Endorsement</h2>
        <p style="color: var(--muted-text); margin:0;">Secure appraisal context for: <strong><?php echo htmlspecialchars($recommendation['student_name']); ?></strong></p>
    </div>

    <?php if (!empty($success_msg)): ?>
        <div class="success-banner"><i class="fa-solid fa-circle-check"></i> <?php echo $success_msg; ?></div>
    <?php endif; ?>

    <?php if ($already_submitted): ?>
        <!-- SUPERVISOR REQUIREMENT MET: Displayed when clicked again (Read-Only Mode) -->
        <div style="background: #F1F5F9; padding: 25px; border-radius: 8px; border-left: 5px solid var(--muted-text);">
            <h3 style="margin:0 0 8px 0; font-size:1.1rem; color: var(--dark-text);"><i class="fa-solid fa-circle-info"></i> Endorsement Completed</h3>
            <p style="margin: 0 0 20px 0; font-size: 0.9rem; color: var(--muted-text);">You have already safely completed and logged an endorsement for this student application tracking link context.</p>
            
            <p style="margin: 0 0 10px 0; font-size:0.95rem;"><strong>Assessment Suitability Rating:</strong><br> <span style="color:var(--softcare-blue); font-weight:700;"><?php echo htmlspecialchars($recommendation['rating']); ?></span></p>
            <p style="margin: 0 0 5px 0; font-size:0.95rem;"><strong>Your Logged Endorsement Remarks:</strong></p>
            <p style="font-style: italic; color:#475569; background:var(--white); padding:15px; border-radius:6px; border:1px solid var(--border-light); margin:0; line-height:1.5;">
                "<?php echo htmlspecialchars($recommendation['recommendation_text'] ?? 'No commentary arguments supplied.'); ?>"
            </p>
        </div>
    <?php else: ?>
        <!-- Standard inputs submission loop rendered if no active metrics are stored within the target tables yet -->
        <form action="" method="POST">
            <p style="font-size: 0.95rem; line-height: 1.5; color: var(--dark-text); margin-bottom:20px;">
                Hello <strong><?php echo htmlspecialchars($recommendation['referee_name']); ?></strong> (<?php echo htmlspecialchars($recommendation['referee_designation']); ?>), you are designated as the verification referee for this candidate's application into the <strong><?php echo htmlspecialchars($recommendation['job_title']); ?></strong> track position. Please fill out your remarks below.
            </p>

            <div style="margin-bottom: 15px;">
                <label style="font-weight: 700; font-size: 0.9rem;">Candidate Suitability Rating</label>
                <select name="rating" class="form-control">
                    <option value="Highly Recommended">Highly Recommended (Excellent Technical Aptitude)</option>
                    <option value="Recommended">Recommended (Competent Skill Base)</option>
                    <option value="Needs Training">Needs Additional Training Supervision</option>
                </select>
            </div>

            <div style="margin-bottom: 15px;">
                <label style="font-weight: 700; font-size: 0.9rem;">Recommendation Remarks / Reference</label>
                <textarea name="recommendation_text" class="form-control" rows="5" required placeholder="Type your performance evaluation or structural observations concerning the student's baseline capabilities..."></textarea>
            </div>

            <button type="submit" name="submit_recommendation" class="btn-send">Submit Official Verification</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>