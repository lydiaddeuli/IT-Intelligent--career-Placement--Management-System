<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

// --- AVATAR UPLOAD HANDLING ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['ajax_profile_pic'])) {
    $file = $_FILES['ajax_profile_pic'];
    $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($file_ext, $allowed_exts) && $file['error'] === 0) {
        $upload_dir = '../uploads/avatars/';
        if (!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }
        $new_filename = 'avatar_' . $student_id . '_' . time() . '.' . $file_ext;
        $target_path = $upload_dir . $new_filename;
        if (move_uploaded_file($file['tmp_name'], $target_path)) {
            $update_stmt = $pdo->prepare("UPDATE student_profiles SET profile_pic = ? WHERE student_id = ?");
            $update_stmt->execute([$target_path, $student_id]);
            header("Location: applications.php");
            exit();
        }
    }
}

// Handle Confirm Acceptance - Change status from Accepted to Confirmed
if (isset($_GET['confirm_id'])) {
    $app_id = intval($_GET['confirm_id']);
    
    $update = $pdo->prepare("UPDATE applications SET status = 'Confirmed', updated_at = NOW() WHERE app_id = ? AND student_id = ?");
    $update->execute([$app_id, $student_id]);
    
    $_SESSION['confirm_success'] = "You have successfully confirmed your acceptance!";
    header("Location: applications.php");
    exit();
}

// Fetch student profile with name
$stmt = $pdo->prepare("
    SELECT u.full_name, sp.placement_type, sp.profile_pic 
    FROM users u
    LEFT JOIN student_profiles sp ON u.user_id = sp.student_id
    WHERE u.user_id = ?
");
$stmt->execute([$student_id]);
$profile = $stmt->fetch();
$full_name = $profile['full_name'] ?? 'Student';
$track = $profile['placement_type'] ?? 'Internship';
$profile_pic = $profile['profile_pic'] ?? '';
$student_avatar = !empty($profile_pic) ? '../' . $profile_pic : 'https://ui-avatars.com/api/?name=' . urlencode($full_name) . '&background=0091DF&color=fff&size=40';

// Fetch unread notifications
$notif_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_notifications WHERE student_id = ? AND is_read = 0");
$notif_stmt->execute([$student_id]);
$unread_notifications_count = $notif_stmt->fetchColumn();

// Fetch recent notifications
$feed_stmt = $pdo->prepare("SELECT title, message, created_at FROM student_notifications WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
$feed_stmt->execute([$student_id]);
$recent_notifications = $feed_stmt->fetchAll();

// Fetch applications with company name and opportunity ID
$history_stmt = $pdo->prepare("
    SELECT a.*, o.title, o.type, o.opp_id, org.org_name 
    FROM applications a 
    LEFT JOIN opportunities o ON a.opportunity_id = o.opp_id 
    LEFT JOIN organizations org ON o.company_id = org.org_id
    WHERE a.student_id = ? 
    ORDER BY a.applied_at DESC
");
$history_stmt->execute([$student_id]);
$my_applications = $history_stmt->fetchAll();

// Count statuses - Use exact trimmed status from database
$total_apps = count($my_applications);
$pending_count = 0;
$accepted_count = 0;

foreach ($my_applications as $app) {
    // Trim and normalize status to prevent whitespace or case issues
    $status = isset($app['status']) ? trim($app['status']) : '';

    // FIX: an empty/NULL status must fall back to 'Pending' here too —
    // the table below already does this (see $rawStatus), but this counting
    // loop didn't, so a NULL status matched no switch case and never got
    // counted, leaving the "Pending" card stuck at 0 even though the table
    // showed rows tagged "Pending".
    if ($status === '') {
        $status = 'Pending';
    }

    switch ($status) {
        case 'Pending': 
            $pending_count++; 
            break;
        case 'Accepted': 
            $accepted_count++; 
            break;
        case 'Confirmed':
            // Confirmed is not shown in summary cards, but tracked
            break;
        case 'Rejected':
            // Rejected is not shown in summary cards
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications | CareerConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }
        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }

        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            margin-bottom: 30px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-radius: 12px; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
            box-shadow: 0 4px 14px rgba(0, 145, 223, 0.25);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .bell-dropdown-wrapper {
            position: relative;
            display: inline-block;
        }

        .bell-trigger-btn {
            background: none;
            border: none;
            color: var(--white);
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            padding: 5px;
            display: flex;
            align-items: center;
        }
        .bell-trigger-btn:hover { opacity: 0.85; }

        .bell-badge-counter {
            position: absolute;
            top: 0px;
            right: -2px;
            background: var(--alert-red);
            color: var(--white);
            font-size: 0.62rem;
            font-weight: 800;
            min-width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--softcare-blue);
        }

        .bell-overlay-panel {
            display: none;
            position: absolute;
            right: -10px;
            top: 140%;
            background: var(--white);
            min-width: 320px;
            max-width: 360px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            border-radius: 10px;
            border: 1px solid var(--border-light);
            z-index: 500;
            overflow: hidden;
        }
        .bell-dropdown-wrapper:hover .bell-overlay-panel { display: block; }

        .bell-panel-header {
            background: var(--milky-white);
            padding: 12px 16px;
            font-size: 0.82rem;
            font-weight: 800;
            color: var(--dark-text);
            border-bottom: 1px solid var(--border-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .bell-feed-scroll { max-height: 280px; overflow-y: auto; }
        
        .bell-item-row {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.15s;
            text-decoration: none;
            display: block;
        }
        .bell-item-row:last-child { border-bottom: none; }
        .bell-item-row:hover { background: var(--softcare-light-blue); }
        .bell-item-row h6 { margin: 0 0 3px 0; font-size: 0.82rem; color: var(--dark-text); font-weight: 700; }
        .bell-item-row p { margin: 0; font-size: 0.76rem; color: var(--muted-text); line-height: 1.35; }
        .bell-item-row span { font-size: 0.68rem; color: #94A3B8; display: block; margin-top: 4px; }
        .bell-empty-state { padding: 20px; text-align: center; color: var(--muted-text); font-size: 0.85rem; }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .student-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .student-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .header-dropdown-card.show {
            display: block;
        }

        .dropdown-user-info {
            padding: 16px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.92rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.72rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li {
            display: block;
        }

        .dropdown-menu-list li a,
        .dropdown-menu-list li label {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            transition: 0.2s;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
            border: none;
            background: none;
            font-family: inherit;
            text-align: left;
        }

        .dropdown-menu-list li a:hover,
        .dropdown-menu-list li label:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 12px;
        }

        .page-header h2 {
            margin: 0;
            font-size: 1.3rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-header h2 i {
            color: var(--softcare-blue);
        }

        /* Status Summary Cards */
        .summary-dashboard-cards {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
            margin-bottom: 25px;
            max-width: 450px;
        }

        .metric-card-box {
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            padding: 16px 20px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .metric-card-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        }

        .metric-card-box .metric-val {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .metric-card-box h5 {
            margin: 0 0 2px 0;
            font-size: 0.7rem;
            color: var(--muted-text);
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
        }

        .metric-card-box .metric-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: var(--white);
            flex-shrink: 0;
            margin: 0 auto 8px auto;
        }

        .metric-card-box .metric-icon.pending { background: var(--mustard-yellow); }
        .metric-card-box .metric-icon.accepted { background: var(--softcare-blue); }

        .history-table-container { 
            border: 1px solid var(--border-light); 
            border-radius: 12px; 
            overflow: hidden; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02); 
            background: var(--white);
        }
        .dashboard-list-table { 
            width: 100%; 
            border-collapse: collapse; 
            font-size: 0.92rem; 
        }
        .dashboard-list-table th { 
            background: var(--milky-white); 
            padding: 12px 18px; 
            text-align: left; 
            font-size: 0.72rem; 
            text-transform: uppercase; 
            color: var(--dark-text); 
            font-weight: 700; 
            letter-spacing: 0.5px; 
            border-bottom: 2px solid var(--border-light); 
        }
        .dashboard-list-table td { 
            padding: 12px 18px; 
            border-bottom: 1px solid var(--border-light); 
            vertical-align: middle;
        }
        .dashboard-list-table tr:last-child td { border-bottom: none; }
        .dashboard-list-table tr:hover td { background: var(--softcare-light-blue); }

        .badge-pill-status { 
            padding: 4px 12px; 
            border-radius: 20px; 
            font-size: 0.72rem; 
            font-weight: 700; 
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .status-badge-Pending { background: #FFFBEB; color: #B45309; border: 1px solid #FCD34D; }
        .status-badge-Accepted { background: #E6F4FC; color: var(--softcare-blue); border: 1px solid #BAE0F7; }
        .status-badge-Confirmed { background: #DCFCE7; color: var(--aloe-green); border: 1px solid #BBF7D0; }
        .status-badge-Rejected { background: #FEF2F2; color: var(--alert-red); border: 1px solid #FEE2E2; }

        .btn-confirm {
            background: var(--aloe-green);
            color: white;
            padding: 5px 14px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-weight: 700;
            font-size: 0.75rem;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-confirm:hover {
            background: #006B36;
        }

        .action-cell {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted-text);
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--border-light);
            margin-bottom: 15px;
            display: block;
        }

        .empty-state h4 {
            margin: 0 0 8px 0;
            color: var(--dark-text);
        }

        .success-message {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        .vacancy-link {
            color: var(--softcare-blue);
            text-decoration: none;
            font-weight: 700;
            transition: 0.2s;
        }
        .vacancy-link:hover {
            text-decoration: underline;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .main-content { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active-page { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .app-header-bar { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .student-name { font-size: 0.75rem; max-width: 80px; }
            .student-avatar-circle { width: 28px; height: 28px; }
            .page-content { padding: 16px; }
            .page-header h2 { font-size: 1.1rem; }
            .summary-dashboard-cards { max-width: 100%; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
        }

        @media (max-width: 576px) {
            .sidebar { width: 60px; }
            .main-content { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .app-header-bar { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .student-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .student-avatar-circle { width: 26px; height: 26px; }
            .page-content { padding: 12px; }
            .page-header h2 { font-size: 1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr; gap: 10px; max-width: 100%; }
            .metric-card-box { padding: 12px 14px; }
            .metric-card-box .metric-val { font-size: 1.2rem; }
            .metric-card-box .metric-icon { width: 30px; height: 30px; font-size: 0.8rem; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<!-- Hidden form for avatar upload -->
<form id="avatarUploadForm" action="applications.php" method="POST" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="ajax_profile_pic" name="ajax_profile_pic" accept="image/*" onchange="document.getElementById('avatarUploadForm').submit();">
</form>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-user-circle"></i> <span>My Profile</span></a></li>
        <li><a href="upload_docs.php"><i class="fa-solid fa-cloud-arrow-up"></i> <span>Upload Documents</span></a></li>
        <li><a href="cv_manager.php"><i class="fa-solid fa-file-invoice"></i> <span>Build & Upload CV</span></a></li>
        <li><a href="opportunities.php"><i class="fa-solid fa-building-user"></i> <span>View Vacancies</span></a></li>
        <li><a href="applications.php" class="active-page"><i class="fa-solid fa-route"></i> <span>My Applications</span></a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> <span>Change Password</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-route"></i> My Applications
            </div>
        </div>
        
        <div class="header-right">
            <div class="bell-dropdown-wrapper">
                <button class="bell-trigger-btn" title="System Alerts">
                    <i class="fa-solid fa-bell"></i>
                    <?php if($unread_notifications_count > 0): ?>
                        <span class="bell-badge-counter"><?php echo $unread_notifications_count; ?></span>
                    <?php endif; ?>
                </button>
                <div class="bell-overlay-panel">
                    <div class="bell-panel-header">System Alerts</div>
                    <div class="bell-feed-scroll">
                        <?php if(empty($recent_notifications)): ?>
                            <div class="bell-empty-state">No real-time alert updates indexed.</div>
                        <?php else: foreach($recent_notifications as $notif): ?>
                            <a href="notifications.php" class="bell-item-row">
                                <h6><?php echo htmlspecialchars($notif['title']); ?></h6>
                                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                <span><i class="fa-regular fa-clock"></i> <?php echo date('M d, g:i A', strtotime($notif['created_at'])); ?></span>
                            </a>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>

            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $student_avatar; ?>" alt="Profile" class="student-avatar-circle">
                <span class="student-name"><?php echo htmlspecialchars($full_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($full_name); ?></h5>
                    <p><?php echo htmlspecialchars($track); ?></p>
                </div>
                <ul class="dropdown-menu-list">
                    <li>
                        <label for="ajax_profile_pic">
                            <i class="fa-solid fa-camera"></i> Upload Picture
                        </label>
                    </li>
                    <li>
                        <a href="../logout.php" class="logout-item">
                            <i class="fa-solid fa-right-from-bracket"></i> Sign Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <?php if (isset($_SESSION['confirm_success'])): ?>
            <div class="success-message">
                <i class="fa-solid fa-circle-check"></i> <?php echo $_SESSION['confirm_success']; unset($_SESSION['confirm_success']); ?>
            </div>
        <?php endif; ?>

        <div class="page-header">
            <h2><i class="fa-solid fa-route"></i> My Applications</h2>
        </div>

        <!-- Status Summary Cards: Pending and Accepted -->
        <div class="summary-dashboard-cards">
            <div class="metric-card-box">
                <div class="metric-icon pending">
                    <i class="fa-solid fa-clock"></i>
                </div>
                <h5>Accepted</h5>
                <div class="metric-val"><?php echo $pending_count; ?></div>
            </div>
            <div class="metric-card-box">
                <div class="metric-icon accepted">
                    <i class="fa-regular fa-circle-check"></i>
                </div>
                
            </div>
        </div>

        <div class="history-table-container">
            <table class="dashboard-list-table">
                <thead>
                    <tr>
                        <th>Vacancy</th>
                        <th>Company</th>
                        <th>Type</th>
                        <th>Applied Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($my_applications)): ?>
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <i class="fa-regular fa-file-lines"></i>
                                    <h4>No Applications Yet</h4>
                                    <p>Browse vacancies and start your career journey today.</p>
                                    <a href="opportunities.php" style="color:var(--softcare-blue);font-weight:700;text-decoration:none;">
                                        <i class="fa-solid fa-arrow-right"></i> View Vacancies
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($my_applications as $app): ?>
                            <?php if (!empty($app['title'])): ?>
                            <tr>
                                <td>
                                    <a href="detail.php?id=<?php echo intval($app['opp_id']); ?>" class="vacancy-link">
                                        <strong><?php echo htmlspecialchars($app['title']); ?></strong>
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars($app['org_name'] ?? 'N/A'); ?></td>
                                <td><span style="background:var(--softcare-light-blue);padding:2px 10px;border-radius:12px;font-size:0.7rem;font-weight:600;color:var(--softcare-blue);"><?php echo htmlspecialchars($app['type'] ?? 'N/A'); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($app['applied_at'])); ?></td>
                                <td>
                                    <?php 
                                        // Get exact status from database, trimmed to remove any whitespace
                                        $rawStatus = isset($app['status']) ? trim($app['status']) : 'Pending';
                                        
                                        // Fallback to Pending if status is empty
                                        if (empty($rawStatus)) {
                                            $rawStatus = 'Pending';
                                        }
                                        
                                        $displayStatus = htmlspecialchars($rawStatus);
                                        $cssClass = htmlspecialchars($rawStatus);
                                        
                                        $statusIcons = [
                                            'Pending' => 'fa-clock',
                                            'Accepted' => 'fa-check-circle',
                                            'Confirmed' => 'fa-circle-check',
                                            'Rejected' => 'fa-times-circle'
                                        ];
                                        $icon = $statusIcons[$rawStatus] ?? 'fa-circle';
                                    ?>
                                    <span class="badge-pill-status status-badge-<?php echo $cssClass; ?>">
                                        <i class="fa-regular <?php echo $icon; ?>"></i>
                                        <?php echo $displayStatus; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-cell">
                                        <?php if ($rawStatus === 'Accepted'): ?>
                                            <a href="?confirm_id=<?php echo $app['app_id']; ?>" class="btn-confirm" onclick="return confirm('Are you sure you want to confirm this acceptance?')">
                                                <i class="fa-regular fa-circle-check"></i> Confirm
                                            </a>
                                        <?php elseif ($rawStatus === 'Confirmed'): ?>
                                            <span style="color:var(--aloe-green);font-weight:700;font-size:0.8rem;">
                                                <i class="fa-regular fa-circle-check"></i> Joined
                                            </span>
                                        <?php elseif ($rawStatus === 'Rejected'): ?>
                                            <span style="color:var(--alert-red);font-weight:600;font-size:0.8rem;">
                                                <i class="fa-regular fa-times-circle"></i> Declined
                                            </span>
                                        <?php else: ?>
                                            <span style="color:var(--muted-text);font-weight:600;font-size:0.8rem;">
                                                <i class="fa-regular fa-clock"></i> Awaiting Response
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('profileDropdown');
    const trigger = document.querySelector('.profile-trigger-zone');
    if (!trigger.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});
</script>
</body>
</html>