<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['username'] ?? 'Student Candidate';

// --- DIRECT AVATAR UPLOAD HANDLING ENGINE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['ajax_profile_pic'])) {
    $file = $_FILES['ajax_profile_pic'];
    $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($file_ext, $allowed_exts) && $file['error'] === 0) {
        $upload_dir = '../uploads/avatars/';
        if (!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }
        $new_filename = 'avatar_' . $student_id . '_' . time() . '.' . $file_ext;
        $target_path = $upload_dir . $new_filename;
        if (move_uploaded_file($file['tmp_name'], $target_path)) {
            $update_stmt = $pdo->prepare("UPDATE student_profiles SET profile_pic = ? WHERE student_id = ?");
            $update_stmt->execute([$target_path, $student_id]);
            header("Location: details.php");
            exit();
        }
    }
}

try {
    // Verified structure from image_934fab.jpg
    $student_stmt = $pdo->prepare("SELECT placement_type, profile_pic FROM student_profiles WHERE student_id = ?");
    $student_stmt->execute([$student_id]);
    $student_info = $student_stmt->fetch();
    $placement_type = $student_info['placement_type'] ?? 'Internship';
    $profile_pic = $student_info['profile_pic'] ?? '';
} catch (PDOException $e) { $placement_type = 'Internship'; }

$notif_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_notifications WHERE student_id = ? AND is_read = 0");
$notif_stmt->execute([$student_id]);
$unread_notifications_count = $notif_stmt->fetchColumn();

$feed_stmt = $pdo->prepare("SELECT title, message, created_at FROM student_notifications WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
$feed_stmt->execute([$student_id]);
$recent_notifications = $feed_stmt->fetchAll();

// FIXED QUERY: Joins via verified keys (app_id, opportunity_id, opp_id, company_id)
$allocation = false;
try {
    $allocation_stmt = $pdo->prepare("
        SELECT a.status, a.applied_at as allocation_date, o.title as job_title, org.org_name as company_name, org.org_email as company_email, org.org_phone as company_phone 
        FROM applications a 
        JOIN opportunities o ON a.opportunity_id = o.opp_id 
        JOIN organizations org ON o.company_id = org.org_id 
        WHERE a.student_id = ? AND a.status = 'Approved'
        ORDER BY a.app_id DESC LIMIT 1
    ");
    $allocation_stmt->execute([$student_id]);
    $allocation = $allocation_stmt->fetch();
} catch (PDOException $e) {
    $allocation = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Allocation Letter | CareerConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--white); display: flex; min-height: 100vh; color: var(--dark-text); }
        
        .sidebar { width: 280px; background: var(--milky-white); color: var(--pure-black); position: fixed; top: 0; bottom: 0; box-shadow: 1px 0 10px rgba(0,0,0,0.05); z-index: 100; display: flex; flex-direction: column; border-right: 1px solid var(--border-light); }
        .sidebar-header { padding: 25px 20px; background: var(--white); display: flex; align-items: center; gap: 12px; font-weight: 900; font-size: 1.15rem; border-bottom: 2px solid var(--border-light); color: var(--pure-black); }
        .sidebar-logo { height: 38px; width: auto; border-radius: 6px; background: var(--white); padding: 2px; border: 1px solid var(--border-light); }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; flex: 1; overflow-y: auto; }
        .sidebar-menu li a { display: flex; align-items: center; padding: 12px 24px; color: var(--pure-black); text-decoration: none; transition: 0.2s; font-weight: 700; font-size: 0.95rem; }
        .sidebar-menu li a i { margin-right: 15px; width: 20px; text-align: center; color: var(--pure-black); }
        .sidebar-menu li a:hover { background: var(--softcare-light-blue); color: var(--softcare-blue); }
        .sidebar-menu li a.active-page { color: var(--softcare-blue); background: var(--softcare-light-blue); border-left: 4px solid var(--softcare-blue); padding-left: 20px; }

        .main-content { flex: 1; margin-left: 280px; padding: 30px 40px; box-sizing: border-box; display: flex; flex-direction: column; background: var(--white); }
        
        .app-header-bar { background: var(--softcare-blue); padding: 12px 24px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; border-radius: 12px; box-shadow: 0 4px 14px rgba(0, 145, 223, 0.2); }
        .header-title-left { font-size: 1.25rem; font-weight: 700; color: var(--white); }
        .header-controls-right { display: flex; align-items: center; gap: 25px; }

        .bell-dropdown-wrapper { position: relative; display: inline-block; }
        .bell-trigger-btn { background: none; border: none; color: var(--white); font-size: 1.2rem; cursor: pointer; position: relative; padding: 5px; display: flex; align-items: center; }
        .bell-badge-counter { position: absolute; top: 0; right: -2px; background: var(--alert-red); color: var(--white); font-size: 0.62rem; font-weight: 800; min-width: 15px; height: 15px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid var(--softcare-blue); }
        .bell-overlay-panel { display: none; position: absolute; right: -10px; top: 140%; background: var(--white); min-width: 320px; max-width: 360px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); border-radius: 10px; border: 1px solid var(--border-light); z-index: 500; }
        .bell-dropdown-wrapper:hover .bell-overlay-panel { display: block; }
        
        .user-profile-dropdown-wrapper { position: relative; display: inline-block; padding-bottom: 10px; margin-bottom: -10px; }
        .user-identity-block { border-left: 1px solid rgba(255, 255, 255, 0.3); padding-left: 20px; display: flex; align-items: center; gap: 12px; cursor: pointer; }
        .user-info-text h4 { margin: 0; font-size: 1.05rem; font-weight: 700; color: var(--white); }
        .profile-circle-avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; background: var(--white); border: 2px solid rgba(255, 255, 255, 0.6); display: flex; align-items: center; justify-content: center; color: var(--softcare-blue); }
        .track-indicator { font-size: 0.7rem; font-weight: 800; padding: 4px 10px; border-radius: 6px; text-transform: uppercase; background: rgba(255, 255, 255, 0.2); color: var(--white); border: 1px solid rgba(255, 255, 255, 0.4); }
        .profile-settings-overlay { display: none; position: absolute; right: 0; top: 100%; background: var(--white); min-width: 200px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); border-radius: 8px; border: 1px solid var(--border-light); z-index: 600; overflow: hidden; }
        .user-profile-dropdown-wrapper:hover .profile-settings-overlay { display: block; }

        .control-panel-box { background: var(--milky-white); border: 1px solid var(--border-light); padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; }
        .btn-print-letter { background: var(--dark-text); color: var(--white); border: none; padding: 11px 20px; border-radius: 6px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: background 0.2s; }
        .btn-print-letter:hover { background: var(--pure-black); }
        #printable-letter-sheet { background: var(--white); border: 1px solid var(--border-light); padding: 50px 60px; border-radius: 4px; max-width: 800px; margin: 0 auto; color: #000000; box-shadow: 0 4px 20px rgba(0,0,0,0.02); }
        .letter-crest-header { text-align: center; border-bottom: 3px double #000000; padding-bottom: 15px; margin-bottom: 30px; }
        .letter-crest-header h1 { margin: 0; font-size: 1.5rem; text-transform: uppercase; }
        .letter-meta-row { display: flex; justify-content: space-between; margin-bottom: 25px; }
        .letter-subject-line { text-align: center; margin: 25px 0; font-size: 1.05rem; font-weight: 800; text-transform: uppercase; text-decoration: underline; }
        .letter-body-prose { font-size: 1rem; line-height: 1.6; text-align: justify; }
        .letter-sign-off { margin-top: 40px; }
        .signature-placeholder { height: 40px; width: 150px; border-bottom: 1px dashed #64748B; margin-bottom: 5px; }
        .empty-allocation-notice { text-align: center; padding: 60px 20px; border: 2px dashed var(--border-light); border-radius: 12px; background: var(--milky-white); }

        @media print {
            body * { visibility: hidden; }
            #printable-letter-sheet, #printable-letter-sheet * { visibility: visible; }
            #printable-letter-sheet { position: absolute; left: 0; top: 0; width: 100%; border: none; box-shadow: none; padding: 0; }
        }
    </style>
</head>
<body>

<form id="avatarUploadForm" action="opportunities.php" method="POST" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="ajax_profile_pic" name="ajax_profile_pic" accept="image/*" onchange="document.getElementById('avatarUploadForm').submit();">
</form>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
        <li><a href="profile.php"><i class="fa-solid fa-user-circle"></i> My Profile</a></li>
        <li><a href="upload_docs.php"><i class="fa-solid fa-cloud-arrow-up"></i> Upload Documents</a></li>
        <li><a href="cv_manager.php"><i class="fa-solid fa-file-invoice"></i> Build & Upload CV</a></li>
        <li><a href="opportunities.php"><i class="fa-solid fa-building-user"></i> View Vacancies</a></li>
        <li><a href="applications.php"><i class="fa-solid fa-route"></i> My Applications</a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> Change Password</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="app-header-bar">
        <div class="header-title-left">Placement Dispatch Center</div>
        <div class="header-controls-right">
            <div class="bell-dropdown-wrapper">
                <button class="bell-trigger-btn"><i class="fa-solid fa-bell"></i>
                    <?php if($unread_notifications_count > 0): ?><span class="bell-badge-counter"><?php echo $unread_notifications_count; ?></span><?php endif; ?>
                </button>
                <div class="bell-overlay-panel">
                    <div class="bell-panel-header">System Alerts Logs</div>
                    <div class="bell-feed-scroll">
                        <?php if(empty($recent_notifications)): ?><div style="padding:15px; text-align:center; font-size:0.8rem; color:var(--muted-text);">No alerts indexed.</div>
                        <?php else: foreach($recent_notifications as $notif): ?>
                            <a href="notifications.php" class="bell-item-row">
                                <h6><?php echo htmlspecialchars($notif['title']); ?></h6>
                                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                <span><i class="fa-regular fa-clock"></i> <?php echo date('M d, g:i A', strtotime($notif['created_at'])); ?></span>
                            </a>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>

            <div class="user-profile-dropdown-wrapper">
                <div class="user-identity-block">
                    <div class="user-info-text"><h4>Surya</h4></div>
                    <span class="track-indicator"><?php echo htmlspecialchars($placement_type); ?></span>
                    <?php if(!empty($profile_pic) && file_exists($profile_pic)): ?>
                        <img src="<?php echo htmlspecialchars($profile_pic); ?>" alt="Avatar" class="profile-circle-avatar">
                    <?php else: ?>
                        <div class="profile-circle-avatar"><i class="fa-solid fa-user"></i></div>
                    <?php endif; ?>
                </div>
                <div class="profile-settings-overlay">
                    <label for="ajax_profile_pic"><i class="fa-solid fa-camera"></i> Upload Picture</label>
                    <a href="settings.php"><i class="fa-solid fa-key"></i> Security Settings</a>
                    <a href="../logout.php" class="logout-divider"><i class="fa-solid fa-power-off"></i> Sign Out</a>
                </div>
            </div>
        </div>
    </div>

    <?php if ($allocation): ?>
        <div class="control-panel-box">
            <div>
                <h4 style="margin:0 0 4px 0;">Official Allocation Document Ready</h4>
                <p style="margin:0; font-size:0.82rem; color:var(--muted-text);">Your allocation configuration records are loaded. Print via system hardware channels.</p>
            </div>
            <button onclick="window.print();" class="btn-print-letter"><i class="fa-solid fa-print"></i> Print Letter</button>
        </div>

        <div id="printable-letter-sheet">
            <div class="letter-crest-header">
                <h1>CAREERCONNECT PLACEMENT SYSTEMS AUTHORITY</h1>
                <p>Directorate of Industrial Field Studies & Career Placements</p>
                <p style="font-size: 0.75rem; font-weight: normal;">P.O. Box 35091, Dar es Salaam, Tanzania</p>
            </div>

            <div class="letter-meta-row">
                <div style="line-height: 1.5; font-weight: 600;">
                    Ref: CC/POST/<?php echo date('Y'); ?>/ST-<?php echo $student_id; ?><br>
                    To: The Human Resources Manager,<br>
                    <strong><?php echo htmlspecialchars($allocation['company_name'] ?? 'N/A'); ?></strong><br>
                    <?php echo htmlspecialchars($allocation['company_phone'] ?? ''); ?><br>
                    <?php echo htmlspecialchars($allocation['company_email'] ?? ''); ?>
                </div>
                <div style="text-align: right; font-weight: 600;">
                    Date: <?php echo date('F d, Y', strtotime($allocation['allocation_date'])); ?>
                </div>
            </div>

            <div class="letter-subject-line">
                SUBJECT: PLACEMENT FOR UNIVERSITY INDUSTRIAL FIELD STUDY & <?php echo strtoupper($placement_type); ?>
            </div>

            <div class="letter-body-prose">
                <p>Dear Sir/Madam,</p>
                <p>We are pleased to introduce <strong><?php echo htmlspecialchars($student_name); ?></strong>, a registered student under our academic ecosystem. Following rigorous internal evaluations, the student has been officially matched and deployed to your organization for the role of <strong><?php echo htmlspecialchars($allocation['job_title']); ?></strong>.</p>
                <p>The attachment period is calculated to meet mandatory industrial curriculum timelines. We kindly request that you accord the student necessary administrative access and mentorship parameters as required to execute assignments optimally.</p>
                <p>Thank you for your ongoing alliance in building robust professional capacities for tomorrow's technology frameworks.</p>
            </div>

            <div class="letter-sign-off">
                <p>Yours Sincerely,</p>
                <div class="signature-placeholder"></div>
                <p style="margin:0; font-weight:800;">Prof. Alistair Vance</p>
                <p style="margin:0; font-size:0.85rem; color:#64748B;">Director of Placement Systems Board, CareerConnect</p>
            </div>
        </div>
    <?php else: ?>
        <div class="empty-allocation-notice">
            <i class="fa-solid fa-folder-open" style="font-size: 3rem; color: var(--muted-text); margin-bottom: 15px;"></i>
            <h3>No Active Allocations Found</h3>
            <p style="max-width: 500px; margin: 0 auto 20px auto; color: var(--muted-text);">Your application credentials are either still pending processing stages or have not been updated by organizational entities yet.</p>
            <a href="applications.php" class="btn-print-letter" style="background: var(--softcare-blue);"><i class="fa-solid fa-arrow-left"></i> Check Application Status</a>
        </div>
    <?php endif; ?>
</div>

</body>
</html>