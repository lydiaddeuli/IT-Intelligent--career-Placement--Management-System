<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

// Fetch student details
$stmt = $pdo->prepare("SELECT full_name, email FROM users WHERE user_id = ?");
$stmt->execute([$student_id]);
$user = $stmt->fetch();
$student_name = $user['full_name'] ?? 'Student';
$student_email = $user['email'] ?? '';

// Fetch student profile data
$stmt = $pdo->prepare("SELECT * FROM student_profiles WHERE student_id = ?");
$stmt->execute([$student_id]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

$track = $profile['placement_type'] ?? 'Internship';
$profile_pic = $profile['profile_pic'] ?? '';
$student_avatar = !empty($profile_pic) ? '../' . $profile_pic : 'https://ui-avatars.com/api/?name=' . urlencode($student_name) . '&background=0091DF&color=fff&size=40';

$success_msg = "";
$error_msg = "";
$skipped_fields = [];

// Get existing columns
$columns_stmt = $pdo->query("SHOW COLUMNS FROM student_profiles");
$existing_columns = $columns_stmt->fetchAll(PDO::FETCH_COLUMN);

function safe_column($column, $columns) {
    return in_array(strtolower($column), array_map('strtolower', $columns));
}

// Handle CV Data Save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_cv'])) {
    try {
        $update_fields = [];
        $params = [];
        
        $field_map = [
            'phone' => trim($_POST['phone']),
            'address' => trim($_POST['address']),
            'summary' => trim($_POST['summary']),
            'education' => trim($_POST['education']),
            'projects' => trim($_POST['projects']),
            'technical_skills' => trim($_POST['technical_skills']),
            'soft_skills' => trim($_POST['soft_skills']),
            'experience' => trim($_POST['experience']),
            'gender' => trim($_POST['gender']),
            'languages' => trim($_POST['languages']),
            'awards' => trim($_POST['awards']),
            'certifications' => trim($_POST['certifications'])
        ];
        
        foreach ($field_map as $field => $value) {
            if (safe_column($field, $existing_columns)) {
                $update_fields[] = "$field = ?";
                $params[] = $value;
            } else {
                $skipped_fields[] = $field;
            }
        }
        
        if (empty($update_fields)) {
            $error_msg = "No valid columns found to update.";
        } else {
            $check = $pdo->prepare("SELECT student_id FROM student_profiles WHERE student_id = ?");
            $check->execute([$student_id]);

            if ($check->fetch()) {
                $sql = "UPDATE student_profiles SET " . implode(", ", $update_fields) . " WHERE student_id = ?";
                $params[] = $student_id;
                $update = $pdo->prepare($sql);
                $update->execute($params);
            } else {
                $fields = array_keys($field_map);
                $values = array_values($field_map);
                array_unshift($fields, 'student_id');
                array_unshift($values, $student_id);
                
                $valid_fields = [];
                $valid_values = [];
                foreach ($fields as $i => $field) {
                    if ($field == 'student_id' || safe_column($field, $existing_columns)) {
                        $valid_fields[] = $field;
                        $valid_values[] = $values[$i];
                    }
                }
                
                if (!empty($valid_fields)) {
                    $sql = "INSERT INTO student_profiles (" . implode(", ", $valid_fields) . ") VALUES (" . implode(", ", array_fill(0, count($valid_values), '?')) . ")";
                    $insert = $pdo->prepare($sql);
                    $insert->execute($valid_values);
                }
            }

            $success_msg = "CV saved successfully!";
            if (!empty($skipped_fields)) {
                $success_msg .= " Note: these fields were NOT saved because their columns don't exist in student_profiles: " . implode(', ', $skipped_fields) . ".";
            }
            
            $stmt = $pdo->prepare("SELECT * FROM student_profiles WHERE student_id = ?");
            $stmt->execute([$student_id]);
            $profile = $stmt->fetch(PDO::FETCH_ASSOC);
        }

    } catch (PDOException $e) {
        $error_msg = "Error saving CV: " . $e->getMessage();
    }
}

// Handle Clear CV
if (isset($_GET['clear']) && $_GET['clear'] == 1) {
    try {
        $clear_fields = [];
        $clearable_fields = ['phone', 'address', 'summary', 'education', 'projects', 
                             'technical_skills', 'soft_skills', 'experience', 
                             'gender', 'languages', 'awards', 'certifications'];
        
        foreach ($clearable_fields as $field) {
            if (safe_column($field, $existing_columns)) {
                $clear_fields[] = "$field = NULL";
            }
        }
        
        if (!empty($clear_fields)) {
            $sql = "UPDATE student_profiles SET " . implode(", ", $clear_fields) . " WHERE student_id = ?";
            $update = $pdo->prepare($sql);
            $update->execute([$student_id]);
        }
    } catch (PDOException $e) {
        // fall through to redirect with an error flag
    }
    header("Location: cv_manager.php?cleared=1");
    exit();
}

if (isset($_GET['cleared']) && $_GET['cleared'] == 1) {
    $success_msg = "CV data cleared successfully!";
}

// Fetch notifications
$notif_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_notifications WHERE student_id = ? AND is_read = 0");
$notif_stmt->execute([$student_id]);
$unread_count = $notif_stmt->fetchColumn();

$feed_stmt = $pdo->prepare("SELECT title, message, created_at FROM student_notifications WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
$feed_stmt->execute([$student_id]);
$recent_notifications = $feed_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Builder | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- ===== CHANGE 1: Add html2pdf.js library for PDF download ===== -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
            --cv-blue: #1a3a5c;
            --cv-gold: #c9a84c;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }

        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            margin-bottom: 30px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-radius: 12px; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
            box-shadow: 0 4px 14px rgba(0, 145, 223, 0.25);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .bell-dropdown-wrapper {
            position: relative;
            display: inline-block;
        }

        .bell-trigger-btn {
            background: none;
            border: none;
            color: var(--white);
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            padding: 5px;
            display: flex;
            align-items: center;
        }
        .bell-trigger-btn:hover { opacity: 0.85; }

        .bell-badge-counter {
            position: absolute;
            top: 0px;
            right: -2px;
            background: var(--alert-red);
            color: var(--white);
            font-size: 0.62rem;
            font-weight: 800;
            min-width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--softcare-blue);
        }

        .bell-overlay-panel {
            display: none;
            position: absolute;
            right: -10px;
            top: 140%;
            background: var(--white);
            min-width: 320px;
            max-width: 360px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            border-radius: 10px;
            border: 1px solid var(--border-light);
            z-index: 500;
            overflow: hidden;
        }
        .bell-dropdown-wrapper:hover .bell-overlay-panel { display: block; }

        .bell-panel-header {
            background: var(--milky-white);
            padding: 12px 16px;
            font-size: 0.82rem;
            font-weight: 800;
            color: var(--dark-text);
            border-bottom: 1px solid var(--border-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .bell-feed-scroll { max-height: 280px; overflow-y: auto; }
        
        .bell-item-row {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.15s;
            text-decoration: none;
            display: block;
        }
        .bell-item-row:last-child { border-bottom: none; }
        .bell-item-row:hover { background: var(--softcare-light-blue); }
        .bell-item-row h6 { margin: 0 0 3px 0; font-size: 0.82rem; color: var(--dark-text); font-weight: 700; }
        .bell-item-row p { margin: 0; font-size: 0.76rem; color: var(--muted-text); line-height: 1.35; }
        .bell-item-row span { font-size: 0.68rem; color: #94A3B8; display: block; margin-top: 4px; }
        .bell-empty-state { padding: 20px; text-align: center; color: var(--muted-text); font-size: 0.85rem; }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .student-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .student-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            overflow: hidden;
        }

        .header-dropdown-card.show {
            display: block;
        }

        .dropdown-user-info {
            padding: 16px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.92rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.72rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li {
            display: block;
        }

        .dropdown-menu-list li a,
        .dropdown-menu-list li label {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            transition: 0.2s;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
            border: none;
            background: none;
            font-family: inherit;
            text-align: left;
        }

        .dropdown-menu-list li a:hover,
        .dropdown-menu-list li label:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        /* CV Builder Layout */
        .cv-builder-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .cv-form-card {
            background: var(--white);
            border-radius: 12px;
            border: 1px solid var(--border-light);
            padding: 28px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
        }

        .cv-form-card h3 {
            margin: 0 0 4px 0;
            font-size: 1.1rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .cv-form-card .subtitle {
            color: var(--muted-text);
            font-size: 0.82rem;
            margin: 0 0 20px 0;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 700;
            color: var(--dark-text);
            margin-bottom: 4px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        .form-group label i {
            margin-right: 6px;
            color: var(--softcare-blue);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border-light);
            border-radius: 8px;
            font-size: 0.9rem;
            background: var(--milky-white);
            transition: border-color 0.2s;
            font-family: inherit;
            box-sizing: border-box;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--softcare-blue);
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 70px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .btn-save {
            background: var(--softcare-blue);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.95rem;
            cursor: pointer;
            transition: background 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            justify-content: center;
            margin-top: 10px;
        }

        .btn-save:hover {
            background: #0077b6;
        }

        /* ====== PROFESSIONAL CV PREVIEW STYLES ====== */
        .cv-preview-card {
            background: var(--white);
            border-radius: 12px;
            border: 1px solid var(--border-light);
            padding: 28px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
            position: sticky;
            top: 90px;
        }

        .cv-preview-card .preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border-light);
            flex-wrap: wrap;
            gap: 10px;
        }

        .cv-preview-card .preview-header h3 {
            margin: 0;
            font-size: 1.05rem;
            font-weight: 800;
        }

        .cv-preview-card .preview-header .preview-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-preview-action {
            padding: 6px 14px;
            border: none;
            border-radius: 6px;
            font-weight: 700;
            font-size: 0.78rem;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
        }

        .btn-preview-action.print {
            background: var(--dark-text);
            color: white;
        }
        .btn-preview-action.print:hover {
            background: var(--pure-black);
        }

        .btn-preview-action.download {
            background: var(--softcare-blue);
            color: white;
        }
        .btn-preview-action.download:hover {
            background: #0077b6;
        }

        .btn-preview-action.clear {
            background: #FEF2F2;
            color: var(--alert-red);
        }
        .btn-preview-action.clear:hover {
            background: #FEE2E2;
        }

        /* ====== PROFESSIONAL CV CONTENT ====== */
        #cv-preview-content {
            background: #ffffff;
            padding: 0;
            border: 1px solid #e8e8e8;
            border-radius: 4px;
            min-height: 500px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow: hidden;
        }

        .cv-header {
            background: var(--cv-blue);
            color: white;
            padding: 30px 35px 20px 35px;
            position: relative;
        }

        .cv-header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--cv-gold);
        }

        .cv-name {
            font-size: 28px;
            font-weight: 700;
            letter-spacing: 1px;
            margin: 0 0 6px 0;
            color: white;
        }

        .cv-contact-row {
            display: flex;
            flex-wrap: wrap;
            gap: 18px;
            font-size: 13px;
            color: rgba(255,255,255,0.85);
            margin-top: 4px;
        }

        .cv-contact-row span {
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .cv-contact-row i {
            font-size: 12px;
            color: var(--cv-gold);
        }

        .cv-body {
            padding: 25px 35px 30px 35px;
        }

        .cv-section-title {
            font-size: 15px;
            font-weight: 700;
            color: var(--cv-blue);
            text-transform: uppercase;
            letter-spacing: 0.8px;
            border-bottom: 2px solid var(--cv-gold);
            padding-bottom: 4px;
            margin: 0 0 12px 0;
        }

        .cv-section {
            margin-bottom: 20px;
        }

        .cv-section:last-child {
            margin-bottom: 0;
        }

        .cv-summary-text {
            font-size: 13.5px;
            line-height: 1.7;
            color: #333;
            margin: 0;
        }

        .cv-experience-item {
            margin-bottom: 14px;
        }

        .cv-experience-item:last-child {
            margin-bottom: 0;
        }

        .cv-exp-header {
            display: flex;
            justify-content: space-between;
            align-items: baseline;
            flex-wrap: wrap;
            gap: 4px;
        }

        .cv-exp-title {
            font-size: 14px;
            font-weight: 700;
            color: var(--cv-blue);
            margin: 0;
        }

        .cv-exp-company {
            font-size: 13px;
            font-weight: 600;
            color: #555;
        }

        .cv-exp-date {
            font-size: 12px;
            color: #888;
            font-weight: 500;
        }

        .cv-exp-desc {
            font-size: 13px;
            line-height: 1.6;
            color: #444;
            margin: 4px 0 0 0;
            padding-left: 0;
        }

        .cv-exp-desc li {
            margin-bottom: 3px;
        }

        .cv-skills-list {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .cv-skill-tag {
            background: var(--milky-white);
            border: 1px solid #e0e0e0;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 12.5px;
            font-weight: 600;
            color: #444;
        }

        .cv-skill-tag:hover {
            border-color: var(--cv-gold);
            background: #faf8f0;
        }

        .cv-edu-item {
            margin-bottom: 10px;
        }

        .cv-edu-item:last-child {
            margin-bottom: 0;
        }

        .cv-edu-title {
            font-size: 14px;
            font-weight: 700;
            color: var(--cv-blue);
            margin: 0;
        }

        .cv-edu-school {
            font-size: 13px;
            color: #555;
            font-weight: 500;
        }

        .cv-edu-date {
            font-size: 12px;
            color: #888;
        }

        .cv-edu-desc {
            font-size: 13px;
            color: #444;
            margin: 2px 0 0 0;
        }

        .cv-awards-list,
        .cv-cert-list {
            display: flex;
            flex-wrap: wrap;
            gap: 6px 16px;
        }

        .cv-award-item,
        .cv-cert-item {
            font-size: 13px;
            color: #444;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .cv-award-item i,
        .cv-cert-item i {
            color: var(--cv-gold);
            font-size: 11px;
        }

        .cv-languages-list {
            display: flex;
            flex-wrap: wrap;
            gap: 6px 16px;
        }

        .cv-language-item {
            font-size: 13px;
            color: #444;
        }

        .cv-project-item {
            margin-bottom: 10px;
        }

        .cv-project-item:last-child {
            margin-bottom: 0;
        }

        .cv-project-title {
            font-size: 14px;
            font-weight: 700;
            color: var(--cv-blue);
            margin: 0;
        }

        .cv-project-desc {
            font-size: 13px;
            color: #444;
            margin: 2px 0 0 0;
        }

        .empty-preview {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted-text);
        }

        .empty-preview i {
            font-size: 2.5rem;
            color: var(--border-light);
            display: block;
            margin-bottom: 12px;
        }

        .empty-preview h4 {
            margin: 0 0 5px 0;
            color: var(--dark-text);
        }

        @media print {
            body * {
                visibility: hidden;
            }
            
            #cv-preview-content,
            #cv-preview-content * {
                visibility: visible;
            }
            
            #cv-preview-content {
                position: fixed;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                border: none;
                border-radius: 0;
                padding: 0;
                margin: 0;
                z-index: 9999;
                background: white;
                box-shadow: none;
            }

            .cv-header {
                padding: 25px 30px 15px 30px;
            }

            .cv-body {
                padding: 20px 30px 25px 30px;
            }

            .cv-section {
                margin-bottom: 14px;
            }

            .cv-section-title {
                font-size: 13px;
                margin-bottom: 8px;
            }

            .cv-name {
                font-size: 24px;
            }

            .cv-contact-row {
                font-size: 12px;
                gap: 14px;
            }

            .cv-exp-title {
                font-size: 13px;
            }

            .cv-exp-desc {
                font-size: 12px;
            }

            .cv-skill-tag {
                font-size: 11px;
                padding: 3px 12px;
            }

            .cv-summary-text {
                font-size: 12.5px;
            }
        }

        @media (max-width: 992px) {
            .cv-builder-grid {
                grid-template-columns: 1fr;
            }
            .cv-preview-card {
                position: relative;
                top: 0;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .main-content { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active-page { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .app-header-bar { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .student-name { font-size: 0.75rem; max-width: 80px; }
            .student-avatar-circle { width: 28px; height: 28px; }
            .page-content { padding: 16px; }
            .cv-form-card { padding: 20px; }
            .cv-preview-card { padding: 20px; }
            .cv-header { padding: 20px 20px 14px 20px; }
            .cv-body { padding: 18px 20px 22px 20px; }
            .cv-name { font-size: 22px; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
        }

        @media (max-width: 576px) {
            .sidebar { width: 60px; }
            .main-content { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .app-header-bar { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .student-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .student-avatar-circle { width: 26px; height: 26px; }
            .page-content { padding: 12px; }
            .cv-form-card { padding: 16px; }
            .cv-preview-card { padding: 16px; }
            .cv-header { padding: 16px 16px 10px 16px; }
            .cv-body { padding: 14px 16px 18px 16px; }
            .cv-name { font-size: 18px; }
            .cv-contact-row { font-size: 11px; gap: 10px; flex-wrap: wrap; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<!-- Hidden form for avatar upload -->
<form id="avatarUploadForm" action="dashboard.php" method="POST" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="ajax_profile_pic" name="ajax_profile_pic" accept="image/*" onchange="document.getElementById('avatarUploadForm').submit();">
</form>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-user-circle"></i> <span>My Profile</span></a></li>
        <li><a href="upload_docs.php"><i class="fa-solid fa-cloud-arrow-up"></i> <span>Upload Documents</span></a></li>
        <li><a href="cv_manager.php" class="active-page"><i class="fa-solid fa-file-invoice"></i> <span>Build & Upload CV</span></a></li>
        <li><a href="opportunities.php"><i class="fa-solid fa-building-user"></i> <span>View Vacancies</span></a></li>
        <li><a href="applications.php"><i class="fa-solid fa-route"></i> <span>My Applications</span></a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> <span>Change Password</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-file-invoice"></i> CV Builder
            </div>
        </div>
        
        <div class="header-right">
            <div class="bell-dropdown-wrapper">
                <button class="bell-trigger-btn" title="System Alerts">
                    <i class="fa-solid fa-bell"></i>
                    <?php if($unread_count > 0): ?>
                        <span class="bell-badge-counter"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </button>
                <div class="bell-overlay-panel">
                    <div class="bell-panel-header">System Alerts</div>
                    <div class="bell-feed-scroll">
                        <?php if(empty($recent_notifications)): ?>
                            <div class="bell-empty-state">No real-time alert updates indexed.</div>
                        <?php else: foreach($recent_notifications as $notif): ?>
                            <a href="notifications.php" class="bell-item-row">
                                <h6><?php echo htmlspecialchars($notif['title']); ?></h6>
                                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                <span><i class="fa-regular fa-clock"></i> <?php echo date('M d, g:i A', strtotime($notif['created_at'])); ?></span>
                            </a>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>

            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $student_avatar; ?>" alt="Profile" class="student-avatar-circle">
                <span class="student-name"><?php echo htmlspecialchars($student_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($student_name); ?></h5>
                    <p><?php echo htmlspecialchars($track); ?></p>
                </div>
                <ul class="dropdown-menu-list">
                    <li>
                        <label for="ajax_profile_pic">
                            <i class="fa-solid fa-camera"></i> Upload Picture
                        </label>
                    </li>
                    <li>
                        <a href="../logout.php" class="logout-item">
                            <i class="fa-solid fa-right-from-bracket"></i> Sign Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <?php if(!empty($success_msg)): ?>
            <div class="alert-success"><i class="fa-solid fa-circle-check"></i> <?php echo $success_msg; ?></div>
        <?php endif; ?>
        <?php if(!empty($error_msg)): ?>
            <div class="alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?php echo $error_msg; ?></div>
        <?php endif; ?>

        <div class="cv-builder-grid">
            <!-- Left: CV Form -->
            <div class="cv-form-card">
                <h3><i class="fa-solid fa-pen-to-square" style="color:var(--softcare-blue);"></i> CV Information</h3>
                <p class="subtitle">Fill in your details to build your professional CV.</p>

                <form method="POST" action="cv_manager.php">
                    <!-- Personal Information -->
                    <div class="form-group">
                        <label><i class="fa-regular fa-user"></i> Full Name</label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($student_name); ?>" readonly style="background:#F1F5F9;color:var(--muted-text);">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fa-regular fa-envelope"></i> Email</label>
                            <input type="email" name="email" value="<?php echo htmlspecialchars($student_email); ?>" readonly style="background:#F1F5F9;color:var(--muted-text);">
                        </div>
                        <div class="form-group">
                            <label><i class="fa-regular fa-phone"></i> Phone</label>
                            <input type="text" name="phone" value="<?php echo htmlspecialchars($profile['phone'] ?? ''); ?>" placeholder="+255 712 345 678">
                        </div>
                    </div>

                    <div class="form-group">
                        <label><i class="fa-regular fa-location-dot"></i> Address</label>
                        <input type="text" name="address" value="<?php echo htmlspecialchars($profile['address'] ?? ''); ?>" placeholder="City, Country">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fa-regular fa-venus-mars"></i> Gender</label>
                            <select name="gender">
                                <option value="">Select</option>
                                <option value="Male" <?php echo (($profile['gender'] ?? '') == 'Male') ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo (($profile['gender'] ?? '') == 'Female') ? 'selected' : ''; ?>>Female</option>
                                <option value="Other" <?php echo (($profile['gender'] ?? '') == 'Other') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fa-regular fa-language"></i> Languages</label>
                            <input type="text" name="languages" value="<?php echo htmlspecialchars($profile['languages'] ?? ''); ?>" placeholder="English, Swahili, French">
                        </div>
                    </div>

                    <!-- Professional Summary -->
                    <div class="form-group">
                        <label><i class="fa-regular fa-file-lines"></i> Professional Summary</label>
                        <textarea name="summary" rows="3" placeholder="Write a brief professional summary..."><?php echo htmlspecialchars($profile['summary'] ?? ''); ?></textarea>
                    </div>

                    <!-- Education -->
                    <div class="form-group">
                        <label><i class="fa-regular fa-graduation-cap"></i> Education</label>
                        <textarea name="education" rows="3" placeholder="List your education history..."><?php echo htmlspecialchars($profile['education'] ?? ''); ?></textarea>
                    </div>

                    <!-- Technical Skills -->
                    <div class="form-group">
                        <label><i class="fa-solid fa-code"></i> Technical Skills</label>
                        <textarea name="technical_skills" rows="3" placeholder="e.g. PHP, JavaScript, MySQL, React, Python..."><?php echo htmlspecialchars($profile['technical_skills'] ?? ''); ?></textarea>
                    </div>

                    <!-- Soft Skills -->
                    <div class="form-group">
                        <label><i class="fa-regular fa-handshake"></i> Soft Skills</label>
                        <textarea name="soft_skills" rows="2" placeholder="e.g. Teamwork, Communication, Leadership..."><?php echo htmlspecialchars($profile['soft_skills'] ?? ''); ?></textarea>
                    </div>

                    <!-- Experience -->
                    <div class="form-group">
                        <label><i class="fa-regular fa-briefcase"></i> Experience</label>
                        <textarea name="experience" rows="3" placeholder="List your work experience..."><?php echo htmlspecialchars($profile['experience'] ?? ''); ?></textarea>
                    </div>

                    <!-- Projects -->
                    <div class="form-group">
                        <label><i class="fa-regular fa-folder-open"></i> Projects</label>
                        <textarea name="projects" rows="3" placeholder="List your projects..."><?php echo htmlspecialchars($profile['projects'] ?? ''); ?></textarea>
                    </div>

                    <!-- Awards & Certifications -->
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fa-regular fa-trophy"></i> Awards</label>
                            <input type="text" name="awards" value="<?php echo htmlspecialchars($profile['awards'] ?? ''); ?>" placeholder="Awards & Recognition">
                        </div>
                        <div class="form-group">
                            <label><i class="fa-regular fa-certificate"></i> Certifications</label>
                            <input type="text" name="certifications" value="<?php echo htmlspecialchars($profile['certifications'] ?? ''); ?>" placeholder="Certifications">
                        </div>
                    </div>

                    <button type="submit" name="save_cv" class="btn-save">
                        <i class="fa-regular fa-floppy-disk"></i> Save CV
                    </button>
                </form>
            </div>

            <!-- Right: CV Preview -->
            <div class="cv-preview-card">
                <!-- ===== CHANGE 3: Updated buttons - Download PDF + Print separated ===== -->
                <div class="preview-header">
                    <h3><i class="fa-solid fa-eye" style="color:var(--softcare-blue);"></i> CV Preview</h3>
                    <div class="preview-actions">
                        <button onclick="downloadCV()" class="btn-preview-action download download-btn">
                            <i class="fa-solid fa-download"></i> Download PDF
                        </button>
                        <button onclick="printCV()" class="btn-preview-action print">
                            <i class="fa-solid fa-print"></i> Print
                        </button>
                        <a href="?clear=1" class="btn-preview-action clear" onclick="return confirm('Are you sure you want to clear your CV data?')">
                            <i class="fa-regular fa-trash-can"></i> Clear
                        </a>
                    </div>
                </div>

                <div id="cv-preview-content">
                    <?php
                    // Get profile data
                    $name = $student_name;
                    $email = $student_email;
                    $phone = $profile['phone'] ?? '';
                    $address = $profile['address'] ?? '';
                    $gender = $profile['gender'] ?? '';
                    $languages = $profile['languages'] ?? '';
                    $summary = $profile['summary'] ?? '';
                    $education = $profile['education'] ?? '';
                    $technical_skills = $profile['technical_skills'] ?? '';
                    $soft_skills = $profile['soft_skills'] ?? '';
                    $experience = $profile['experience'] ?? '';
                    $projects = $profile['projects'] ?? '';
                    $awards = $profile['awards'] ?? '';
                    $certifications = $profile['certifications'] ?? '';
                    
                    $has_data = !empty($summary) || !empty($education) || !empty($technical_skills)
                        || !empty($soft_skills) || !empty($experience) || !empty($projects)
                        || !empty($phone) || !empty($address) || !empty($gender)
                        || !empty($languages) || !empty($awards) || !empty($certifications);
                    ?>

                    <?php if ($has_data): ?>
                        <!-- PROFESSIONAL CV HEADER -->
                        <div class="cv-header">
                            <div class="cv-name"><?php echo htmlspecialchars($name); ?></div>
                            <div class="cv-contact-row">
                                <?php if(!empty($email)): ?>
                                    <span><i class="fa-regular fa-envelope"></i> <?php echo htmlspecialchars($email); ?></span>
                                <?php endif; ?>
                                <?php if(!empty($phone)): ?>
                                    <span><i class="fa-regular fa-phone"></i> <?php echo htmlspecialchars($phone); ?></span>
                                <?php endif; ?>
                                <?php if(!empty($address)): ?>
                                    <span><i class="fa-regular fa-location-dot"></i> <?php echo htmlspecialchars($address); ?></span>
                                <?php endif; ?>
                                <?php if(!empty($gender)): ?>
                                    <span><i class="fa-regular fa-venus-mars"></i> <?php echo htmlspecialchars($gender); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- PROFESSIONAL CV BODY -->
                        <div class="cv-body">
                            <!-- Summary -->
                            <?php if(!empty($summary)): ?>
                                <div class="cv-section">
                                    <div class="cv-section-title">Summary</div>
                                    <p class="cv-summary-text"><?php echo nl2br(htmlspecialchars($summary)); ?></p>
                                </div>
                            <?php endif; ?>

                            <!-- Experience -->
                            <?php if(!empty($experience)): ?>
                                <div class="cv-section">
                                    <div class="cv-section-title">Professional Experience</div>
                                    <?php 
                                    $exp_items = explode("\n", $experience);
                                    foreach($exp_items as $item):
                                        $item = trim($item);
                                        if(!empty($item)):
                                    ?>
                                        <div class="cv-experience-item">
                                            <div class="cv-exp-header">
                                                <span class="cv-exp-title"><?php echo nl2br(htmlspecialchars($item)); ?></span>
                                            </div>
                                        </div>
                                    <?php 
                                        endif;
                                    endforeach; 
                                    ?>
                                </div>
                            <?php endif; ?>

                            <!-- Education -->
                            <?php if(!empty($education)): ?>
                                <div class="cv-section">
                                    <div class="cv-section-title">Education</div>
                                    <?php 
                                    $edu_items = explode("\n", $education);
                                    foreach($edu_items as $item):
                                        $item = trim($item);
                                        if(!empty($item)):
                                    ?>
                                        <div class="cv-edu-item">
                                            <div class="cv-edu-title"><?php echo nl2br(htmlspecialchars($item)); ?></div>
                                        </div>
                                    <?php 
                                        endif;
                                    endforeach; 
                                    ?>
                                </div>
                            <?php endif; ?>

                            <!-- Technical Skills -->
                            <?php if(!empty($technical_skills)): ?>
                                <div class="cv-section">
                                    <div class="cv-section-title">Technical Skills</div>
                                    <div class="cv-skills-list">
                                        <?php 
                                        $skills = explode(',', $technical_skills);
                                        foreach($skills as $skill):
                                            $skill = trim($skill);
                                            if(!empty($skill)):
                                        ?>
                                            <span class="cv-skill-tag"><?php echo htmlspecialchars($skill); ?></span>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Soft Skills -->
                            <?php if(!empty($soft_skills)): ?>
                                <div class="cv-section">
                                    <div class="cv-section-title">Soft Skills</div>
                                    <div class="cv-skills-list">
                                        <?php 
                                        $skills = explode(',', $soft_skills);
                                        foreach($skills as $skill):
                                            $skill = trim($skill);
                                            if(!empty($skill)):
                                        ?>
                                            <span class="cv-skill-tag"><?php echo htmlspecialchars($skill); ?></span>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Projects -->
                            <?php if(!empty($projects)): ?>
                                <div class="cv-section">
                                    <div class="cv-section-title">Projects</div>
                                    <?php 
                                    $proj_items = explode("\n", $projects);
                                    foreach($proj_items as $item):
                                        $item = trim($item);
                                        if(!empty($item)):
                                    ?>
                                        <div class="cv-project-item">
                                            <div class="cv-project-title"><?php echo nl2br(htmlspecialchars($item)); ?></div>
                                        </div>
                                    <?php 
                                        endif;
                                    endforeach; 
                                    ?>
                                </div>
                            <?php endif; ?>

                            <!-- Languages -->
                            <?php if(!empty($languages)): ?>
                                <div class="cv-section">
                                    <div class="cv-section-title">Languages</div>
                                    <div class="cv-languages-list">
                                        <?php 
                                        $langs = explode(',', $languages);
                                        foreach($langs as $lang):
                                            $lang = trim($lang);
                                            if(!empty($lang)):
                                        ?>
                                            <span class="cv-language-item"><?php echo htmlspecialchars($lang); ?></span>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Awards & Certifications -->
                            <?php if(!empty($awards) || !empty($certifications)): ?>
                                <div class="cv-section">
                                    <div class="cv-section-title">Awards & Certifications</div>
                                    <div class="cv-awards-list">
                                        <?php if(!empty($awards)): ?>
                                            <?php 
                                            $award_items = explode(',', $awards);
                                            foreach($award_items as $item):
                                                $item = trim($item);
                                                if(!empty($item)):
                                            ?>
                                                <span class="cv-award-item"><i class="fa-regular fa-star"></i> <?php echo htmlspecialchars($item); ?></span>
                                            <?php 
                                                endif;
                                            endforeach; 
                                            ?>
                                        <?php endif; ?>
                                        <?php if(!empty($certifications)): ?>
                                            <?php 
                                            $cert_items = explode(',', $certifications);
                                            foreach($cert_items as $item):
                                                $item = trim($item);
                                                if(!empty($item)):
                                            ?>
                                                <span class="cv-cert-item"><i class="fa-regular fa-certificate"></i> <?php echo htmlspecialchars($item); ?></span>
                                            <?php 
                                                endif;
                                            endforeach; 
                                            ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-preview">
                            <i class="fa-regular fa-file-lines"></i>
                            <h4 style="margin:0 0 5px 0;color:var(--dark-text);">No CV Data Yet</h4>
                            <p>Fill in the form on the left and click "Save CV" to preview your professional CV.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ===== CHANGE 2: Replace printCV() with printCV() + downloadCV() ===== -->
<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('profileDropdown');
    const trigger = document.querySelector('.profile-trigger-zone');
    if (!trigger.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});

function printCV() {
    window.print();
}

function downloadCV() {
    const element = document.getElementById('cv-preview-content');
    
    // Check if CV has data
    if (!element || element.querySelector('.empty-preview')) {
        alert('Please fill in and save your CV data before downloading.');
        return;
    }

    const studentName = '<?php echo addslashes(htmlspecialchars($student_name)); ?>';
    const filename = studentName.replace(/\s+/g, '_') + '_CV.pdf';

    const opt = {
        margin:       [8, 8, 8, 8],
        filename:     filename,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { 
            scale: 2, 
            useCORS: true,
            letterRendering: true,
            scrollX: 0,
            scrollY: 0
        },
        jsPDF:        { 
            unit: 'mm', 
            format: 'a4', 
            orientation: 'portrait' 
        }
    };

    // Show loading state on button
    const btn = document.querySelector('.download-btn');
    const originalHTML = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Generating...';
    btn.disabled = true;

    html2pdf().set(opt).from(element).save().then(function() {
        // Restore button after download
        btn.innerHTML = originalHTML;
        btn.disabled = false;
    });
}
</script>
</body>
</html>