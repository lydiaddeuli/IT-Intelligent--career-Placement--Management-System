<?php
session_start();
include('../includes/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $opp_id = $_POST['opp_id']; 
    $student_id = $_SESSION['user_id'];
    $cover_letter = $_POST['cover_letter'];

    try {
        $sql = "INSERT INTO applications (opportunity_id, student_id, cover_letter, status, applied_at) VALUES (?, ?, ?, 'Pending', NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$opp_id, $student_id, $cover_letter]);
        
        // Set a success message in session
        $_SESSION['apply_success'] = "Application submitted successfully!";
        
        header("Location: apply.php"); // Redirect back to apply page
        exit();
        
   } catch (Exception $e) {
        die("Error: " . $e->getMessage()); 
   }
}
?>