<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

// Fetch student details for header
$stmt = $pdo->prepare("SELECT full_name FROM users WHERE user_id = ?");
$stmt->execute([$student_id]);
$user = $stmt->fetch();
$student_name = $user['full_name'] ?? 'Student';

// Fetch student profile data
$stmt = $pdo->prepare("SELECT placement_type, profile_pic FROM student_profiles WHERE student_id = ?");
$stmt->execute([$student_id]);
$profile = $stmt->fetch();
$track = $profile['placement_type'] ?? 'Internship';
$profile_pic = $profile['profile_pic'] ?? '';
$student_avatar = !empty($profile_pic) ? '../' . $profile_pic : 'https://ui-avatars.com/api/?name=' . urlencode($student_name) . '&background=0091DF&color=fff&size=40';

$msg = "";
$error = "";

// Ensure upload directories exist
$upload_dir = '../uploads/student_docs/';
$doc_types = ['cv', 'certificate', 'birth_certificate', 'national_id', 'recommendation_letter', 'transcript'];

foreach ($doc_types as $type) {
    $dir = $upload_dir . $type . '/';
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
}

// Handle Form Uploads
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_docs'])) {
    try {
        // Check existing entry
        $check = $pdo->prepare("SELECT * FROM student_docs WHERE student_id = ?");
        $check->execute([$student_id]);
        $existing = $check->fetch();

        $doc_data = [
            'cv_path' => $existing['cv_path'] ?? null,
            'certificate_path' => $existing['certificate_path'] ?? null,
            'birth_certificate_path' => $existing['birth_certificate_path'] ?? null,
            'national_id_path' => $existing['national_id_path'] ?? null,
            'recommendation_letter_path' => $existing['recommendation_letter_path'] ?? null,
            'transcript_path' => $existing['transcript_path'] ?? null
        ];

        // Process each document type
        $doc_map = [
            'cv' => 'cv_path',
            'certificate' => 'certificate_path',
            'birth_certificate' => 'birth_certificate_path',
            'national_id' => 'national_id_path',
            'recommendation_letter' => 'recommendation_letter_path',
            'transcript' => 'transcript_path'
        ];

        foreach ($doc_map as $field => $db_column) {
            if (!empty($_FILES[$field]['name'])) {
                $file = $_FILES[$field];
                $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $allowed = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
                
                if (in_array($file_ext, $allowed)) {
                    $new_name = strtoupper($field) . '_' . $student_id . '_' . time() . '.' . $file_ext;
                    $target_path = $upload_dir . $field . '/' . $new_name;
                    
                    if (move_uploaded_file($file['tmp_name'], $target_path)) {
                        $doc_data[$db_column] = 'uploads/student_docs/' . $field . '/' . $new_name;
                    }
                }
            }
        }

        if ($existing) {
            $update = $pdo->prepare("UPDATE student_docs SET 
                cv_path = ?,
                certificate_path = ?,
                birth_certificate_path = ?,
                national_id_path = ?,
                recommendation_letter_path = ?,
                transcript_path = ?
                WHERE student_id = ?");
            $update->execute([
                $doc_data['cv_path'],
                $doc_data['certificate_path'],
                $doc_data['birth_certificate_path'],
                $doc_data['national_id_path'],
                $doc_data['recommendation_letter_path'],
                $doc_data['transcript_path'],
                $student_id
            ]);
        } else {
            $insert = $pdo->prepare("INSERT INTO student_docs 
                (student_id, cv_path, certificate_path, birth_certificate_path, national_id_path, recommendation_letter_path, transcript_path) 
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $insert->execute([
                $student_id,
                $doc_data['cv_path'],
                $doc_data['certificate_path'],
                $doc_data['birth_certificate_path'],
                $doc_data['national_id_path'],
                $doc_data['recommendation_letter_path'],
                $doc_data['transcript_path']
            ]);
        }
        
        $msg = "Documents uploaded successfully!";
        
        // Refresh data
        $doc_stmt = $pdo->prepare("SELECT * FROM student_docs WHERE student_id = ?");
        $doc_stmt->execute([$student_id]);
        $current_docs = $doc_stmt->fetch();
        
    } catch (Exception $e) {
        $error = "Upload processing error: " . $e->getMessage();
    }
}

// Fetch current uploaded documents
$doc_stmt = $pdo->prepare("SELECT * FROM student_docs WHERE student_id = ?");
$doc_stmt->execute([$student_id]);
$current_docs = $doc_stmt->fetch();

// Fetch notifications count
$notif_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_notifications WHERE student_id = ? AND is_read = 0");
$notif_stmt->execute([$student_id]);
$unread_count = $notif_stmt->fetchColumn();

$feed_stmt = $pdo->prepare("SELECT title, message, created_at FROM student_notifications WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
$feed_stmt->execute([$student_id]);
$recent_notifications = $feed_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Documents | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }

        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            margin-bottom: 30px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-radius: 12px; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
            box-shadow: 0 4px 14px rgba(0, 145, 223, 0.25);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .bell-dropdown-wrapper {
            position: relative;
            display: inline-block;
        }

        .bell-trigger-btn {
            background: none;
            border: none;
            color: var(--white);
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            padding: 5px;
            display: flex;
            align-items: center;
        }
        .bell-trigger-btn:hover { opacity: 0.85; }

        .bell-badge-counter {
            position: absolute;
            top: 0px;
            right: -2px;
            background: var(--alert-red);
            color: var(--white);
            font-size: 0.62rem;
            font-weight: 800;
            min-width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--softcare-blue);
        }

        .bell-overlay-panel {
            display: none;
            position: absolute;
            right: -10px;
            top: 140%;
            background: var(--white);
            min-width: 320px;
            max-width: 360px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            border-radius: 10px;
            border: 1px solid var(--border-light);
            z-index: 500;
            overflow: hidden;
        }
        .bell-dropdown-wrapper:hover .bell-overlay-panel { display: block; }

        .bell-panel-header {
            background: var(--milky-white);
            padding: 12px 16px;
            font-size: 0.82rem;
            font-weight: 800;
            color: var(--dark-text);
            border-bottom: 1px solid var(--border-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .bell-feed-scroll { max-height: 280px; overflow-y: auto; }
        
        .bell-item-row {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.15s;
            text-decoration: none;
            display: block;
        }
        .bell-item-row:last-child { border-bottom: none; }
        .bell-item-row:hover { background: var(--softcare-light-blue); }
        .bell-item-row h6 { margin: 0 0 3px 0; font-size: 0.82rem; color: var(--dark-text); font-weight: 700; }
        .bell-item-row p { margin: 0; font-size: 0.76rem; color: var(--muted-text); line-height: 1.35; }
        .bell-item-row span { font-size: 0.68rem; color: #94A3B8; display: block; margin-top: 4px; }
        .bell-empty-state { padding: 20px; text-align: center; color: var(--muted-text); font-size: 0.85rem; }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .student-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .student-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            overflow: hidden;
        }

        .header-dropdown-card.show {
            display: block;
        }

        .dropdown-user-info {
            padding: 16px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.92rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.72rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li {
            display: block;
        }

        .dropdown-menu-list li a,
        .dropdown-menu-list li label {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            transition: 0.2s;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
            border: none;
            background: none;
            font-family: inherit;
            text-align: left;
        }

        .dropdown-menu-list li a:hover,
        .dropdown-menu-list li label:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .container-card {
            background: var(--white);
            border-radius: 12px;
            border: 1px solid var(--border-light);
            padding: 30px;
            max-width: 900px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
        }

        .container-card h2 {
            margin: 0 0 4px 0;
            font-size: 1.3rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .container-card .subtitle {
            color: var(--muted-text);
            font-size: 0.88rem;
            margin: 0 0 25px 0;
        }

        .alert-success {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        .alert-error {
            background: #FEF2F2;
            color: var(--alert-red);
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #FEE2E2;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        .doc-status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 12px;
            background: var(--milky-white);
            padding: 16px 18px;
            border-radius: 8px;
            border: 1px solid var(--border-light);
            margin-bottom: 25px;
        }

        .doc-status-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .doc-status-item .status-icon {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.6rem;
            flex-shrink: 0;
        }

        .doc-status-item .status-icon.uploaded {
            background: #DCFCE7;
            color: var(--aloe-green);
        }

        .doc-status-item .status-icon.missing {
            background: #FEF2F2;
            color: var(--alert-red);
        }

        .doc-link {
            color: var(--softcare-blue);
            text-decoration: none;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 0.82rem;
        }

        .doc-link:hover {
            text-decoration: underline;
        }

        .track-badge {
            display: inline-block;
            background: var(--dark-text);
            color: var(--white);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .form-grid .full-width {
            grid-column: span 2;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-size: 0.78rem;
            font-weight: 700;
            color: var(--dark-text);
            margin-bottom: 4px;
        }

        .form-group label i {
            margin-right: 6px;
            color: var(--softcare-blue);
        }

        .form-group input[type="file"] {
            padding: 8px 10px;
            border: 2px dashed var(--border-light);
            border-radius: 8px;
            background: var(--milky-white);
            font-family: inherit;
            font-size: 0.85rem;
            cursor: pointer;
            transition: border-color 0.2s;
            width: 100%;
            box-sizing: border-box;
        }

        .form-group input[type="file"]:hover {
            border-color: var(--softcare-blue);
            background: var(--softcare-light-blue);
        }

        .form-group .file-hint {
            font-size: 0.7rem;
            color: var(--muted-text);
            margin-top: 3px;
        }

        .btn-upload {
            background: var(--softcare-blue);
            color: var(--white);
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.95rem;
            cursor: pointer;
            transition: background 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            justify-content: center;
            margin-top: 10px;
        }

        .btn-upload:hover {
            background: #0077b6;
        }

        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .main-content { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active-page { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .app-header-bar { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .student-name { font-size: 0.75rem; max-width: 80px; }
            .student-avatar-circle { width: 28px; height: 28px; }
            .page-content { padding: 16px; }
            .container-card { padding: 20px; }
            .form-grid { grid-template-columns: 1fr; }
            .form-grid .full-width { grid-column: span 1; }
            .doc-status-grid { grid-template-columns: 1fr 1fr; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
        }

        @media (max-width: 576px) {
            .sidebar { width: 60px; }
            .main-content { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .app-header-bar { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .student-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .student-avatar-circle { width: 26px; height: 26px; }
            .page-content { padding: 12px; }
            .container-card { padding: 16px; }
            .container-card h2 { font-size: 1.1rem; }
            .doc-status-grid { grid-template-columns: 1fr; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<!-- Hidden form for avatar upload -->
<form id="avatarUploadForm" action="dashboard.php" method="POST" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="ajax_profile_pic" name="ajax_profile_pic" accept="image/*" onchange="document.getElementById('avatarUploadForm').submit();">
</form>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-user-circle"></i> <span>My Profile</span></a></li>
        <li><a href="upload_docs.php" class="active-page"><i class="fa-solid fa-cloud-arrow-up"></i> <span>Upload Documents</span></a></li>
        <li><a href="cv_manager.php"><i class="fa-solid fa-file-invoice"></i> <span>Build & Upload CV</span></a></li>
        <li><a href="opportunities.php"><i class="fa-solid fa-building-user"></i> <span>View Vacancies</span></a></li>
        <li><a href="applications.php"><i class="fa-solid fa-route"></i> <span>My Applications</span></a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> <span>Change Password</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-cloud-arrow-up"></i> Upload Documents
            </div>
        </div>
        
        <div class="header-right">
            <!-- Notifications -->
            <div class="bell-dropdown-wrapper">
                <button class="bell-trigger-btn" title="System Alerts">
                    <i class="fa-solid fa-bell"></i>
                    <?php if($unread_count > 0): ?>
                        <span class="bell-badge-counter"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </button>
                <div class="bell-overlay-panel">
                    <div class="bell-panel-header">System Alerts</div>
                    <div class="bell-feed-scroll">
                        <?php if(empty($recent_notifications)): ?>
                            <div class="bell-empty-state">No real-time alert updates indexed.</div>
                        <?php else: foreach($recent_notifications as $notif): ?>
                            <a href="notifications.php" class="bell-item-row">
                                <h6><?php echo htmlspecialchars($notif['title']); ?></h6>
                                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                <span><i class="fa-regular fa-clock"></i> <?php echo date('M d, g:i A', strtotime($notif['created_at'])); ?></span>
                            </a>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>

            <!-- Profile -->
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $student_avatar; ?>" alt="Profile" class="student-avatar-circle">
                <span class="student-name"><?php echo htmlspecialchars($student_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($student_name); ?></h5>
                    <p><?php echo htmlspecialchars($track); ?></p>
                </div>
                <ul class="dropdown-menu-list">
                    <li>
                        <label for="ajax_profile_pic">
                            <i class="fa-solid fa-camera"></i> Upload Picture
                        </label>
                    </li>
                    <li>
                        <a href="../logout.php" class="logout-item">
                            <i class="fa-solid fa-right-from-bracket"></i> Sign Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <div class="container-card">
            <h2>
                <i class="fa-solid fa-folder-open" style="color: var(--softcare-blue);"></i> 
                Document Management
            </h2>
            <p class="subtitle">Upload and manage your documents. These will be used during the application process.</p>

            <?php if(!empty($msg)): ?>
                <div class="alert-success"><i class="fa-solid fa-circle-check"></i> <?php echo $msg; ?></div>
            <?php endif; ?>
            <?php if(!empty($error)): ?>
                <div class="alert-error"><i class="fa-solid fa-triangle-exclamation"></i> <?php echo $error; ?></div>
            <?php endif; ?>

            <!-- Document Status -->
            <div class="doc-status-grid">
                <?php
                $documents = [
                    'cv' => 'CV / Resume',
                    'certificate' => 'Certificate',
                    'birth_certificate' => 'Birth Certificate',
                    'national_id' => 'National ID',
                    'recommendation_letter' => 'Recommendation Letter',
                    'transcript' => 'Transcript'
                ];
                $doc_paths = [
                    'cv' => $current_docs['cv_path'] ?? null,
                    'certificate' => $current_docs['certificate_path'] ?? null,
                    'birth_certificate' => $current_docs['birth_certificate_path'] ?? null,
                    'national_id' => $current_docs['national_id_path'] ?? null,
                    'recommendation_letter' => $current_docs['recommendation_letter_path'] ?? null,
                    'transcript' => $current_docs['transcript_path'] ?? null
                ];
                foreach ($documents as $key => $label):
                    $uploaded = !empty($doc_paths[$key]);
                ?>
                    <div class="doc-status-item">
                        <span class="status-icon <?php echo $uploaded ? 'uploaded' : 'missing'; ?>">
                            <i class="fa-solid <?php echo $uploaded ? 'fa-check' : 'fa-times'; ?>"></i>
                        </span>
                        <?php if($uploaded): ?>
                            <a href="../<?php echo htmlspecialchars($doc_paths[$key]); ?>" target="_blank" class="doc-link">
                                <i class="fa-regular fa-file-pdf"></i> <?php echo $label; ?>
                            </a>
                        <?php else: ?>
                            <span style="color: var(--muted-text);"><?php echo $label; ?> <span style="font-weight:400;font-size:0.7rem;">(Not uploaded)</span></span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-grid">
                    <div class="form-group">
                        <label><i class="fa-regular fa-file-pdf"></i> CV / Resume</label>
                        <input type="file" name="cv" accept=".pdf,.doc,.docx">
                        <span class="file-hint">PDF, DOC, DOCX (Max 5MB)</span>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-certificate"></i> Certificate</label>
                        <input type="file" name="certificate" accept=".pdf,.jpg,.jpeg,.png">
                        <span class="file-hint">PDF, JPG, PNG (Max 5MB)</span>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-file-lines"></i> Birth Certificate</label>
                        <input type="file" name="birth_certificate" accept=".pdf,.jpg,.jpeg,.png">
                        <span class="file-hint">PDF, JPG, PNG (Max 5MB)</span>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-id-card"></i> National ID</label>
                        <input type="file" name="national_id" accept=".pdf,.jpg,.jpeg,.png">
                        <span class="file-hint">PDF, JPG, PNG (Max 5MB)</span>
                    </div>
                    <div class="form-group full-width">
                        <label><i class="fa-regular fa-envelope"></i> Recommendation Letter</label>
                        <input type="file" name="recommendation_letter" accept=".pdf,.doc,.docx">
                        <span class="file-hint">PDF, DOC, DOCX (Max 5MB)</span>
                    </div>
                    <div class="form-group full-width">
                        <label><i class="fa-regular fa-file-lines"></i> Academic Transcript</label>
                        <input type="file" name="transcript" accept=".pdf,.jpg,.jpeg,.png">
                        <span class="file-hint">PDF, JPG, PNG (Max 5MB)</span>
                    </div>
                </div>

                <button type="submit" name="upload_docs" class="btn-upload">
                    <i class="fa-solid fa-circle-arrow-up"></i> Upload All Documents
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('profileDropdown');
    const trigger = document.querySelector('.profile-trigger-zone');
    if (!trigger.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});
</script>
</body>
</html>