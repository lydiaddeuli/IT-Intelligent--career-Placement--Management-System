<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

// Fetch student details for header
$stmt = $pdo->prepare("SELECT full_name FROM users WHERE user_id = ?");
$stmt->execute([$student_id]);
$user = $stmt->fetch();
$student_name = $user['full_name'] ?? 'Student';

// --- AVATAR UPLOAD HANDLING ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['ajax_profile_pic'])) {
    $file = $_FILES['ajax_profile_pic'];
    $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($file_ext, $allowed_exts) && $file['error'] === 0) {
        $upload_dir = '../uploads/avatars/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $new_filename = 'avatar_' . $student_id . '_' . time() . '.' . $file_ext;
        $target_path = $upload_dir . $new_filename;
        
        if (move_uploaded_file($file['tmp_name'], $target_path)) {
            $update_stmt = $pdo->prepare("UPDATE student_profiles SET profile_pic = ? WHERE student_id = ?");
            $update_stmt->execute([$target_path, $student_id]);
            header("Location: dashboard.php");
            exit();
        }
    }
}

// 1. Fetch Student Track & Profile Details
$stmt = $pdo->prepare("SELECT placement_type, skills, bio, cv_path, transcript_path, profile_pic FROM student_profiles WHERE student_id = ?");
$stmt->execute([$student_id]);
$profile = $stmt->fetch();

$track = $profile['placement_type'] ?? 'Internship';
$profile_pic = $profile['profile_pic'] ?? '';
$student_avatar = !empty($profile_pic) ? '../' . $profile_pic : 'https://ui-avatars.com/api/?name=' . urlencode($student_name) . '&background=0091DF&color=fff&size=40';

// 2. Fetch Live Unread Notifications Count
$notif_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_notifications WHERE student_id = ? AND is_read = 0");
$notif_stmt->execute([$student_id]);
$unread_notifications_count = $notif_stmt->fetchColumn();

$feed_stmt = $pdo->prepare("SELECT title, message, created_at FROM student_notifications WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
$feed_stmt->execute([$student_id]);
$recent_notifications = $feed_stmt->fetchAll();

// 3. Fetch Student Application Status Statistics
$app_stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status='Accepted' THEN 1 ELSE 0 END) as accepted,
        SUM(CASE WHEN status='Confirmed' THEN 1 ELSE 0 END) as confirmed
    FROM applications 
    WHERE student_id = ?
");
$app_stmt->execute([$student_id]);
$app_stats = $app_stmt->fetch();
$total_applications = (int)($app_stats['total'] ?? 0);
$pending_count = (int)($app_stats['pending'] ?? 0);
$accepted_count = (int)($app_stats['accepted'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }

        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            margin-bottom: 30px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-radius: 12px; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
            box-shadow: 0 4px 14px rgba(0, 145, 223, 0.25);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .bell-dropdown-wrapper {
            position: relative;
            display: inline-block;
        }

        .bell-trigger-btn {
            background: none;
            border: none;
            color: var(--white);
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            padding: 5px;
            display: flex;
            align-items: center;
        }
        .bell-trigger-btn:hover { opacity: 0.85; }

        .bell-badge-counter {
            position: absolute;
            top: 0px;
            right: -2px;
            background: var(--alert-red);
            color: var(--white);
            font-size: 0.62rem;
            font-weight: 800;
            min-width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--softcare-blue);
        }

        .bell-overlay-panel {
            display: none;
            position: absolute;
            right: -10px;
            top: 140%;
            background: var(--white);
            min-width: 320px;
            max-width: 360px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            border-radius: 10px;
            border: 1px solid var(--border-light);
            z-index: 500;
            overflow: hidden;
        }
        .bell-dropdown-wrapper:hover .bell-overlay-panel { display: block; }

        .bell-panel-header {
            background: var(--milky-white);
            padding: 12px 16px;
            font-size: 0.82rem;
            font-weight: 800;
            color: var(--dark-text);
            border-bottom: 1px solid var(--border-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .bell-feed-scroll { max-height: 280px; overflow-y: auto; }
        
        .bell-item-row {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.15s;
            text-decoration: none;
            display: block;
        }
        .bell-item-row:last-child { border-bottom: none; }
        .bell-item-row:hover { background: var(--softcare-light-blue); }
        .bell-item-row h6 { margin: 0 0 3px 0; font-size: 0.82rem; color: var(--dark-text); font-weight: 700; }
        .bell-item-row p { margin: 0; font-size: 0.76rem; color: var(--muted-text); line-height: 1.35; }
        .bell-item-row span { font-size: 0.68rem; color: #94A3B8; display: block; margin-top: 4px; }
        .bell-empty-state { padding: 20px; text-align: center; color: var(--muted-text); font-size: 0.85rem; }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .student-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .student-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a, 
        .dropdown-menu-list li label {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
        }

        .dropdown-menu-list li a:hover, 
        .dropdown-menu-list li label:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .page-content {
            padding: 30px 35px;
        }

        .summary-dashboard-cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
            margin-bottom: 0;
        }

        .metric-card-box {
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }

        .metric-card-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        }

        .metric-card-box .metric-info h5 {
            margin: 0 0 2px 0;
            font-size: 0.7rem;
            color: var(--muted-text);
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
        }

        .metric-card-box .metric-info .metric-val {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .metric-card-box .metric-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: var(--white);
            flex-shrink: 0;
        }

        .metric-card-box .metric-icon.total { background: var(--softcare-blue); }
        .metric-card-box .metric-icon.pending { background: var(--mustard-yellow); }
        .metric-card-box .metric-icon.accepted { background: var(--aloe-green); }

        @media (max-width: 992px) {
            .summary-dashboard-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .main-content { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active-page { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .app-header-bar { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .student-name { font-size: 0.75rem; max-width: 80px; }
            .student-avatar-circle { width: 28px; height: 28px; }
            .page-content { padding: 16px; }
            .summary-dashboard-cards { grid-template-columns: 1fr 1fr; gap: 12px; }
            .metric-card-box { padding: 14px 16px; }
            .metric-card-box .metric-info .metric-val { font-size: 1.2rem; }
            .metric-card-box .metric-icon { width: 34px; height: 34px; font-size: 0.9rem; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
        }

        @media (max-width: 576px) {
            .sidebar { width: 60px; }
            .main-content { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .app-header-bar { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .student-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .student-avatar-circle { width: 26px; height: 26px; }
            .page-content { padding: 12px; }
            .summary-dashboard-cards { grid-template-columns: 1fr; gap: 10px; }
            .metric-card-box { padding: 12px 14px; }
            .metric-card-box .metric-info .metric-val { font-size: 1.1rem; }
            .metric-card-box .metric-icon { width: 30px; height: 30px; font-size: 0.8rem; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<!-- Hidden form for avatar upload -->
<form id="avatarUploadForm" action="dashboard.php" method="POST" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="ajax_profile_pic" name="ajax_profile_pic" accept="image/*" onchange="document.getElementById('avatarUploadForm').submit();">
</form>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php" class="active-page"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard</span></a></li>
        <li><a href="profile.php"><i class="fa-solid fa-user-circle"></i> <span>My Profile</span></a></li>
        <li><a href="upload_docs.php"><i class="fa-solid fa-cloud-arrow-up"></i> <span>Upload Documents</span></a></li>
        <li><a href="cv_manager.php"><i class="fa-solid fa-file-invoice"></i> <span>Build & Upload CV</span></a></li>
        <li><a href="opportunities.php"><i class="fa-solid fa-building-user"></i> <span>View Vacancies</span></a></li>
        <li><a href="applications.php"><i class="fa-solid fa-route"></i> <span>My Applications</span></a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> <span>Change Password</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-gauge-high"></i> Dashboard
            </div>
        </div>
        
        <div class="header-right">
            <!-- Notifications -->
            <div class="bell-dropdown-wrapper">
                <button class="bell-trigger-btn" title="System Alerts">
                    <i class="fa-solid fa-bell"></i>
                    <?php if($unread_notifications_count > 0): ?>
                        <span class="bell-badge-counter"><?php echo $unread_notifications_count; ?></span>
                    <?php endif; ?>
                </button>
                <div class="bell-overlay-panel">
                    <div class="bell-panel-header">System Alerts</div>
                    <div class="bell-feed-scroll">
                        <?php if(empty($recent_notifications)): ?>
                            <div class="bell-empty-state">No real-time alert updates indexed.</div>
                        <?php else: ?>
                            <?php foreach($recent_notifications as $notif): ?>
                                <a href="notifications.php" class="bell-item-row">
                                    <h6><?php echo htmlspecialchars($notif['title']); ?></h6>
                                    <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                    <span><i class="fa-regular fa-clock"></i> <?php echo date('M d, g:i A', strtotime($notif['created_at'])); ?></span>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Profile -->
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $student_avatar; ?>" alt="Profile" class="student-avatar-circle">
                <span class="student-name"><?php echo htmlspecialchars($student_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($student_name); ?></h5>
                    <p><?php echo htmlspecialchars($track); ?></p>
                </div>
                <ul class="dropdown-menu-list">
                    <label for="ajax_profile_pic"><i class="fa-solid fa-camera"></i> Upload Picture</label>
                    <a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <!-- Metric Cards Only -->
        <div class="summary-dashboard-cards">
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Total Applications</h5>
                    <div class="metric-val"><?php echo $total_applications; ?></div>
                </div>
                <div class="metric-icon total">
                    <i class="fa-solid fa-file-lines"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Pending</h5>
                    <div class="metric-val"><?php echo $pending_count; ?></div>
                </div>
                <div class="metric-icon pending">
                    <i class="fa-solid fa-clock"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Accepted</h5>
                    <div class="metric-val"><?php echo $accepted_count; ?></div>
                </div>
                <div class="metric-icon accepted">
                    <i class="fa-regular fa-circle-check"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});
</script>

</body>
</html>