<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

// Fetch student details for header
$stmt = $pdo->prepare("SELECT full_name, email FROM users WHERE user_id = ?");
$stmt->execute([$student_id]);
$user = $stmt->fetch();
$student_name = $user['full_name'] ?? 'Student';
$student_email = $user['email'] ?? '';

// Fetch student profile data
$stmt = $pdo->prepare("SELECT * FROM student_profiles WHERE student_id = ?");
$stmt->execute([$student_id]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle Profile Update
$success_msg = "";
$error_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // Personal Information
    $gender = trim($_POST['gender']);
    $date_of_birth = trim($_POST['date_of_birth']);
    $nida_number = trim($_POST['nida_number']);
    $disability = trim($_POST['disability']);
    
    // Contact Details
    $phone_number = trim($_POST['phone_number']);
    $physical_address = trim($_POST['physical_address']);
    $district = trim($_POST['district']);
    $region = trim($_POST['region']);
    
    // Academic Details
    $course_program = trim($_POST['course_program']);
    $year_of_study = trim($_POST['year_of_study']);
    
    // Other Details
    $religion = trim($_POST['religion']);
    $physical_address_full = trim($_POST['physical_address_full']);
    
    try {
        // Check if profile exists
        $check = $pdo->prepare("SELECT student_id FROM student_profiles WHERE student_id = ?");
        $check->execute([$student_id]);
        
        if ($check->fetch()) {
            // Update existing profile - removed full_name from update
            $update = $pdo->prepare("UPDATE student_profiles SET 
                gender = ?,
                date_of_birth = ?,
                nida_number = ?,
                disability = ?,
                phone_number = ?,
                physical_address = ?,
                district = ?,
                region = ?,
                course_program = ?,
                year_of_study = ?,
                religion = ?,
                physical_address_full = ?
                WHERE student_id = ?");
            
            $update->execute([
                $gender, $date_of_birth, $nida_number, $disability,
                $phone_number, $physical_address, $district, $region,
                $course_program, $year_of_study, $religion,
                $physical_address_full,
                $student_id
            ]);
        } else {
            // Insert new profile - removed full_name from insert
            $insert = $pdo->prepare("INSERT INTO student_profiles SET 
                student_id = ?,
                gender = ?,
                date_of_birth = ?,
                nida_number = ?,
                disability = ?,
                phone_number = ?,
                physical_address = ?,
                district = ?,
                region = ?,
                course_program = ?,
                year_of_study = ?,
                religion = ?,
                physical_address_full = ?,
                placement_type = 'Internship'");
            
            $insert->execute([
                $student_id, $gender, $date_of_birth, $nida_number,
                $disability, $phone_number, $physical_address,
                $district, $region, $course_program, $year_of_study,
                $religion, $physical_address_full
            ]);
        }
        
        $success_msg = "Profile updated successfully!";
        
        // Refresh profile data
        $stmt = $pdo->prepare("SELECT * FROM student_profiles WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $profile = $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        $error_msg = "Error updating profile: " . $e->getMessage();
    }
}

$profile_pic = $profile['profile_pic'] ?? '';
$student_avatar = !empty($profile_pic) ? '../' . $profile_pic : 'https://ui-avatars.com/api/?name=' . urlencode($student_name) . '&background=0091DF&color=fff&size=40';

// Fetch placement type
$track = $profile['placement_type'] ?? 'Internship';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;       
            --softcare-light-blue: #E6F4FC; 
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --milky-white: #F9F9FB;        
            --border-light: #E2E8F0;
            --pure-black: #000000;
            --alert-red: #EF4444;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--white); 
            display: flex; 
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 20px 0; 
            margin: 0; 
            flex: 1; 
        }
        
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active-page { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active-page i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active-page { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        .main-content { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--milky-white);
        }

        .app-header-bar { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            margin-bottom: 30px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-radius: 12px; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
            box-shadow: 0 4px 14px rgba(0, 145, 223, 0.25);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .bell-dropdown-wrapper {
            position: relative;
            display: inline-block;
        }

        .bell-trigger-btn {
            background: none;
            border: none;
            color: var(--white);
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            padding: 5px;
            display: flex;
            align-items: center;
        }
        .bell-trigger-btn:hover { opacity: 0.85; }

        .bell-badge-counter {
            position: absolute;
            top: 0px;
            right: -2px;
            background: var(--alert-red);
            color: var(--white);
            font-size: 0.62rem;
            font-weight: 800;
            min-width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--softcare-blue);
        }

        .bell-overlay-panel {
            display: none;
            position: absolute;
            right: -10px;
            top: 140%;
            background: var(--white);
            min-width: 320px;
            max-width: 360px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            border-radius: 10px;
            border: 1px solid var(--border-light);
            z-index: 500;
            overflow: hidden;
        }
        .bell-dropdown-wrapper:hover .bell-overlay-panel { display: block; }

        .bell-panel-header {
            background: var(--milky-white);
            padding: 12px 16px;
            font-size: 0.82rem;
            font-weight: 800;
            color: var(--dark-text);
            border-bottom: 1px solid var(--border-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .bell-feed-scroll { max-height: 280px; overflow-y: auto; }
        
        .bell-item-row {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.15s;
            text-decoration: none;
            display: block;
        }
        .bell-item-row:last-child { border-bottom: none; }
        .bell-item-row:hover { background: var(--softcare-light-blue); }
        .bell-item-row h6 { margin: 0 0 3px 0; font-size: 0.82rem; color: var(--dark-text); font-weight: 700; }
        .bell-item-row p { margin: 0; font-size: 0.76rem; color: var(--muted-text); line-height: 1.35; }
        .bell-item-row span { font-size: 0.68rem; color: #94A3B8; display: block; margin-top: 4px; }
        .bell-empty-state { padding: 20px; text-align: center; color: var(--muted-text); font-size: 0.85rem; }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .student-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .student-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            overflow: hidden;
        }

        .header-dropdown-card.show {
            display: block;
        }

        .dropdown-user-info {
            padding: 16px 18px;
            background: var(--milky-white);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.92rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.72rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li {
            display: block;
        }

        .dropdown-menu-list li a,
        .dropdown-menu-list li label {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            transition: 0.2s;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
            border: none;
            background: none;
            font-family: inherit;
            text-align: left;
        }

        .dropdown-menu-list li a:hover,
        .dropdown-menu-list li label:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        .dropdown-menu-list li label i {
            color: var(--softcare-blue);
        }

        /* --- PAGE CONTENT --- */
        .page-content {
            padding: 30px 35px;
        }

        .profile-container {
            background: var(--white);
            border-radius: 12px;
            border: 1px solid var(--border-light);
            padding: 30px;
            max-width: 900px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 24px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--border-light);
            margin-bottom: 25px;
        }

        .profile-avatar-large {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--softcare-blue);
        }

        .profile-header-info h2 {
            margin: 0 0 4px 0;
            font-size: 1.4rem;
            font-weight: 800;
        }

        .profile-header-info p {
            margin: 0;
            color: var(--muted-text);
            font-size: 0.9rem;
        }

        .profile-header-info .email-text {
            color: var(--softcare-blue);
            font-weight: 600;
        }

        .profile-header-info .track-badge {
            display: inline-block;
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
            padding: 3px 14px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            margin-top: 6px;
        }

        .section-title {
            font-size: 1.05rem;
            font-weight: 800;
            color: var(--dark-text);
            margin: 25px 0 18px 0;
            padding-bottom: 8px;
            border-bottom: 2px solid var(--border-light);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            color: var(--softcare-blue);
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .form-grid .full-width {
            grid-column: span 2;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-size: 0.78rem;
            font-weight: 700;
            color: var(--dark-text);
            margin-bottom: 4px;
        }

        .form-group label i {
            margin-right: 6px;
            color: var(--softcare-blue);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            padding: 10px 12px;
            border: 1px solid var(--border-light);
            border-radius: 8px;
            font-size: 0.9rem;
            background: var(--milky-white);
            transition: border-color 0.2s;
            font-family: inherit;
            width: 100%;
            box-sizing: border-box;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--softcare-blue);
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }

        .form-group .readonly-field {
            background: #F1F5F9;
            color: var(--muted-text);
            padding: 10px 12px;
            border: 1px solid var(--border-light);
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .btn-submit {
            background: var(--softcare-blue);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.95rem;
            cursor: pointer;
            transition: background 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 15px;
            width: 100%;
            justify-content: center;
        }

        .btn-submit:hover {
            background: #0077b6;
        }

        .alert-success {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        .alert-error {
            background: #FEF2F2;
            color: var(--alert-red);
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #FEE2E2;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        /* Mobile Responsive */
        @media (max-width: 992px) {
            .form-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .main-content { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active-page { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .app-header-bar { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .student-name { font-size: 0.75rem; max-width: 80px; }
            .student-avatar-circle { width: 28px; height: 28px; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
            .page-content { padding: 16px; }
            .profile-container { padding: 20px; }
            .form-grid { grid-template-columns: 1fr; }
            .form-grid .full-width { grid-column: span 1; }
            .profile-header { flex-direction: column; text-align: center; }
            .profile-avatar-large { width: 60px; height: 60px; }
        }

        @media (max-width: 576px) {
            .sidebar { width: 60px; }
            .main-content { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .app-header-bar { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .student-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .student-avatar-circle { width: 26px; height: 26px; }
            .page-content { padding: 12px; }
            .profile-container { padding: 16px; }
            .profile-header-info h2 { font-size: 1.1rem; }
            .btn-submit { font-size: 0.85rem; padding: 10px; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<!-- Hidden form for avatar upload -->
<form id="avatarUploadForm" action="dashboard.php" method="POST" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="ajax_profile_pic" name="ajax_profile_pic" accept="image/*" onchange="document.getElementById('avatarUploadForm').submit();">
</form>

<aside class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard</span></a></li>
        <li><a href="profile.php" class="active-page"><i class="fa-solid fa-user-circle"></i> <span>My Profile</span></a></li>
        <li><a href="upload_docs.php"><i class="fa-solid fa-cloud-arrow-up"></i> <span>Upload Documents</span></a></li>
        <li><a href="cv_manager.php"><i class="fa-solid fa-file-invoice"></i> <span>Build & Upload CV</span></a></li>
        <li><a href="opportunities.php"><i class="fa-solid fa-building-user"></i> <span>View Vacancies</span></a></li>
        <li><a href="applications.php"><i class="fa-solid fa-route"></i> <span>My Applications</span></a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> <span>Change Password</span></a></li>
    </ul>
</aside>

<div class="main-content">
    <header class="app-header-bar">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-user-circle"></i> My Profile
            </div>
        </div>
        
        <div class="header-right">
            <!-- Notifications -->
            <div class="bell-dropdown-wrapper">
                <button class="bell-trigger-btn" title="System Alerts">
                    <i class="fa-solid fa-bell"></i>
                    <?php
                    $notif_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_notifications WHERE student_id = ? AND is_read = 0");
                    $notif_stmt->execute([$student_id]);
                    $unread_count = $notif_stmt->fetchColumn();
                    if($unread_count > 0): ?>
                        <span class="bell-badge-counter"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </button>
                <div class="bell-overlay-panel">
                    <div class="bell-panel-header">System Alerts</div>
                    <div class="bell-feed-scroll">
                        <?php
                        $feed_stmt = $pdo->prepare("SELECT title, message, created_at FROM student_notifications WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
                        $feed_stmt->execute([$student_id]);
                        $recent = $feed_stmt->fetchAll();
                        if(empty($recent)): ?>
                            <div class="bell-empty-state">No real-time alert updates indexed.</div>
                        <?php else: foreach($recent as $notif): ?>
                            <a href="notifications.php" class="bell-item-row">
                                <h6><?php echo htmlspecialchars($notif['title']); ?></h6>
                                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                <span><i class="fa-regular fa-clock"></i> <?php echo date('M d, g:i A', strtotime($notif['created_at'])); ?></span>
                            </a>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>

            <!-- Profile -->
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $student_avatar; ?>" alt="Profile" class="student-avatar-circle">
                <span class="student-name"><?php echo htmlspecialchars($student_name); ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo htmlspecialchars($student_name); ?></h5>
                    <p><?php echo htmlspecialchars($track); ?></p>
                </div>
                <ul class="dropdown-menu-list">
                    <li>
                        <label for="ajax_profile_pic">
                            <i class="fa-solid fa-camera"></i> Upload Picture
                        </label>
                    </li>
                    <li>
                        <a href="../logout.php" class="logout-item">
                            <i class="fa-solid fa-right-from-bracket"></i> Sign Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <div class="page-content">
        <div class="profile-container">
            <?php if(!empty($success_msg)): ?>
                <div class="alert-success">
                    <i class="fa-solid fa-circle-check"></i> <?php echo $success_msg; ?>
                </div>
            <?php endif; ?>
            <?php if(!empty($error_msg)): ?>
                <div class="alert-error">
                    <i class="fa-solid fa-circle-exclamation"></i> <?php echo $error_msg; ?>
                </div>
            <?php endif; ?>

            <!-- Profile Header -->
            <div class="profile-header">
                <img src="<?php echo $student_avatar; ?>" alt="Profile Picture" class="profile-avatar-large">
                <div class="profile-header-info">
                    <h2><?php echo htmlspecialchars($student_name); ?></h2>
                    <p><span class="email-text"><?php echo htmlspecialchars($student_email); ?></span></p>
                    <span class="track-badge"><i class="fa-regular fa-briefcase"></i> <?php echo htmlspecialchars($track); ?></span>
                </div>
            </div>

            <form method="POST" action="">
                <!-- 1. Personal Information -->
                <div class="section-title">
                    <i class="fa-regular fa-user"></i> Personal Information
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label><i class="fa-regular fa-user"></i> Full Name</label>
                        <div class="readonly-field"><?php echo htmlspecialchars($student_name); ?></div>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-envelope"></i> Email Address</label>
                        <div class="readonly-field"><?php echo htmlspecialchars($student_email); ?></div>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-venus-mars"></i> Gender</label>
                        <select name="gender">
                            <option value="">Select Gender</option>
                            <option value="Male" <?php echo (isset($profile['gender']) && $profile['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo (isset($profile['gender']) && $profile['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                            <option value="Other" <?php echo (isset($profile['gender']) && $profile['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-calendar"></i> Date of Birth</label>
                        <input type="date" name="date_of_birth" value="<?php echo htmlspecialchars($profile['date_of_birth'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-id-card"></i> NIDA Number</label>
                        <input type="text" name="nida_number" placeholder="Enter NIDA Number" value="<?php echo htmlspecialchars($profile['nida_number'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-wheelchair"></i> Disability Status</label>
                        <select name="disability">
                            <option value="">Select Option</option>
                            <option value="None" <?php echo (isset($profile['disability']) && $profile['disability'] == 'None') ? 'selected' : ''; ?>>None</option>
                            <option value="Physical" <?php echo (isset($profile['disability']) && $profile['disability'] == 'Physical') ? 'selected' : ''; ?>>Physical Disability</option>
                            <option value="Visual" <?php echo (isset($profile['disability']) && $profile['disability'] == 'Visual') ? 'selected' : ''; ?>>Visual Impairment</option>
                            <option value="Hearing" <?php echo (isset($profile['disability']) && $profile['disability'] == 'Hearing') ? 'selected' : ''; ?>>Hearing Impairment</option>
                            <option value="Other" <?php echo (isset($profile['disability']) && $profile['disability'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-flag"></i> Religion</label>
                        <input type="text" name="religion" placeholder="Enter Religion" value="<?php echo htmlspecialchars($profile['religion'] ?? ''); ?>">
                    </div>
                </div>

                <!-- 2. Other Personal Details -->
                <div class="section-title">
                    <i class="fa-regular fa-graduation-cap"></i> Other Personal Details
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label><i class="fa-regular fa-graduation-cap"></i> Course / Degree Program</label>
                        <input type="text" name="course_program" placeholder="e.g. Bachelor of Computer Science" value="<?php echo htmlspecialchars($profile['course_program'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-calendar"></i> Year of Study</label>
                        <select name="year_of_study">
                            <option value="">Select Year</option>
                            <option value="1" <?php echo (isset($profile['year_of_study']) && $profile['year_of_study'] == '1') ? 'selected' : ''; ?>>Year 1</option>
                            <option value="2" <?php echo (isset($profile['year_of_study']) && $profile['year_of_study'] == '2') ? 'selected' : ''; ?>>Year 2</option>
                            <option value="3" <?php echo (isset($profile['year_of_study']) && $profile['year_of_study'] == '3') ? 'selected' : ''; ?>>Year 3</option>
                            <option value="4" <?php echo (isset($profile['year_of_study']) && $profile['year_of_study'] == '4') ? 'selected' : ''; ?>>Year 4</option>
                            <option value="5" <?php echo (isset($profile['year_of_study']) && $profile['year_of_study'] == '5') ? 'selected' : ''; ?>>Year 5</option>
                            <option value="6" <?php echo (isset($profile['year_of_study']) && $profile['year_of_study'] == '6') ? 'selected' : ''; ?>>Year 6</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-location-dot"></i> Region</label>
                        <input type="text" name="region" placeholder="Enter Region" value="<?php echo htmlspecialchars($profile['region'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-location-dot"></i> District</label>
                        <input type="text" name="district" placeholder="Enter District" value="<?php echo htmlspecialchars($profile['district'] ?? ''); ?>">
                    </div>
                </div>

                <!-- 3. Contact Details -->
                <div class="section-title">
                    <i class="fa-regular fa-address-card"></i> Contact Details
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label><i class="fa-regular fa-phone"></i> Phone Number</label>
                        <input type="tel" name="phone_number" placeholder="e.g. 0712 345 678" value="<?php echo htmlspecialchars($profile['phone_number'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-location-dot"></i> Physical Address</label>
                        <input type="text" name="physical_address" placeholder="e.g. Street, Area" value="<?php echo htmlspecialchars($profile['physical_address'] ?? ''); ?>">
                    </div>
                    <div class="form-group full-width">
                        <label><i class="fa-regular fa-address-card"></i> Complete Address</label>
                        <textarea name="physical_address_full" rows="2" placeholder="Full address details"><?php echo htmlspecialchars($profile['physical_address_full'] ?? ''); ?></textarea>
                    </div>
                </div>

                <button type="submit" name="update_profile" class="btn-submit">
                    <i class="fa-regular fa-floppy-disk"></i> Save Profile
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('profileDropdown');
    const trigger = document.querySelector('.profile-trigger-zone');
    if (!trigger.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});
</script>
</body>
</html>