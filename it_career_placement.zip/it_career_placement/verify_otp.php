<?php
session_start();
include('includes/db_connect.php');

if (!isset($_SESSION['reset_user_id'])) {
    header("Location: forgot_password.php");
    exit();
}

$error = "";
$simulated_otp = $_SESSION['generated_otp_simulation'] ?? null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $entered_otp = trim($_POST['otp']);
    $user_id = $_SESSION['reset_user_id'];

    $stmt = $pdo->prepare("SELECT * FROM system_notifications WHERE user_id = ? AND type = 'reset_request' AND otp_code = ? AND is_resolved = 0 ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$user_id, $entered_otp]);
    $valid_request = $stmt->fetch();

    if ($valid_request) {
        $_SESSION['otp_verified'] = true;
        $_SESSION['active_notif_id'] = $valid_request['notif_id'];
        
        // Remove the simulation variable before shifting focus to clean the context tracking
        unset($_SESSION['generated_otp_simulation']);
        
        header("Location: reset_password_form.php");
        exit();
    } else {
        $error = "Security mismatch! The OTP code entered is invalid or has expired.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Identity | OTP Gateway</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      /* Primary Corporate Blue */
            --softcare-light-blue: #E6F4FC;/* Clean Fresh Accent Tint */
            --mustard-yellow: #F59E0B;     /* Sharp Contrast Structural Border Color */
            --dark-text: #1C2D42;          /* Deep Slate Grey Text */
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           /* Workspace Canvas Background */
            --border-light: #E2E8F0;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            flex-direction: column;
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        /* --- NAVIGATION HEADER --- */
        .global-header {
            background: var(--white);
            border-bottom: 3px solid var(--softcare-blue);
            box-shadow: 0 4px 20px rgba(0, 145, 223, 0.06);
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
            box-sizing: border-box;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 900;
            color: #000000;
            text-decoration: none;
            letter-spacing: -0.5px;
        }

        .brand-logo-img {
            height: 80px;
            width: auto;
            object-fit: contain;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 15px;
        }

        .nav-menu li a {
            color: var(--dark-text);
            text-decoration: none;
            font-weight: 700;
            font-size: 0.95rem;
            padding: 10px 18px;
            border-radius: 8px;
            transition: 0.2s ease-in-out;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-menu li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        /* --- CARD WORKSPACE --- */
        .main-workspace {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 60px 20px;
            box-sizing: border-box;
        }
        
        .card { 
            background: var(--white); 
            width: 100%;
            max-width: 450px; 
            margin: auto; 
            border-radius: 16px; 
            box-shadow: 0 10px 30px rgba(28, 45, 66, 0.04); 
            overflow: hidden; 
            border-top: 6px solid var(--mustard-yellow); 
        }

        .card-header { 
            padding: 40px 40px 15px 40px; 
            background: var(--white); 
            text-align: center; 
        }

        .card-header h3 { 
            margin: 0; 
            color: var(--dark-text); 
            font-size: 1.6rem; 
            font-weight: 900; 
            letter-spacing: -0.5px;
            text-transform: uppercase;
        }

        .card-header span { 
            color: var(--softcare-blue); 
            font-weight: 800; 
            font-size: 0.85rem; 
            text-transform: uppercase; 
            letter-spacing: 1.5px; 
            display: block;
            margin-bottom: 8px;
        }

        .card-body { padding: 15px 40px 40px 40px; }

        .form-group { margin-bottom: 24px; position: relative; }
        
        input { 
            width: 100%; 
            padding: 14px; 
            border: 2px solid var(--border-light); 
            border-radius: 8px; 
            box-sizing: border-box; 
            font-size: 1.6rem; 
            font-weight: 700;
            letter-spacing: 5px;
            text-align: center;
            background: var(--cream-bg); 
            color: var(--dark-text); 
            transition: 0.2s ease-in-out;
        }

        input:focus { 
            border-color: var(--softcare-blue); 
            outline: none; 
            background: var(--white); 
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }

        button { 
            background: var(--softcare-blue); 
            color: var(--white); 
            border: none; 
            padding: 16px; 
            width: 100%; 
            border-radius: 8px; 
            font-weight: 800; 
            font-size: 1.05rem; 
            cursor: pointer; 
            transition: 0.2s ease-in-out; 
            margin-top: 10px; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
            box-shadow: 0 4px 12px rgba(0, 145, 223, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        button:hover { 
            background: var(--dark-text); 
            box-shadow: 0 4px 12px rgba(28, 45, 66, 0.2);
            color: var(--white);
        }

        .error-box { 
            background: #FFF5F5; 
            color: #E53E3E; 
            padding: 14px; 
            border-radius: 8px; 
            margin-bottom: 25px; 
            font-weight: 600; 
            border: 1px solid #FED7D7;
            border-left: 5px solid #E53E3E; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 0.9rem;
        }

        /* Localhost Environment Simulation Sandbox Alert CSS */
        .localhost-sim-alert {
            background: #FFFBE6;
            border: 2px dashed #FFE58F;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 25px;
            color: #D46B08;
            font-size: 0.85rem;
            line-height: 1.5;
        }
        
        .otp-token-highlight {
            display: block;
            text-align: center;
            font-size: 1.7rem;
            font-weight: 900;
            color: #1A1A1B;
            letter-spacing: 2px;
            margin-top: 10px;
            font-family: monospace;
            background: rgba(255, 255, 255, 0.7);
            padding: 6px;
            border-radius: 6px;
            border: 1px solid #FFE58F;
        }

        /* --- SYSTEM FOOTER --- */
        .system-footer {
            background: var(--dark-text);
            color: #94A3B8;
            padding: 40px 25px 30px 25px;
            border-top: 4px solid var(--mustard-yellow);
            width: 100%;
            box-sizing: border-box;
        }

        .footer-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
        }

        .footer-column h5 {
            color: var(--white);
            font-size: 1.1rem;
            margin: 0 0 15px 0;
            font-weight: 700;
        }

        .footer-column p {
            font-size: 0.9rem;
            line-height: 1.6;
            margin: 0;
        }

        .footer-base {
            max-width: 1200px;
            margin: 30px auto 0 auto;
            border-top: 1px solid #2E3E52;
            padding-top: 20px;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 600;
        }
    </style>
</head>
<body>

<header class="global-header">
    <div class="nav-container">
        <a href="index.php" class="brand-logo">
            <img src="images/logo.jpeg" alt="CareerConnect Logo" class="brand-logo-img"> CareerConnect
        </a>
        <ul class="nav-menu">
            <li><a href="index.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="login.php"><i class="fa-solid fa-right-to-bracket"></i> Login</a></li>
        </ul>
    </div>
</header>

<div class="main-workspace">
    <div class="card">
        <div class="card-header">
            <span>Identity Vetting Desk</span>
            <h3>Identity Validation</h3>
        </div>
        
        <div class="card-body">
            <?php if ($simulated_otp): ?>
                <div class="localhost-sim-alert">
                    <i class="fa-solid fa-laptop-code"></i> <strong>Localhost SMTP Simulation:</strong><br>
                    An email delivery message was intercepted. Your testing token value is:
                    <span class="otp-token-highlight"><?php echo $simulated_otp; ?></span>
                </div>
            <?php else: ?>
                <p style="color: var(--muted-text); font-size: 0.95rem; text-align: center; margin-top: 0; margin-bottom: 25px;">
                    Please enter your token sequence to authorize account configuration manipulation overrides.
                </p>
            <?php endif; ?>

            <?php if(!empty($error)): ?>
                <div class="error-box">
                    <i class="fa-solid fa-triangle-exclamation"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <input type="text" name="otp" maxlength="6" placeholder="000000" required autocomplete="off">
                </div>
                <button type="submit">Verify Token &rarr;</button>
            </form>
        </div>
    </div>
</div>

<footer class="system-footer">
    <div class="footer-inner">
        <div class="footer-column">
            <h5>About CareerConnect</h5>
            <p>Our centralized management architecture handles seamless, automated verification parameters connecting academic talent directly with corporate structures.</p>
        </div>
        <div class="footer-column">
            <h5>Technical Desk Support</h5>
            <p>Encountering user access restrictions or database profile lockouts? Connect directly with support teams at info@softcareplacement.co.tz.</p>
        </div>
    </div>
    <div class="footer-base">
        &copy; 2026 Softcare Intelligent Career Placement System. All Rights Reserved.
    </div>
</footer>

</body>
</html>