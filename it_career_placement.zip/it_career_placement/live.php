<?php
session_start();
include('includes/db_connect.php');

// 1. Fetching Data kwa kutumia LEFT JOIN sahihi
try {
    $sql = "SELECT o.*, 
                   IFNULL(org.org_name, 'Verified Partner') AS company_name, 
                   org.location AS org_location
            FROM opportunities o
            LEFT JOIN organizations org ON o.company_id = org.org_id
            ORDER BY o.opp_id DESC";
            
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $vacancies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $total_live = count($vacancies);
    $total_slots = array_sum(array_column($vacancies, 'slots'));
} catch (Exception $e) {
    $vacancies = [];
    $total_live = 0;
    $total_slots = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Live Vacancy Board | CareerConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --softcare-blue: #0091DF; --dark-text: #1C2D42; --white: #FFFFFF; --cream-bg: #F8FAFC; --border-light: #E2E8F0; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--cream-bg); margin: 0; }
        .container { max-width: 1000px; margin: 40px auto; padding: 20px; }
        
        /* Muonekano wa Jedwali kama ule wa student/opportunities.php */
        .vacancy-table-container { background: var(--white); padding: 25px; border-radius: 12px; border: 1px solid var(--border-light); }
        .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .table th { background: #f8f9fa; padding: 15px; text-align: left; border-bottom: 2px solid var(--border-light); }
        .table td { padding: 15px; border-bottom: 1px solid var(--border-light); }
        
        .btn-action { background: var(--softcare-blue); color: white; padding: 8px 15px; border-radius: 6px; text-decoration: none; font-size: 0.9rem; }
    </style>
</head>
<body>

<div class="container">
    <h2>Available Opportunities</h2>
    
    <div class="vacancy-table-container">
        <table class="table">
            <thead>
                <tr>
                    <th>JOB TITLE & CORPORATE UNIT</th>
                    <th>PATH VARIANT</th>
                    <th>CLOSING DATE</th>
                    <th>SLOTS</th>
                    <th>ACTION</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($vacancies)): ?>
                    <?php foreach ($vacancies as $row): ?>
                    <tr>
                        <td>
                            <strong><?php echo htmlspecialchars($row['title']); ?></strong><br>
                            <small><i class="fa-solid fa-building"></i> <?php echo htmlspecialchars($row['company_name']); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($row['type']); ?></td>
                        <td><?php echo htmlspecialchars($row['closing_date'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($row['slots']); ?> Slots</td>
                        <td>
                            <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'student'): ?>
                                <a href="student/apply.php?id=<?php echo $row['opp_id']; ?>" class="btn-action">Apply Now</a>
                            <?php else: ?>
                                <a href="login.php" class="btn-action">Login to Apply</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5">Hakuna nafasi za kazi kwa sasa.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>