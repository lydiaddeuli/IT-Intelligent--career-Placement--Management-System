<?php
include('includes/db_connect.php');

// Fetch current gate states from settings database
$settings_query = $pdo->query("SELECT * FROM system_settings")->fetchAll(PDO::FETCH_KEY_PAIR);
$student_allowed = isset($settings_query['allow_student_reg']) ? $settings_query['allow_student_reg'] : '1';
$company_allowed = isset($settings_query['allow_company_reg']) ? $settings_query['allow_company_reg'] : '1';

$error = "";

// Tanzania Regions with Districts
$tanzania_regions = [
    'Arusha' => ['Arusha', 'Arusha City', 'Karatu', 'Longido', 'Meru', 'Monduli', 'Ngorongoro'],
    'Dar es Salaam' => ['Ilala', 'Kinondoni', 'Temeke', 'Ubungo', 'Kigamboni'],
    'Dodoma' => ['Bahi', 'Chamwino', 'Chemba', 'Dodoma City', 'Kongwa', 'Mpwapwa'],
    'Geita' => ['Bukombe', 'Chato', 'Geita', 'Mbogwe', 'Nyang\'wale'],
    'Iringa' => ['Iringa', 'Iringa City', 'Kilolo', 'Mafinga', 'Mufindi'],
    'Kagera' => ['Biharamulo', 'Bukoba', 'Bukoba City', 'Karagwe', 'Kyerwa', 'Misenyi', 'Muleba', 'Ngara'],
    'Katavi' => ['Mlele', 'Mpanda', 'Mpanda City', 'Tanganyika'],
    'Kigoma' => ['Buhigwe', 'Kakonko', 'Kasulu', 'Kasulu City', 'Kibondo', 'Kigoma', 'Kigoma City', 'Uvinza'],
    'Kilimanjaro' => ['Hai', 'Moshi', 'Moshi City', 'Mwanga', 'Rombo', 'Same', 'Siha'],
    'Lindi' => ['Kilwa', 'Lindi', 'Lindi City', 'Liwalde', 'Mchinga', 'Nachingwea', 'Ruangwa'],
    'Manyara' => ['Babati', 'Babati City', 'Hanang', 'Kiteto', 'Mbulu', 'Simanjiro'],
    'Mara' => ['Bunda', 'Butiama', 'Musoma', 'Musoma City', 'Rorya', 'Serengeti', 'Tarime'],
    'Mbeya' => ['Busokelo', 'Chunya', 'Kyela', 'Mbeya', 'Mbeya City', 'Mbozi', 'Rungwe'],
    'Morogoro' => ['Gairo', 'Ifakara City', 'Kilosa', 'Morogoro', 'Morogoro City', 'Mvomero', 'Ulanga'],
    'Mtwara' => ['Masasi', 'Masasi City', 'Mtwara', 'Mtwara City', 'Nanyumbu', 'Newala', 'Tandahimba'],
    'Mwanza' => ['Geita', 'Ilemela', 'Kwimba', 'Magu', 'Misungwi', 'Nyamagana', 'Sengerema', 'Ukerewe'],
    'Njombe' => ['Ludewa', 'Makambako City', 'Makete', 'Njombe', 'Njombe City', 'Wanging\'ombe'],
    'Pemba North' => ['Micheweni', 'Wete'],
    'Pemba South' => ['Chake Chake', 'Mkoani'],
    'Pwani' => ['Bagamoyo', 'Chalinze', 'Kibaha', 'Kibaha City', 'Kisarawe', 'Mafia', 'Mkuranga', 'Rufiji'],
    'Rukwa' => ['Kalambo', 'Nkasi', 'Sumbawanga', 'Sumbawanga City'],
    'Ruvuma' => ['Mbinga', 'Mbinga City', 'Namanga', 'Namtumbo', 'Nyasa', 'Songea', 'Songea City', 'Tunduru'],
    'Shinyanga' => ['Kahama', 'Kahama City', 'Kishapu', 'Shinyanga', 'Shinyanga City'],
    'Simiyu' => ['Bariadi', 'Bariadi City', 'Busega', 'Itilima', 'Maswa', 'Meatu'],
    'Singida' => ['Iramba', 'Ikungi', 'Manyoni', 'Mkalama', 'Singida', 'Singida City'],
    'Songwe' => ['Ileje', 'Mbozi', 'Momba', 'Songwe'],
    'Tabora' => ['Igunga', 'Kaliua', 'Nzega', 'Sikonge', 'Tabora', 'Tabora City', 'Urambo', 'Uyui'],
    'Tanga' => ['Handeni', 'Handeni City', 'Korogwe', 'Korogwe City', 'Lushoto', 'Mkinga', 'Muheza', 'Pangani', 'Tanga', 'Tanga City'],
    'Zanzibar North' => ['Kaskazini A', 'Kaskazini B'],
    'Zanzibar South' => ['Kati', 'Kusini'],
    'Zanzibar West' => ['Magharibi', 'Mjini']
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if fields exist before accessing
    $fullname = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    $role = isset($_POST['role']) ? $_POST['role'] : '';

    // --- ENHANCED SECURITY VALIDATION ---
    if (empty($fullname) || empty($email) || empty($password)) {
        $error = "Registration Failed: All fields are required. Please fill in all information.";
    } elseif ($password !== $confirm_password) {
        $error = "Registration Failed: Passwords do not match. Please verify and try again.";
    } elseif (strlen($password) < 6) {
        $error = "Registration Failed: Password must be at least 6 characters long.";
    } elseif ($role === 'student' && $student_allowed !== '1') {
        $error = "Registration Blocked: Student account registration is currently closed by administration.";
    } elseif ($role === 'company' && $company_allowed !== '1') {
        $error = "Registration Blocked: Corporate entity self-registration is currently disabled.";
    } else {
        try {
            $pdo->beginTransaction();

            // Hash password safely after confirmations pass
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$fullname, $email, $hashed_password, $role]);
            $user_id = $pdo->lastInsertId();

            if ($role == 'student') {
                $placement = isset($_POST['placement_type']) ? $_POST['placement_type'] : 'Internship';
                $stmtProfile = $pdo->prepare("INSERT INTO student_profiles (student_id, placement_type) VALUES (?, ?)");
                $stmtProfile->execute([$user_id, $placement]);
            } 
            elseif ($role == 'company') {
                $industry = isset($_POST['industry']) ? trim($_POST['industry']) : 'Not Specified';
                $region = isset($_POST['region']) ? trim($_POST['region']) : 'Not Specified';
                $district = isset($_POST['district']) ? trim($_POST['district']) : 'Not Specified';
                $location = $region . ', ' . $district;
                
                // Vetted corporate parameters
                $reg_number = isset($_POST['reg_number']) ? trim($_POST['reg_number']) : '';
                $tin_number = isset($_POST['tin_number']) ? trim($_POST['tin_number']) : '';
                $website = isset($_POST['website']) ? trim($_POST['website']) : '';
                
                // Dynamic Fee Structure parameters
                $has_fees = isset($_POST['has_fees']) ? $_POST['has_fees'] : 'None';
                $reg_fee = isset($_POST['reg_fee_amount']) ? floatval($_POST['reg_fee_amount']) : 0.00;
                $direct_cost = isset($_POST['direct_cost_amount']) ? floatval($_POST['direct_cost_amount']) : 0.00;
                $fee_reason = isset($_POST['fee_reason']) ? trim($_POST['fee_reason']) : '';

                // Package amounts into structured JSON format for easy loading
                $fee_amounts_json = json_encode([
                    'registration_fee' => $reg_fee,
                    'direct_field_cost' => $direct_cost
                ]);
                
                // --- FILE UPLOAD PROCESSING (BRELA / TIN CERTIFICATES) ---
                $uploaded_docs_path = "";
                if (isset($_FILES['verification_docs']) && $_FILES['verification_docs']['error'] == 0) {
                    $file_name = $_FILES['verification_docs']['name'];
                    $file_tmp = $_FILES['verification_docs']['tmp_name'];
                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                    
                    $allowed_exts = ['pdf', 'zip', 'rar'];
                    
                    if (in_array($file_ext, $allowed_exts)) {
                        $upload_dir = 'uploads/company_verifications/';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }
                        $new_file_name = "verify_" . $user_id . "_" . time() . "." . $file_ext;
                        $uploaded_docs_path = $upload_dir . $new_file_name;
                        move_uploaded_file($file_tmp, $uploaded_docs_path);
                    } else {
                        throw new Exception("Invalid file format. Documentation must be a combined PDF or compressed ZIP archive.");
                    }
                } else {
                    throw new Exception("Corporate registration requires uploading verification compliance documents.");
                }

                // Insert with fee specifications mapping directly into table space
                $stmtOrg = $pdo->prepare("INSERT INTO organizations (org_id, org_name, industry, location, contact_email, reg_number, tin_number, website, verification_documents, verification_status, has_fees, fee_amounts_json, fee_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?)");
                $stmtOrg->execute([$user_id, $fullname, $industry, $location, $email, $reg_number, $tin_number, $website, $uploaded_docs_path, $has_fees, $fee_amounts_json, $fee_reason]);
            }

            $pdo->commit();
            
            if ($role == 'company') {
                header("Location: payment_invoice.php?account_id=" . $user_id);
            } else {
                header("Location: login.php?msg=Registration successful");
            }
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "System Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           
            --border-light: #E2E8F0;
            --alert-banner: #FEF3C7;
            --alert-text: #B45309;
            --alert-red: #EF4444;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            flex-direction: column;
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        .global-header {
            background: var(--white);
            border-bottom: 3px solid var(--softcare-blue);
            box-shadow: 0 4px 20px rgba(0, 145, 223, 0.06);
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
            box-sizing: border-box;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 900;
            color: #000000; 
            text-decoration: none;
            letter-spacing: -0.5px;
        }

        .brand-logo-img {
            height: 80px;
            width: auto;
            object-fit: contain;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 15px;
        }

        .nav-menu li a {
            color: var(--dark-text);
            text-decoration: none;
            font-weight: 700;
            font-size: 0.95rem;
            padding: 10px 18px;
            border-radius: 8px;
            transition: 0.2s ease-in-out;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-menu li a:hover, .nav-menu li a.active {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .main-workspace {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 50px 20px;
            box-sizing: border-box;
        }
        
        .reg-container { 
            background: var(--white); 
            width: 100%;
            max-width: 700px; 
            margin: auto; 
            border-radius: 16px; 
            box-shadow: 0 10px 30px rgba(28, 45, 66, 0.04); 
            overflow: hidden; 
            border-top: 6px solid var(--mustard-yellow); 
        }

        .reg-header { 
            padding: 40px 40px 20px 40px; 
            background: var(--white); 
            text-align: center; 
        }

        .reg-header h2 { 
            margin: 0; 
            color: var(--dark-text); 
            font-size: 1.8rem; 
            font-weight: 900; 
            letter-spacing: -0.5px;
        }

        .reg-header span { 
            color: var(--softcare-blue); 
            font-weight: 800; 
            font-size: 0.85rem; 
            text-transform: uppercase; 
            letter-spacing: 1.5px; 
            display: block;
            margin-bottom: 8px;
        }

        .reg-body { padding: 20px 45px 45px 45px; }

        .form-group { margin-bottom: 24px; position: relative; }

        .form-group > i:first-of-type, .form-group > i.field-icon { 
            position: absolute; 
            left: 16px; 
            top: 44px; 
            color: var(--muted-text); 
            z-index: 5; 
            font-size: 1.05rem;
        }
        
        .form-group label { 
            display: block; 
            font-weight: 700; 
            margin-bottom: 9px; 
            color: var(--dark-text); 
            font-size: 0.85rem; 
            text-transform: uppercase; 
            letter-spacing: 0.3px;
        }

        .form-group input, 
        .form-group select, 
        .form-group textarea { 
            width: 100%; 
            padding: 14px 16px 14px 45px; 
            border: 2px solid var(--border-light); 
            border-radius: 8px; 
            box-sizing: border-box; 
            font-size: 1rem; 
            background: var(--cream-bg); 
            color: var(--dark-text); 
            transition: 0.2s ease-in-out;
            font-family: inherit;
        }

        .form-group input:focus, 
        .form-group select:focus, 
        .form-group textarea:focus { 
            border-color: var(--softcare-blue); 
            outline: none; 
            background: var(--white); 
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }

        .file-upload-box {
            border: 2px dashed var(--softcare-blue);
            background: var(--softcare-light-blue);
            border-radius: 8px;
            padding: 12px;
            box-sizing: border-box;
        }

        .file-upload-box input[type="file"] {
            padding: 8px;
            background: transparent;
            border: none;
        }
        
        .verification-warning {
            background-color: var(--alert-banner);
            color: var(--alert-text);
            padding: 15px 18px;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 20px;
            border-left: 5px solid var(--mustard-yellow);
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }

        .verification-warning i {
            margin-top: 2px;
            font-size: 1.1rem;
        }

        .password-input-wrapper { 
            position: relative; 
            display: flex; 
            width: 100%; 
            align-items: center; 
        }
        .password-input-wrapper input { 
            padding-left: 45px; 
            padding-right: 45px;
        }

        .password-toggle-icon { 
            position: absolute; 
            right: 16px; 
            top: 50%; 
            transform: translateY(-50%);
            color: var(--muted-text); 
            cursor: pointer; 
            transition: 0.2s; 
            font-size: 1.1rem; 
            z-index: 10; 
        }

        .password-toggle-icon:hover { color: var(--softcare-blue); }

        .btn-submit { 
            background: var(--softcare-blue); 
            color: var(--white); 
            border: none; 
            padding: 16px; 
            width: 100%; 
            border-radius: 8px; 
            font-weight: 800; 
            font-size: 1.05rem; 
            cursor: pointer; 
            transition: 0.2s ease-in-out; 
            margin-top: 15px; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
            box-shadow: 0 4px 12px rgba(0, 145, 223, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-submit:hover { 
            background: var(--dark-text); 
            color: var(--white); 
            box-shadow: 0 4px 12px rgba(28, 45, 66, 0.2);
        }

        .error-box { 
            background: #FFF5F5; 
            color: #E53E3E; 
            padding: 14px 18px; 
            border-radius: 8px; 
            margin-bottom: 25px; 
            font-weight: 600; 
            border: 1px solid #FED7D7;
            border-left: 5px solid #E53E3E; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 0.9rem;
        }

        .error-box i {
            font-size: 1.2rem;
        }

        .system-footer {
            background: var(--dark-text);
            color: #94A3B8;
            padding: 40px 25px 30px 25px;
            border-top: 4px solid var(--mustard-yellow);
            width: 100%;
            box-sizing: border-box;
        }

        .footer-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
        }

        .footer-column h5 {
            color: var(--white);
            font-size: 1.1rem;
            margin: 0 0 15px 0;
            font-weight: 700;
        }

        .footer-column p {
            font-size: 0.9rem;
            line-height: 1.6;
            margin: 0;
        }

        .footer-base {
            max-width: 1200px;
            margin: 30px auto 0 auto;
            border-top: 1px solid #2E3E52;
            padding-top: 20px;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .fee-sub-box {
            background: #F1F5F9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 15px;
            border-left: 4px solid var(--softcare-blue);
        }

        .fee-sub-box label {
            text-transform: none;
            font-size: 0.8rem;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .nav-container {
                padding: 0 15px;
                height: 65px;
                flex-wrap: wrap;
            }
            .brand-logo {
                font-size: 1.1rem;
            }
            .brand-logo-img {
                height: 50px;
            }
            .nav-menu {
                gap: 5px;
            }
            .nav-menu li a {
                font-size: 0.75rem;
                padding: 6px 10px;
            }
            .nav-menu li a span {
                display: none;
            }
            .reg-container {
                max-width: 100%;
                margin: 0 10px;
            }
            .reg-header {
                padding: 25px 20px 15px 20px;
            }
            .reg-header h2 {
                font-size: 1.3rem;
            }
            .reg-body {
                padding: 15px 20px 25px 20px;
            }
            .form-group {
                margin-bottom: 18px;
            }
            .form-group input, 
            .form-group select, 
            .form-group textarea {
                padding: 12px 14px 12px 40px;
                font-size: 0.9rem;
            }
            .form-group label {
                font-size: 0.75rem;
            }
            .form-group > i:first-of-type {
                top: 40px;
                left: 14px;
                font-size: 0.9rem;
            }
            .verification-warning {
                font-size: 0.8rem;
                padding: 12px 14px;
            }
            .btn-submit {
                font-size: 0.9rem;
                padding: 14px;
            }
            .footer-inner {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            .fee-sub-box {
                padding: 15px;
            }
        }

        @media (max-width: 480px) {
            .brand-logo {
                font-size: 0.9rem;
                gap: 8px;
            }
            .brand-logo-img {
                height: 40px;
            }
            .nav-menu li a {
                font-size: 0.65rem;
                padding: 4px 8px;
            }
            .nav-menu li a i {
                font-size: 0.8rem;
            }
            .reg-header h2 {
                font-size: 1.1rem;
            }
            .reg-header span {
                font-size: 0.7rem;
            }
            .reg-body {
                padding: 12px 15px 20px 15px;
            }
            .form-group input, 
            .form-group select, 
            .form-group textarea {
                padding: 10px 12px 10px 36px;
                font-size: 0.85rem;
            }
            .form-group > i:first-of-type {
                top: 36px;
                left: 12px;
                font-size: 0.8rem;
            }
            .file-upload-box input[type="file"] {
                font-size: 0.75rem;
                padding: 4px;
            }
        }
    </style>

    <script>
        // Tanzania Regions and Districts Data
        const regionsData = <?php echo json_encode($tanzania_regions); ?>;

        function updateUI() {
            var role = document.getElementById('role').value;
            var companySection = document.getElementById('company-section');
            var placementSection = document.getElementById('placement-section');
            
            if (role === 'company') {
                companySection.style.display = 'block';
                placementSection.style.display = 'none';
                toggleInputs(companySection, true);
                updateFeeFields();
            } else {
                companySection.style.display = 'none';
                placementSection.style.display = 'block';
                toggleInputs(companySection, false);
            }
        }

        function toggleInputs(container, status) {
            var inputs = container.querySelectorAll('input, select, textarea');
            for (var i = 0; i < inputs.length; i++) {
                if(inputs[i].classList.contains('fee-conditional-input')) continue;
                if (status) {
                    if(inputs[i].name !== 'website') {
                        inputs[i].setAttribute('required', 'required');
                    }
                } else {
                    inputs[i].removeAttribute('required');
                }
            }
        }

        function updateFeeFields() {
            var feeType = document.getElementById('has_fees').value;
            var regBox = document.getElementById('reg-fee-box');
            var costBox = document.getElementById('direct-cost-box');
            var reasonBox = document.getElementById('reason-fee-box');

            regBox.style.display = 'none';
            costBox.style.display = 'none';
            reasonBox.style.display = 'none';
            
            document.getElementById('reg_fee_amount').removeAttribute('required');
            document.getElementById('direct_cost_amount').removeAttribute('required');
            document.getElementById('fee_reason').removeAttribute('required');

            if(feeType !== 'None') {
                reasonBox.style.display = 'block';
                document.getElementById('fee_reason').setAttribute('required', 'required');
                
                if(feeType === 'Registration Only' || feeType === 'Both') {
                    regBox.style.display = 'block';
                    document.getElementById('reg_fee_amount').setAttribute('required', 'required');
                }
                if(feeType === 'Direct Cost Only' || feeType === 'Both') {
                    costBox.style.display = 'block';
                    document.getElementById('direct_cost_amount').setAttribute('required', 'required');
                }
            }
        }

        function updateDistricts() {
            var regionSelect = document.getElementById('region');
            var districtSelect = document.getElementById('district');
            var selectedRegion = regionSelect.value;
            
            // Clear current districts
            districtSelect.innerHTML = '';
            
            if (selectedRegion && regionsData[selectedRegion]) {
                var districts = regionsData[selectedRegion];
                // Add default option
                var defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = '-- Select District --';
                districtSelect.appendChild(defaultOption);
                
                // Add districts
                districts.forEach(function(district) {
                    var option = document.createElement('option');
                    option.value = district;
                    option.textContent = district;
                    districtSelect.appendChild(option);
                });
            } else {
                var defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = '-- Select Region First --';
                districtSelect.appendChild(defaultOption);
            }
        }

        function togglePassword(fieldId, iconElement) {
            const targetField = document.getElementById(fieldId);
            if (targetField.type === "password") {
                targetField.type = "text";
                iconElement.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                targetField.type = "password";
                iconElement.classList.replace("fa-eye-slash", "fa-eye");
            }
        }

        function validatePasswords() {
            const pass = document.getElementById('password').value;
            const confirmPass = document.getElementById('confirm_password').value;
            
            if (pass !== confirmPass) {
                alert("Validation Error: System Password fields do not match!");
                return false;
            }
            if (pass.length < 6) {
                alert("Validation Error: Password must contain at least 6 characters!");
                return false;
            }
            return true;
        }

        window.onload = function() { 
            updateUI(); 
            updateDistricts();
        };
    </script>
</head>
<body>

<header class="global-header">
    <div class="nav-container">
        <a href="index.php" class="brand-logo">
            <img src="images/logo.jpeg" alt="CareerConnect Logo" class="brand-logo-img"> CareerConnect
        </a>
        <ul class="nav-menu">
            <li><a href="index.php"><i class="fa-solid fa-house"></i> <span>Home</span></a></li>
            <li><a href="index.php#vacancies-section"><i class="fa-solid fa-briefcase"></i> <span>Vacancies</span></a></li>
            <li><a href="#feedback-section"><i class="fa-solid fa-comments"></i> <span>Feedback</span></a></li>
            <li><a href="login.php"><i class="fa-solid fa-right-to-bracket"></i> <span>Login</span></a></li>
            <li><a href="register.php" class="active"><i class="fa-solid fa-user-plus"></i> <span>Register</span></a></li>
        </ul>
    </div>
</header>

<div class="main-workspace">
    <div class="reg-container">
        <div class="reg-header">
            <span>Intelligent Corporate Gateway</span>
            <h2>Create New Account</h2>
        </div>
        
        <div class="reg-body">
            <?php if(!empty($error)): ?>
                <div class='error-box'><i class='fa-solid fa-circle-exclamation'></i> <?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data" onsubmit="return validatePasswords();">
                
                <div class="form-group">
                    <label>Account Role Profile</label>
                    <i class="fa-solid fa-users-gear"></i>
                    <select name="role" id="role" onchange="updateUI()" required>
                        <option value="student" <?php echo $student_allowed !== '1' ? 'disabled style="color:red;"' : ''; ?>>
                            IT Student <?php echo $student_allowed !== '1' ? '(Registration Closed)' : ''; ?>
                        </option>
                        <option value="company" <?php echo $company_allowed !== '1' ? 'disabled style="color:red;"' : ''; ?>>
                            Organization / Corporate Partner <?php echo $company_allowed !== '1' ? '(Registration Closed)' : ''; ?>
                        </option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Full Legal Name / Company Registered Title</label>
                    <i class="fa-solid fa-user"></i>
                    <input type="text" name="full_name" placeholder="Ex: John Smith or Softcare Ltd" required>
                </div>

                <div class="form-group">
                    <label>Official Email Address</label>
                    <i class="fa-solid fa-envelope"></i>
                    <input type="email" name="email" placeholder="example@domain.com" required>
                </div>

                <div class="form-group">
                    <label>System Password</label>
                    <i class="fa-solid fa-lock"></i>
                    <div class="password-input-wrapper">
                        <input type="password" id="password" name="password" placeholder="Minimum 6 characters" required>
                        <i class="fa-solid fa-eye password-toggle-icon" onclick="togglePassword('password', this)"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label>Confirm Password</label>
                    <i class="fa-solid fa-lock"></i>
                    <div class="password-input-wrapper">
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-enter your password" required>
                        <i class="fa-solid fa-eye password-toggle-icon" onclick="togglePassword('confirm_password', this)"></i>
                    </div>
                </div>

                <div id="placement-section">
                    <div class="form-group">
                        <label>Target Placement Type</label>
                        <i class="fa-solid fa-briefcase"></i>
                        <select name="placement_type">
                            <option value="Internship">Internship (Work-based)</option>
                            <option value="Field Study">Field Study (Practical Training)</option>
                        </select>
                    </div>
                </div>

                <div id="company-section" style="display:none;">
                    <div class="verification-warning">
                        <i class="fa-solid fa-shield-halved"></i>
                        <div>Only government-registered corporate profiles are permitted. Input data must precisely match your official business registry details.</div>
                    </div>

                    <div class="form-group">
                        <label>Business Registration Number (BRELA / Equivalent)</label>
                        <i class="fa-solid fa-id-card"></i>
                        <input type="text" name="reg_number" placeholder="Ex: 123456-X">
                    </div>

                    <div class="form-group">
                        <label>Tax Identification Number (TIN)</label>
                        <i class="fa-solid fa-file-invoice-dollar"></i>
                        <input type="text" name="tin_number" placeholder="Ex: 101-202-303">
                    </div>

                    <div class="form-group">
                        <label>Official Company Website</label>
                        <i class="fa-solid fa-globe"></i>
                        <input type="url" name="website" placeholder="https://www.yourcompany.co.tz">
                    </div>

                    <div class="form-group">
                        <label>Industry Sector</label>
                        <i class="fa-solid fa-industry"></i>
                        <input type="text" name="industry" placeholder="Ex: Telecommunications, Banking">
                    </div>

                    <!-- Tanzania Location Dropdowns -->
                    <div class="form-group">
                        <label>Region</label>
                        <i class="fa-solid fa-map-pin"></i>
                        <select name="region" id="region" onchange="updateDistricts()">
                            <option value="">-- Select Region --</option>
                            <?php foreach(array_keys($tanzania_regions) as $region): ?>
                                <option value="<?php echo $region; ?>"><?php echo $region; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>District</label>
                        <i class="fa-solid fa-location-dot"></i>
                        <select name="district" id="district">
                            <option value="">-- Select Region First --</option>
                        </select>
                    </div>

                    <div class="form-group" style="background: #F8FAFC; border: 2px solid var(--border-light); padding: 20px; border-radius: 8px;">
                        <label style="color: var(--softcare-blue); font-weight:800;"><i class="fa-solid fa-hand-holding-dollar"></i> Placement Fees Allocation Framework</label>
                        <p style="font-size:0.85rem; color: var(--muted-text); margin:0 0 15px 0;">Specify if students incur costs to join or operate parameters at your firm.</p>
                        
                        <select name="has_fees" id="has_fees" onchange="updateFeeFields()" style="background: var(--white);">
                            <option value="None">Our Organization Charges No Fees (100% Free Field Study)</option>
                            <option value="Registration Only">Requires Registration Fee Only</option>
                            <option value="Direct Cost Only">Requires Direct Operational Field Costs Only</option>
                            <option value="Both">Requires Both Registration Fee & Direct Cost</option>
                        </select>

                        <div id="reg-fee-box" class="fee-sub-box" style="display:none;">
                            <label>Registration Fee Amount (TZS)</label>
                            <div style="position:relative;">
                                <i class="fa-solid fa-money-bill-wave field-icon" style="top:14px; left:16px; position:absolute; color:var(--muted-text);"></i>
                                <input type="number" id="reg_fee_amount" name="reg_fee_amount" min="0" placeholder="Ex: 20000" class="fee-conditional-input" style="background:var(--white); padding-left:45px; width:100%;">
                            </div>
                        </div>

                        <div id="direct-cost-box" class="fee-sub-box" style="display:none;">
                            <label>Direct Cost Amount (TZS)</label>
                            <div style="position:relative;">
                                <i class="fa-solid fa-coins field-icon" style="top:14px; left:16px; position:absolute; color:var(--muted-text);"></i>
                                <input type="number" id="direct_cost_amount" name="direct_cost_amount" min="0" placeholder="Ex: 30000" class="fee-conditional-input" style="background:var(--white); padding-left:45px; width:100%;">
                            </div>
                        </div>

                        <div id="reason-fee-box" class="fee-sub-box" style="display:none;">
                            <label>Reason / Detailed Justification for Fees</label>
                            <div style="position:relative;">
                                <i class="fa-solid fa-circle-question field-icon" style="top:14px; left:16px; position:absolute; color:var(--muted-text);"></i>
                                <textarea id="fee_reason" name="fee_reason" rows="3" placeholder="Provide the specific explanation or services covered by this fee..." class="fee-conditional-input" style="background:var(--white); padding-left:45px; width:100%;"></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Upload Compliance Certificates (Combine BRELA License, TIN & CV into single PDF/ZIP)</label>
                        <i class="fa-solid fa-file-shield" style="top: 44px; left: 16px; position: absolute; color: var(--muted-text); z-index: 5;"></i>
                        <div class="file-upload-box">
                            <input type="file" name="verification_docs" accept=".pdf,.zip,.rar">
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-submit">
                    <i class="fa-solid fa-paper-plane"></i> Initialize Account
                </button>
            </form>
        </div>
    </div>
</div>

<footer id="feedback-section" class="system-footer">
    <div class="footer-inner">
        <div class="footer-column">
            <h5>About CareerConnect</h5>
            <p>Our centralized management architecture handles seamless, automated verification parameters connecting academic talent directly with corporate structures.</p>
        </div>
        <div class="footer-column">
            <h5>Technical Desk Support</h5>
            <p>Encountering user access restrictions or database profile lockouts? Connect directly with support teams at info@softcareplacement.co.tz.</p>
        </div>
    </div>
    <div class="footer-base">
        &copy; 2026 Softcare Intelligent Career Placement System. All Rights Reserved.
    </div>
</footer>

</body>
</html>