<?php
session_start();
include('includes/db_connect.php');

// Fetch ONLY open/active vacancies (closing_date >= today or no closing date)
$vacancies = [];
$e = null;

try {
    $vacancy_stmt = $pdo->prepare("
        SELECT 
            o.opp_id,
            o.title, 
            o.type AS opportunity_type, 
            o.slots AS slots_available, 
            o.closing_date, 
            o.required_gpa, 
            o.core_responsibilities,
            o.created_at,
            org.org_name AS company_name,
            org.location,
            org.industry
        FROM opportunities o
        LEFT JOIN organizations org ON o.company_id = org.org_id
        WHERE o.status = 'published' 
        AND (o.closing_date >= CURDATE() OR o.closing_date IS NULL)
        ORDER BY o.created_at DESC
    ");
    $vacancy_stmt->execute();
    $vacancies = $vacancy_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $ex) {
    $vacancies = [];
    $e = $ex;
}

// Helper: turns a closing_date into a friendly "time left" badge.
function vacancyDaysLeftBadge($closingDate) {
    if (empty($closingDate)) {
        return '<span class="days-badge badge-open"><i class="fa-regular fa-clock"></i> No Deadline</span>';
    }
    try {
        $today = new DateTime('today');
        $close = new DateTime($closingDate);
    } catch (Exception $ex) {
        return '';
    }
    $diffDays = (int)$today->diff($close)->format('%r%a');

    if ($close < $today) {
        return '<span class="days-badge badge-closed"><i class="fa-solid fa-lock"></i> Closed</span>';
    } elseif ($diffDays <= 3) {
        return '<span class="days-badge badge-urgent"><i class="fa-solid fa-triangle-exclamation"></i> ' . $diffDays . ' day' . ($diffDays == 1 ? '' : 's') . ' left</span>';
    } elseif ($diffDays <= 14) {
        return '<span class="days-badge badge-soon"><i class="fa-regular fa-clock"></i> ' . $diffDays . ' days left</span>';
    } else {
        return '<span class="days-badge badge-open"><i class="fa-regular fa-calendar"></i> ' . $close->format('M d, Y') . '</span>';
    }
}

$isLoggedIn = isset($_SESSION['user_id']);
$isStudent  = $isLoggedIn && isset($_SESSION['role']) && $_SESSION['role'] === 'student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Intelligent Career Placement System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           
            --border-light: #E2E8F0;
            --danger-red: #DC2626;
            --purple: #8B5CF6;
            --pink: #EC4899;
        }

        * { box-sizing: border-box; }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, sans-serif; 
            background: var(--cream-bg); 
            color: var(--dark-text);
            display: flex; 
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden;
        }

        a { -webkit-tap-highlight-color: transparent; }

        /* --- HORIZONTAL HEADER NAVIGATION --- */
        .global-header {
            background: var(--white);
            border-bottom: 3px solid var(--softcare-blue);
            box-shadow: 0 4px 20px rgba(0, 145, 223, 0.06);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
            position: relative;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 900;
            color: #000000; 
            text-decoration: none;
            letter-spacing: -0.5px;
        }

        .brand-logo-img {
            height: 56px;
            width: auto;
            object-fit: contain;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 15px;
        }

        .nav-menu li a {
            color: var(--dark-text);
            text-decoration: none;
            font-weight: 700;
            font-size: 0.95rem;
            padding: 10px 18px;
            border-radius: 8px;
            transition: 0.2s ease-in-out;
            display: flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }

        .nav-menu li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .nav-menu li a.active-link {
            background: var(--softcare-blue);
            color: var(--white);
        }

        .btn-login-nav {
            background: var(--softcare-blue) !important;
            color: var(--white) !important;
            border-bottom: 2px solid #00669e;
        }

        .nav-toggle {
            display: none;
            background: var(--softcare-light-blue);
            border: none;
            color: var(--softcare-blue);
            width: 44px;
            height: 44px;
            border-radius: 8px;
            font-size: 1.2rem;
            cursor: pointer;
            align-items: center;
            justify-content: center;
        }

        /* --- HERO BANNER --- */
        .hero-banner {
            text-align: center;
            padding: 110px 20px; 
            margin: 0 auto 40px auto;
            max-width: 1150px;
            width: 100%;
            border-radius: 20px;
            background:
                linear-gradient(180deg, rgba(11, 26, 46, 0.55) 0%, rgba(11, 26, 46, 0.72) 100%),
                url('images/career.jpeg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            box-shadow: 0 12px 40px rgba(0, 145, 223, 0.15);
            box-sizing: border-box;
            position: relative;
        }

        .hero-subtitle { 
            color: var(--mustard-yellow); 
            font-weight: 800; 
            text-transform: uppercase; 
            letter-spacing: 2px;
            font-size: 0.95rem;
            margin-bottom: 15px;
            display: block;
        }

        .hero-title { 
            color: var(--white); 
            font-size: clamp(2rem, 5vw, 3.2rem); 
            font-weight: 900;
            margin: 0 0 20px 0;
            letter-spacing: -1px;
            line-height: 1.15;
        }

        .hero-desc {
            color: #FFFFFF; 
            max-width: 700px;
            font-size: clamp(1rem, 2.2vw, 1.25rem);
            margin: 0 auto 32px auto;
            line-height: 1.7;
            font-weight: 600;
        }

        .hero-cta-row {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .hero-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 13px 26px;
            border-radius: 8px;
            font-weight: 800;
            font-size: 0.95rem;
            text-decoration: none;
            transition: 0.2s;
        }

        .hero-btn-primary {
            background: var(--mustard-yellow);
            color: var(--dark-text);
        }
        .hero-btn-primary:hover { background: #ffb733; transform: translateY(-2px); }

        .hero-btn-secondary {
            background: rgba(255,255,255,0.12);
            color: var(--white);
            border: 1.5px solid rgba(255,255,255,0.7);
            backdrop-filter: blur(2px);
        }
        .hero-btn-secondary:hover { background: rgba(255,255,255,0.25); transform: translateY(-2px); }

        /* --- SEARCH VACANCIES BAR --- */
        .search-shell {
            max-width: 1150px;
            width: 100%;
            margin: -60px auto 40px auto;
            padding: 0 25px;
            box-sizing: border-box;
            position: relative;
            z-index: 5;
        }

        .search-card {
            background: var(--white);
            border-radius: 16px;
            box-shadow: 0 10px 35px rgba(28, 45, 66, 0.14);
            border: 1px solid var(--border-light);
            padding: 22px;
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
            align-items: center;
        }

        .search-field {
            flex: 1 1 260px;
            display: flex;
            align-items: center;
            gap: 10px;
            background: var(--cream-bg);
            border: 1.5px solid var(--border-light);
            border-radius: 10px;
            padding: 12px 16px;
        }

        .search-field i { color: var(--softcare-blue); }

        .search-field input {
            border: none;
            background: transparent;
            outline: none;
            font-size: 0.95rem;
            width: 100%;
            color: var(--dark-text);
            font-family: inherit;
        }

        .search-select {
            flex: 0 1 200px;
            padding: 13px 16px;
            border-radius: 10px;
            border: 1.5px solid var(--border-light);
            background: var(--cream-bg);
            color: var(--dark-text);
            font-weight: 700;
            font-size: 0.9rem;
            font-family: inherit;
            cursor: pointer;
        }

        .search-btn {
            flex: 0 0 auto;
            background: var(--softcare-blue);
            color: var(--white);
            border: none;
            padding: 13px 24px;
            border-radius: 10px;
            font-weight: 800;
            font-size: 0.95rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }
        .search-btn:hover { background: #0077b8; }

        /* --- VACANCY GRID --- */
        .vacancies-section {
            max-width: 1200px;
            margin: 0 auto 40px auto;
            padding: 0 25px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .section-header h2 {
            margin: 0;
            font-size: 1.6rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-header h2 i {
            color: var(--softcare-blue);
        }

        .section-header .count-badge {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 700;
        }

        .vacancy-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 24px;
        }

        /* --- ATTRACTIVE VACANCY CARD --- */
        .vacancy-card {
            background: var(--white);
            border-radius: 16px;
            border: 1px solid var(--border-light);
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            display: flex;
            flex-direction: column;
        }

        .vacancy-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 16px 40px rgba(0, 145, 223, 0.12);
            border-color: var(--softcare-blue);
        }

        .card-header-gradient {
            padding: 18px 22px;
            background: linear-gradient(135deg, var(--softcare-blue), #0066a0);
            color: var(--white);
            position: relative;
        }

        .card-header-gradient .company-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,255,255,0.15);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .card-header-gradient h3 {
            margin: 0;
            font-size: 1.15rem;
            font-weight: 800;
            line-height: 1.3;
        }

        .card-header-gradient .company-name {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.85rem;
            font-weight: 600;
            opacity: 0.9;
            margin-top: 4px;
        }

        .card-body {
            padding: 20px 22px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .card-body .badge-row {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 12px;
        }

        .type-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 0.68rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .badge-internship { background: #E0F2FE; color: #0369A1; }
        .badge-field { background: #DCFCE7; color: #15803D; }

        .slots-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 0.68rem;
            font-weight: 800;
            background: #FEF3C7;
            color: #92400E;
        }

        .gpa-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 0.68rem;
            font-weight: 800;
            background: #F3E8FF;
            color: #6D28D9;
        }

        .card-body .description {
            font-size: 0.85rem;
            color: var(--muted-text);
            line-height: 1.6;
            margin: 0 0 16px 0;
            flex: 1;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .card-footer {
            padding: 14px 22px;
            background: var(--milky-white);
            border-top: 1px solid var(--border-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .card-footer .days-badge {
            font-size: 0.7rem;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .badge-open { background: #E0F2FE; color: #0369A1; }
        .badge-soon { background: #FEF3C7; color: #92400E; }
        .badge-urgent { background: #FEE2E2; color: #B91C1C; }
        .badge-closed { background: #F1F5F9; color: #64748B; }

        .btn-apply {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.82rem;
            text-decoration: none;
            transition: 0.2s;
            background: var(--softcare-blue);
            color: var(--white);
            border: none;
            cursor: pointer;
        }

        .btn-apply:hover {
            background: #0077b8;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 145, 223, 0.3);
        }

        .btn-apply i {
            font-size: 0.8rem;
        }

        .btn-apply.login-required {
            background: var(--border-light);
            color: var(--muted-text);
        }

        .btn-apply.login-required:hover {
            background: var(--softcare-blue);
            color: var(--white);
        }

        .no-vacancies {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted-text);
        }

        .no-vacancies i {
            font-size: 3rem;
            color: var(--border-light);
            margin-bottom: 15px;
            display: block;
        }

        .no-vacancies h4 {
            margin: 0 0 8px 0;
            color: var(--dark-text);
        }

        /* --- SYSTEM FOOTER --- */
        .system-footer {
            background: var(--dark-text);
            color: #94A3B8;
            padding: 55px 25px 0 25px;
            border-top: 4px solid var(--mustard-yellow);
            margin-top: auto;
        }

        .footer-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1.4fr 1fr 1fr 1fr;
            gap: 40px;
            text-align: left;
            padding-bottom: 40px;
        }

        .footer-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 16px;
        }
        .footer-brand img { height: 34px; width: auto; }
        .footer-brand span { color: var(--white); font-weight: 900; font-size: 1.15rem; }

        .footer-column h5 {
            color: var(--white);
            font-size: 1rem;
            margin: 0 0 20px 0;
            font-weight: 700;
            letter-spacing: 0.3px;
        }

        .footer-column p {
            font-size: 0.88rem;
            line-height: 1.7;
            margin: 0 0 18px 0;
        }

        .footer-social {
            display: flex;
            gap: 10px;
        }
        .footer-social a {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            background: rgba(255,255,255,0.06);
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: 0.2s;
            font-size: 0.9rem;
        }
        .footer-social a:hover { background: var(--softcare-blue); transform: translateY(-2px); }

        .footer-links-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links-list li {
            margin-bottom: 13px;
            font-size: 0.88rem;
        }

        .footer-links-list li a {
            color: #94A3B8;
            text-decoration: none;
            transition: 0.2s;
        }
        .footer-links-list li a:hover { color: var(--white); padding-left: 3px; }

        .footer-contact-list li {
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }
        .footer-contact-list i { margin-top: 3px; width: 14px; }

        .footer-base {
            max-width: 1200px;
            margin: 0 auto;
            border-top: 1px solid #334155;
            padding: 22px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .footer-base a { color: #94A3B8; text-decoration: none; }
        .footer-base a:hover { color: var(--white); }

        .back-to-top {
            width: 38px;
            height: 38px;
            border-radius: 8px;
            background: rgba(255,255,255,0.06);
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: 0.2s;
        }
        .back-to-top:hover { background: var(--softcare-blue); }

        /* ============ MOBILE RESPONSIVENESS ============ */
        @media (max-width: 900px) {
            .footer-inner { grid-template-columns: 1fr 1fr; }
            .vacancy-grid { grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); }
        }

        @media (max-width: 768px) {
            .nav-toggle { display: flex; }

            .nav-menu {
                display: none;
                position: absolute;
                top: 80px;
                left: 0;
                right: 0;
                background: var(--white);
                flex-direction: column;
                align-items: stretch;
                gap: 4px;
                padding: 14px 20px 20px 20px;
                box-shadow: 0 12px 20px rgba(0,0,0,0.06);
                border-top: 1px solid var(--border-light);
            }

            .nav-menu.nav-menu-open { display: flex; }

            .nav-menu li a { width: 100%; padding: 12px 14px; }

            .hero-banner { padding: 70px 18px; border-radius: 14px; }

            .search-shell { margin-top: -40px; }
            .search-card { padding: 16px; }
            .search-select, .search-btn { flex: 1 1 100%; }

            .vacancy-grid { grid-template-columns: 1fr; }

            .footer-inner { grid-template-columns: 1fr; gap: 30px; padding-bottom: 30px; }
            .footer-base { flex-direction: column; text-align: center; }
        }

        @media (max-width: 480px) {
            .nav-container { height: 68px; }
            .brand-logo-img { height: 42px; }
            .brand-logo { font-size: 1.15rem; }
            .hero-title { letter-spacing: -0.5px; }
            .hero-cta-row { flex-direction: column; align-items: stretch; }
            .hero-btn { justify-content: center; }
            .vacancy-grid { grid-template-columns: 1fr; }
            .card-header-gradient h3 { font-size: 1rem; }
        }
    </style>
</head>
<body>

<header class="global-header">
    <div class="nav-container">
        <a href="index.php" class="brand-logo">
            <img src="images/logo.jpeg" alt="CareerConnect Logo" class="brand-logo-img"> CareerConnect
        </a>

        <button class="nav-toggle" id="navToggle" aria-label="Toggle menu" aria-expanded="false">
            <i class="fa-solid fa-bars"></i>
        </button>
        
        <ul class="nav-menu" id="navMenu">
            <li><a href="index.php" class="active-link"><i class="fa-solid fa-house"></i> Home</a></li>
            <?php if ($isLoggedIn): ?>
                <?php if ($isStudent): ?>
                    <li><a href="student/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
                <?php else: ?>
                    <li><a href="company/dashboard.php"><i class="fa-solid fa-building"></i> Dashboard</a></li>
                <?php endif; ?>
                <li><a href="logout.php"><i class="fa-solid fa-power-off"></i> Sign Out</a></li>
            <?php else: ?>
                <li><a href="register.php"><i class="fa-solid fa-user-plus"></i> Join Us</a></li>
                <li><a href="login.php" class="btn-login-nav"><i class="fa-solid fa-right-to-bracket"></i> Account Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
</header>

<div style="max-width: 1200px; width: 100%; margin: 40px auto 0 auto; padding: 0 25px; box-sizing: border-box;">
    <section class="hero-banner">
        <span class="hero-subtitle">Intelligent Career Placement Engine</span>
        <h1 class="hero-title">Your Next Tech Move Begins Here</h1>
        <p class="hero-desc">
            An intuitive database integration matching top academic IT students directly to verified enterprise networks and local internship systems.
        </p>
        <div class="hero-cta-row">
            <a href="#vacancies" class="hero-btn hero-btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Browse Vacancies</a>
            <?php if (!$isLoggedIn): ?>
                <a href="register.php" class="hero-btn hero-btn-secondary"><i class="fa-solid fa-user-plus"></i> Create an Account</a>
            <?php endif; ?>
        </div>
    </section>
</div>

<!-- Search Bar -->
<div class="search-shell">
    <div class="search-card">
        <div class="search-field">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="vacancySearchInput" placeholder="Search by job title or company...">
        </div>
        <select id="vacancyTypeFilter" class="search-select">
            <option value="all">All Types</option>
            <option value="Internship">Internship</option>
            <option value="Field Study">Field Study</option>
        </select>
        <button class="search-btn" id="vacancySearchBtn"><i class="fa-solid fa-filter"></i> Search</button>
    </div>
</div>

<!-- Vacancies Section -->
<section class="vacancies-section" id="vacancies">
    <div class="section-header">
        <h2><i class="fa-solid fa-briefcase"></i> Available Opportunities</h2>
        <span class="count-badge"><i class="fa-regular fa-circle"></i> <?php echo count($vacancies); ?> Openings</span>
    </div>

    <?php if (empty($vacancies)): ?>
        <div class="no-vacancies">
            <i class="fa-regular fa-circle-check"></i>
            <h4>No Open Positions Available</h4>
            <p>Check back later for new opportunities from our partner organizations.</p>
        </div>
    <?php else: ?>
        <div class="vacancy-grid" id="vacancyGrid">
            <?php foreach ($vacancies as $row): 
                $companyName = $row['company_name'] ?? 'Partner Enterprise';
                $initials = strtoupper(substr(trim($companyName), 0, 1));
                $typeBadgeClass = $row['opportunity_type'] === 'Internship' ? 'badge-internship' : 'badge-field';
                $gpa = $row['required_gpa'] !== null && $row['required_gpa'] !== '' ? number_format((float)$row['required_gpa'], 2) : 'N/A';
            ?>
                <div class="vacancy-card" data-title="<?php echo strtolower($row['title']); ?>" data-company="<?php echo strtolower($companyName); ?>" data-type="<?php echo $row['opportunity_type']; ?>">
                    <div class="card-header-gradient">
                        <div class="company-badge">
                            <i class="fa-regular fa-building"></i> <?php echo htmlspecialchars($row['industry'] ?? 'Corporate Partner'); ?>
                        </div>
                        <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                        <div class="company-name">
                            <i class="fa-regular fa-user"></i> <?php echo htmlspecialchars($companyName); ?>
                            <i class="fa-regular fa-location-dot" style="margin-left:8px;"></i> <?php echo htmlspecialchars($row['location'] ?? 'Tanzania'); ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="badge-row">
                            <span class="type-badge <?php echo $typeBadgeClass; ?>">
                                <i class="fa-solid fa-briefcase"></i> <?php echo htmlspecialchars($row['opportunity_type']); ?>
                            </span>
                            <?php if (isset($row['slots_available']) && $row['slots_available'] !== null && $row['slots_available'] > 0): ?>
                                <span class="slots-badge"><i class="fa-regular fa-user"></i> <?php echo (int)$row['slots_available']; ?> slots</span>
                            <?php endif; ?>
                            <span class="gpa-badge"><i class="fa-regular fa-star"></i> GPA <?php echo $gpa; ?></span>
                        </div>
                        <p class="description"><?php echo htmlspecialchars($row['core_responsibilities'] ?? 'No description available.'); ?></p>
                    </div>
                    <div class="card-footer">
                        <?php echo vacancyDaysLeftBadge($row['closing_date'] ?? null); ?>
                        <?php if ($isStudent): ?>
                            <a href="student/apply.php?opp_id=<?php echo $row['opp_id']; ?>" class="btn-apply">
                                <i class="fa-regular fa-paper-plane"></i> Apply Now
                            </a>
                        <?php else: ?>
                            <a href="login.php" class="btn-apply login-required">
                                <i class="fa-solid fa-lock"></i> Login to Apply
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<footer class="system-footer">
    <div class="footer-inner">
        <div class="footer-column">
            <div class="footer-brand">
                <img src="images/logo.jpeg" alt="CareerConnect Logo">
                <span>CareerConnect</span>
            </div>
            <p>
                A specialized platform designed to bridge the gap between brilliant IT students looking for field study positions and verified corporate organizations.
            </p>
            <div class="footer-social">
                <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
                <a href="#" aria-label="X / Twitter"><i class="fa-brands fa-x-twitter"></i></a>
                <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
            </div>
        </div>

        <div class="footer-column">
            <h5>Quick Links</h5>
            <ul class="footer-links-list">
                <li><a href="index.php">Home</a></li>
                <li><a href="#vacancies">Browse Vacancies</a></li>
                <li><a href="register.php">Join Us</a></li>
                <li><a href="login.php">Account Login</a></li>
            </ul>
        </div>

        <div class="footer-column">
            <h5>Get In Touch</h5>
            <ul class="footer-links-list footer-contact-list">
                <li><i class="fa-solid fa-envelope" style="color: var(--softcare-blue);"></i> info@careplacement.co.tz</li>
                <li><i class="fa-solid fa-phone" style="color: var(--aloe-green);"></i> +255 712 345 678</li>
            </ul>
        </div>

        <div class="footer-column">
            <h5>Our Location</h5>
            <ul class="footer-links-list footer-contact-list">
                <li><i class="fa-solid fa-map-location-dot" style="color: var(--mustard-yellow);"></i> Main Corporate Hub, 3rd Floor</li>
                <li><i class="fa-solid fa-city" style="color: var(--mustard-yellow);"></i> Dar es Salaam, Tanzania</li>
            </ul>
        </div>
    </div>
    <div class="footer-base">
        <span>&copy; <?php echo date('Y'); ?> CareerConnect &mdash; Intelligent Career Placement System. All Rights Reserved.</span>
        <a href="#top" class="back-to-top" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></a>
    </div>
</footer>

<script>
    // Mobile nav toggle
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    navToggle.addEventListener('click', () => {
        const isOpen = navMenu.classList.toggle('nav-menu-open');
        navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        navToggle.innerHTML = isOpen ? '<i class="fa-solid fa-xmark"></i>' : '<i class="fa-solid fa-bars"></i>';
    });

    // Search functionality
    const searchInput = document.getElementById('vacancySearchInput');
    const typeFilter = document.getElementById('vacancyTypeFilter');
    const searchBtn = document.getElementById('vacancySearchBtn');
    const vacancyGrid = document.getElementById('vacancyGrid');
    const allCards = vacancyGrid ? vacancyGrid.querySelectorAll('.vacancy-card') : [];

    function filterVacancies() {
        const query = searchInput.value.toLowerCase().trim();
        const type = typeFilter.value;

        allCards.forEach(card => {
            const title = card.dataset.title || '';
            const company = card.dataset.company || '';
            const cardType = card.dataset.type || '';

            const matchesQuery = !query || title.includes(query) || company.includes(query);
            const matchesType = type === 'all' || cardType === type;

            card.style.display = (matchesQuery && matchesType) ? '' : 'none';
        });
    }

    searchBtn.addEventListener('click', filterVacancies);
    typeFilter.addEventListener('change', filterVacancies);
    searchInput.addEventListener('input', filterVacancies);
    searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') filterVacancies();
    });
</script>

</body>
</html>