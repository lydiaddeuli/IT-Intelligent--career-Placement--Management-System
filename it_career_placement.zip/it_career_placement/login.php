<?php
session_start();
include('includes/db_connect.php');

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Set Session Variables
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];

        // Role-Based Redirection
        if ($user['role'] === 'admin') {
            header("Location: admin/dashboard.php");
        } elseif ($user['role'] === 'company') {
            header("Location: company/dashboard.php");
        } else {
            header("Location: student/dashboard.php");
        }
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Universal Login | CareerConnect Placement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            /* Softcare Package Palette Integration Matrix */
            --softcare-blue: #0091DF;      /* Primary Brand Blue */
            --softcare-light-blue: #E6F4FC;/* Accent fresh background tint */
            --aloe-green: #008543;         
            --mustard-yellow: #F59E0B;     /* Beautiful contrast highlight */
            --dark-text: #1C2D42;          /* Readable deep blue-grey text */
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           /* Ultra Clean background structure */
            --border-light: #E2E8F0;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--cream-bg);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: var(--dark-text);
        }

        /* --- HORIZONTAL HEADER NAVIGATION CONTROLLER --- */
        .global-header {
            background: var(--white);
            border-bottom: 3px solid var(--softcare-blue);
            box-shadow: 0 4px 20px rgba(0, 145, 223, 0.06);
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
            box-sizing: border-box;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 900;
            color: #000000; /* Solid Deep Black */
            text-decoration: none;
            letter-spacing: -0.5px;
        }

        .brand-logo-img {
            height: 80px;
            width: auto;
            object-fit: contain;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 15px;
        }

        .nav-menu li a {
            color: var(--dark-text);
            text-decoration: none;
            font-weight: 700;
            font-size: 0.95rem;
            padding: 10px 18px;
            border-radius: 8px;
            transition: 0.2s ease-in-out;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-menu li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        /* Unified Portal Link Setup active style */
        .btn-login-nav {
            background: var(--softcare-blue) !important;
            color: var(--white) !important;
            border-bottom: 2px solid #00669e;
        }

        /* --- CARD WORKSPACE WRAPPER --- */
        .login-wrapper {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
        }

        .login-card {
            background: var(--white);
            padding: 45px 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(28, 45, 66, 0.04);
            width: 100%;
            max-width: 420px;
            border-top: 6px solid var(--mustard-yellow); /* Top border accent block */
            box-sizing: border-box;
        }

        .login-card h2 {
            text-align: center;
            color: var(--dark-text);
            margin: 0 0 10px 0;
            font-size: 1.8rem;
            font-weight: 900;
            letter-spacing: -0.5px;
        }

        .login-subtitle {
            text-align: center;
            color: var(--muted-text);
            font-size: 0.95rem;
            margin-bottom: 35px;
        }

        .form-group {
            margin-bottom: 24px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 9px;
            font-weight: 700;
            color: var(--dark-text);
            font-size: 0.9rem;
        }

        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid var(--border-light);
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 1rem;
            transition: 0.2s ease-in-out;
            color: var(--dark-text);
            background-color: var(--cream-bg);
        }

        .form-group input:focus {
            border-color: var(--softcare-blue);
            background-color: var(--white);
            outline: none;
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }

        /* Password Toggle Styling */
        .password-wrapper {
            position: relative;
        }

        .form-group .password-wrapper input {
            padding-right: 45px;
        }

        .toggle-password {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--muted-text);
            transition: 0.2s;
            font-size: 1.1rem;
        }

        .toggle-password:hover {
            color: var(--softcare-blue);
        }

        .btn-login {
            width: 100%;
            padding: 15px;
            background-color: var(--softcare-blue);
            color: var(--white);
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 800;
            cursor: pointer;
            transition: 0.2s ease-in-out;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 12px rgba(240, 90, 20, 0.2);
        }

        .btn-login:hover {
            background-color: var(--dark-text);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(28, 45, 66, 0.2);
        }

        .footer-links {
            margin-top: 30px;
            text-align: center;
            font-size: 0.95rem;
            color: var(--muted-text);
            border-top: 1px solid var(--border-light);
            padding-top: 20px;
        }

        .footer-links a {
            color: var(--softcare-blue);
            text-decoration: none;
            font-weight: 700;
        }

        .footer-links a:hover {
            color: var(--dark-text);
            text-decoration: underline;
        }

        .error-msg {
            background: #FFF5F5;
            color: #E53E3E;
            padding: 14px;
            border-radius: 8px;
            margin-bottom: 25px;
            text-align: center;
            font-size: 0.9rem;
            font-weight: 600;
            border: 1px solid #FED7D7;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        /* --- SYSTEM UTILITY FOOTER --- */
        .system-footer {
            background: var(--dark-text);
            color: #94A3B8;
            padding: 40px 25px 30px 25px;
            border-top: 4px solid var(--mustard-yellow);
            width: 100%;
            box-sizing: border-box;
        }

        .footer-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
            text-align: left;
        }

        .footer-column h5 {
            color: var(--white);
            font-size: 1.1rem;
            margin: 0 0 15px 0;
            font-weight: 700;
        }

        .footer-column p {
            font-size: 0.9rem;
            line-height: 1.6;
            margin: 0;
        }

        .footer-base {
            max-width: 1200px;
            margin: 30px auto 0 auto;
            border-top: 1px solid #2E3E52;
            padding-top: 20px;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 600;
        }
    </style>
</head>
<body>

<header class="global-header">
    <div class="nav-container">
        <a href="index.php" class="brand-logo">
            <img src="images/logo.jpeg" alt="CareerConnect Logo" class="brand-logo-img"> CareerConnect
        </a>
        
        <ul class="nav-menu">
            <li><a href="index.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="index.php#vacancies-section"><i class="fa-solid fa-briefcase"></i> Vacancies</a></li>
            <li><a href="#feedback-section"><i class="fa-solid fa-comments"></i> Feedback</a></li>
            
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php"><i class="fa-solid fa-power-off"></i> Sign Out</a></li>
            <?php else: ?>
                <li><a href="register.php"><i class="fa-solid fa-user-plus"></i> Join Us</a></li>
                <li><a href="login.php" class="btn-login-nav"><i class="fa-solid fa-right-to-bracket"></i> Account Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
</header>

<div class="login-wrapper">
    <div class="login-card">
        <h2>Account Portal</h2>
        <div class="login-subtitle">Sign in to access your placement workstation</div>

        <?php if ($error): ?>
            <div class="error-msg">
                <i class="fa-solid fa-circle-exclamation"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="name@domain.com" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="password-field" placeholder="••••••••" required>
                    <i class="fa-solid fa-eye toggle-password" id="toggle-eye"></i>
                </div>
            </div>

            <div style="text-align: right; margin-bottom: 25px;">
                <a href="forgot_password.php" style="color: var(--softcare-blue); font-size: 0.85rem; text-decoration: none; font-weight: 700;">Forgot Password?</a>
            </div>

            <button type="submit" class="btn-login">Sign In</button>
        </form>

        <div class="footer-links">
            <p>Don't have an account? <a href="register.php">Create it now</a></p>
        </div>
    </div>
</div>

<footer id="feedback-section" class="system-footer">
    <div class="footer-inner">
        <div class="footer-column">
            <h5>About CareerConnect</h5>
            <p>Our centralized management architecture handles seamless, automated verification parameters connecting academic talent directly with corporate structures.</p>
        </div>
        <div class="footer-column">
            <h5>Technical Desk Support</h5>
            <p>Encountering user access restrictions or database profile lockouts? Connect directly with support teams at info@softcareplacement.co.tz.</p>
        </div>
    </div>
    <div class="footer-base">
        &copy; 2026 Softcare Intelligent Career Placement System. All Rights Reserved.
    </div>
</footer>

<script>
    const toggleEye = document.querySelector('#toggle-eye');
    const passwordField = document.querySelector('#password-field');

    toggleEye.addEventListener('click', function () {
        const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);
        
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
</script>

</body>
</html>