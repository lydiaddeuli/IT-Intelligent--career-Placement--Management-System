<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];
$display_title = "System Admin";
$admin_avatar = "https://ui-avatars.com/api/?name=Admin&background=0091DF&color=fff&size=40";

try {
    $admin_stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $admin_stmt->execute([$admin_id]);
    $admin_profile = $admin_stmt->fetch();
    if ($admin_profile) {
        if (isset($admin_profile['username'])) { $display_title = htmlspecialchars($admin_profile['username']); }
        elseif (isset($admin_profile['email'])) { $display_title = htmlspecialchars(explode('@', $admin_profile['email'])[0]); }
        if (!empty($admin_profile['profile_pic'])) { $admin_avatar = "../" . $admin_profile['profile_pic']; }
    }
} catch (PDOException $e) {}

// Check if is_blocked column exists, if not add it
try {
    $check_column = $pdo->query("SHOW COLUMNS FROM users LIKE 'is_blocked'");
    if ($check_column->rowCount() == 0) {
        $pdo->exec("ALTER TABLE users ADD COLUMN is_blocked TINYINT(1) DEFAULT 0");
    }
} catch (PDOException $e) {}

// Handle Block/Unblock
if (isset($_GET['block_id'])) {
    $user_id = intval($_GET['block_id']);
    try {
        $update = $pdo->prepare("UPDATE users SET is_blocked = 1 WHERE user_id = ?");
        $update->execute([$user_id]);
        $_SESSION['user_success'] = "User blocked successfully!";
    } catch(PDOException $e) {
        $_SESSION['user_success'] = "Error blocking user: " . $e->getMessage();
    }
    header("Location: view_users.php");
    exit();
}

if (isset($_GET['unblock_id'])) {
    $user_id = intval($_GET['unblock_id']);
    try {
        $update = $pdo->prepare("UPDATE users SET is_blocked = 0 WHERE user_id = ?");
        $update->execute([$user_id]);
        $_SESSION['user_success'] = "User unblocked successfully!";
    } catch(PDOException $e) {
        $_SESSION['user_success'] = "Error unblocking user: " . $e->getMessage();
    }
    header("Location: view_users.php");
    exit();
}

// Filter Logic
$role_filter = $_GET['role'] ?? 'all';
$status_filter = $_GET['status'] ?? 'all';

$query = "SELECT u.user_id, u.full_name, u.email, u.role, u.created_at, 
          COALESCE(u.is_blocked, 0) as is_blocked,
          COALESCE(sp.placement_type, 'N/A') as placement_type,
          COALESCE(o.org_name, 'N/A') as company_name
          FROM users u
          LEFT JOIN student_profiles sp ON u.user_id = sp.student_id
          LEFT JOIN organizations o ON u.user_id = o.org_id
          WHERE 1=1";
$params = [];

if ($role_filter === 'student') {
    $query .= " AND u.role = 'student'";
} elseif ($role_filter === 'company') {
    $query .= " AND u.role = 'company'";
}

if ($status_filter === 'blocked') {
    $query .= " AND COALESCE(u.is_blocked, 0) = 1";
} elseif ($status_filter === 'active') {
    $query .= " AND COALESCE(u.is_blocked, 0) = 0";
}

$query .= " ORDER BY u.role DESC, u.user_id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count statistics
$total_users = count($users);
$active_count = 0;
$blocked_count = 0;
$student_count = 0;
$company_count = 0;

foreach ($users as $user) {
    if (($user['is_blocked'] ?? 0) == 1) {
        $blocked_count++;
    } else {
        $active_count++;
    }
    if ($user['role'] === 'student') $student_count++;
    if ($user['role'] === 'company') $company_count++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users Hub | Admin Workspace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F9F9FB;           
            --border-light: #E2E8F0;
            --alert-red: #EF4444;
            --aloe-green: #008543;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }

        /* --- SIDEBAR --- */
        .admin-sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu-container { 
            flex: 1; 
            overflow-y: auto; 
            padding: 15px 0; 
            background: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 0; 
            margin: 0; 
        }
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        /* --- MAIN CONTENT --- */
        .admin-container { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--cream-bg);
        }

        /* --- TOP HEADER --- */
        .admin-top-header { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .admin-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .admin-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        /* Profile Dropdown */
        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--cream-bg);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        /* --- PAGE CONTENT --- */
        .admin-main { 
            padding: 30px 35px; 
        }

        .admin-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .admin-page-header h2 { 
            margin: 0; 
            font-weight: 800; 
            font-size: 1.4rem; 
        }
        .admin-page-header h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }

        /* Status Summary Cards */
        .summary-dashboard-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .metric-card-box {
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }

        .metric-card-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        }

        .metric-card-box .metric-info h5 {
            margin: 0 0 2px 0;
            font-size: 0.7rem;
            color: var(--muted-text);
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
        }

        .metric-card-box .metric-info .metric-val {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .metric-card-box .metric-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: var(--white);
            flex-shrink: 0;
        }

        .metric-card-box .metric-icon.total { background: var(--softcare-blue); }
        .metric-card-box .metric-icon.student { background: var(--mustard-yellow); }
        .metric-card-box .metric-icon.company { background: var(--aloe-green); }
        .metric-card-box .metric-icon.blocked { background: var(--alert-red); }

        /* Filter Navigation */
        .filter-nav {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-btn {
            padding: 8px 18px;
            border-radius: 6px;
            border: 1px solid var(--border-light);
            background: var(--white);
            text-decoration: none;
            color: var(--dark-text);
            font-weight: 600;
            font-size: 0.82rem;
            transition: 0.2s;
        }

        .filter-btn:hover {
            background: var(--softcare-light-blue);
            border-color: var(--softcare-blue);
        }

        .filter-btn.active {
            background: var(--softcare-blue);
            color: white;
            border-color: var(--softcare-blue);
        }

        /* Table Card */
        .data-table-card { 
            background: var(--white); 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.02); 
            border: 1px solid var(--border-light);
            overflow: hidden; 
        }

        .table-responsive { 
            width: 100%; 
            overflow-x: auto; 
        }

        table { 
            width: 100%; 
            border-collapse: collapse; 
            text-align: left; 
            font-size: 0.92rem; 
        }
        th { 
            background: var(--cream-bg); 
            color: var(--dark-text); 
            padding: 14px 20px; 
            font-weight: 700; 
            text-transform: uppercase; 
            font-size: 0.72rem; 
            letter-spacing: 0.5px; 
            border-bottom: 2px solid var(--border-light); 
        }
        td { 
            padding: 14px 20px; 
            border-bottom: 1px solid var(--border-light); 
            color: var(--dark-text); 
            vertical-align: middle; 
        }
        tr:hover td { 
            background: var(--softcare-light-blue); 
        }
        tr:last-child td { 
            border-bottom: none; 
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.72rem;
            font-weight: 700;
        }

        .badge-student {
            background: #FFFBEB;
            color: #B45309;
            border: 1px solid #FCD34D;
        }

        .badge-company {
            background: #DCFCE7;
            color: var(--aloe-green);
            border: 1px solid #BBF7D0;
        }

        .badge-active {
            background: #DCFCE7;
            color: var(--aloe-green);
            border: 1px solid #BBF7D0;
        }

        .badge-blocked {
            background: #FEF2F2;
            color: var(--alert-red);
            border: 1px solid #FEE2E2;
        }

        .badge-admin {
            background: #E6F4FC;
            color: var(--softcare-blue);
            border: 1px solid #BAE0F7;
        }

        .btn-action { 
            padding: 6px 14px; 
            border-radius: 6px; 
            font-weight: 700; 
            font-size: 0.75rem; 
            cursor: pointer; 
            text-decoration: none; 
            display: inline-flex; 
            align-items: center; 
            gap: 5px; 
            border: none; 
            transition: 0.2s; 
        }
        .btn-block { 
            background: #FEF2F2; 
            color: var(--alert-red); 
        }
        .btn-block:hover { 
            background: #FEE2E2; 
        }
        .btn-unblock { 
            background: #DCFCE7; 
            color: var(--aloe-green); 
        }
        .btn-unblock:hover { 
            background: #BBF7D0; 
        }

        .action-buttons {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }

        .success-message {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 14px 20px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted-text);
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--border-light);
            margin-bottom: 15px;
            display: block;
        }

        .empty-state h4 {
            margin: 0 0 8px 0;
            color: var(--dark-text);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .admin-sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .admin-container { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .admin-top-header { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .admin-name { font-size: 0.75rem; max-width: 80px; }
            .admin-avatar-circle { width: 28px; height: 28px; }
            .admin-main { padding: 16px; }
            .admin-page-header { flex-direction: column; align-items: flex-start; }
            .admin-page-header h2 { font-size: 1.1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr 1fr; gap: 12px; }
            .metric-card-box { padding: 14px 16px; }
            .metric-card-box .metric-info .metric-val { font-size: 1.2rem; }
            .metric-card-box .metric-icon { width: 34px; height: 34px; font-size: 0.9rem; }
            .filter-nav { gap: 5px; }
            .filter-btn { padding: 6px 12px; font-size: 0.75rem; }
            .action-buttons { flex-direction: column; align-items: flex-start; gap: 4px; }
            th, td { padding: 10px 12px; font-size: 0.8rem; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
        }

        @media (max-width: 576px) {
            .admin-sidebar { width: 60px; }
            .admin-container { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .admin-top-header { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .admin-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .admin-avatar-circle { width: 26px; height: 26px; }
            .admin-main { padding: 12px; }
            .admin-page-header h2 { font-size: 1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr; gap: 10px; }
            .metric-card-box { padding: 12px 14px; }
            .metric-card-box .metric-info .metric-val { font-size: 1.1rem; }
            .metric-card-box .metric-icon { width: 30px; height: 30px; font-size: 0.8rem; }
            .filter-btn { padding: 4px 10px; font-size: 0.7rem; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<aside class="admin-sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <div class="sidebar-menu-container">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Overview</span></a></li>
            <li><a href="verify_orgs.php"><i class="fa-solid fa-user-shield"></i> <span>Verify Organizations</span></a></li>
            <li><a href="reset_requests.php"><i class="fa-solid fa-key"></i> <span>Password Resets</span></a></li>
            <li><a href="view_users.php" class="active"><i class="fa-solid fa-users-gear"></i> <span>View Users Hub</span></a></li>
            <li><a href="system_settings.php"><i class="fa-solid fa-sliders"></i> <span>System Settings</span></a></li>
            <li><a href="audit_logs.php"><i class="fa-solid fa-clock-rotate-left"></i> <span>Audit Metric Logs</span></a></li>
        </ul>
    </div>
</aside>

<div class="admin-container">
    <header class="admin-top-header">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-users-gear"></i> View Users Hub
            </div>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $admin_avatar; ?>" alt="Admin Avatar" class="admin-avatar-circle">
                <span class="admin-name"><?php echo $display_title; ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo $display_title; ?></h5>
                    <p>System Administrator</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="admin-main">
        <?php if (isset($_SESSION['user_success'])): ?>
            <div class="success-message">
                <i class="fa-solid fa-circle-check"></i> <?php echo $_SESSION['user_success']; unset($_SESSION['user_success']); ?>
            </div>
        <?php endif; ?>

        <div class="admin-page-header">
            <h2><i class="fa-solid fa-users-gear"></i> Registered System Users</h2>
        </div>

        <!-- Status Summary Cards -->
        <div class="summary-dashboard-cards">
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Total Users</h5>
                    <div class="metric-val"><?php echo $total_users; ?></div>
                </div>
                <div class="metric-icon total">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Students</h5>
                    <div class="metric-val"><?php echo $student_count; ?></div>
                </div>
                <div class="metric-icon student">
                    <i class="fa-solid fa-user-graduate"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Companies</h5>
                    <div class="metric-val"><?php echo $company_count; ?></div>
                </div>
                <div class="metric-icon company">
                    <i class="fa-solid fa-building"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Blocked Users</h5>
                    <div class="metric-val"><?php echo $blocked_count; ?></div>
                </div>
                <div class="metric-icon blocked">
                    <i class="fa-solid fa-ban"></i>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="filter-nav">
            <a href="view_users.php?role=all&status=all" class="filter-btn <?php echo ($role_filter === 'all' && $status_filter === 'all' ? 'active' : ''); ?>">All Users</a>
            <a href="view_users.php?role=student&status=all" class="filter-btn <?php echo ($role_filter === 'student' && $status_filter === 'all' ? 'active' : ''); ?>">Students</a>
            <a href="view_users.php?role=company&status=all" class="filter-btn <?php echo ($role_filter === 'company' && $status_filter === 'all' ? 'active' : ''); ?>">Companies</a>
            <a href="view_users.php?role=all&status=active" class="filter-btn <?php echo ($role_filter === 'all' && $status_filter === 'active' ? 'active' : ''); ?>">Active Users</a>
            <a href="view_users.php?role=all&status=blocked" class="filter-btn <?php echo ($role_filter === 'all' && $status_filter === 'blocked' ? 'active' : ''); ?>">Blocked Users</a>
        </div>

        <div class="data-table-card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Details</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($users)): ?>
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <i class="fa-regular fa-users"></i>
                                        <h4>No Users Found</h4>
                                        <p>No users match the selected filters.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            $counter = 1;
                            foreach($users as $user): 
                                $is_blocked = ($user['is_blocked'] ?? 0) == 1;
                                $role_class = $user['role'] === 'student' ? 'badge-student' : 'badge-company';
                                $role_icon = $user['role'] === 'student' ? 'fa-user-graduate' : 'fa-building';
                                
                                // Get display name - for students use full_name, for companies use org_name
                                if ($user['role'] === 'student') {
                                    $display_name = !empty($user['full_name']) ? $user['full_name'] : $user['email'];
                                } elseif ($user['role'] === 'company') {
                                    $display_name = !empty($user['company_name']) && $user['company_name'] !== 'N/A' ? $user['company_name'] : $user['email'];
                                } else {
                                    $display_name = $user['email'];
                                }
                                
                                $detail_info = $user['role'] === 'student' ? $user['placement_type'] : $user['company_name'];
                            ?>
                                <tr>
                                    <td><strong><?php echo $counter++; ?></strong></td>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:10px;">
                                            <div style="width:32px; height:32px; border-radius:50%; background:var(--softcare-light-blue); display:flex; align-items:center; justify-content:center; color:var(--softcare-blue);">
                                                <i class="fa-solid <?php echo $role_icon; ?>"></i>
                                            </div>
                                            <strong><?php echo htmlspecialchars($display_name); ?></strong>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <span class="badge <?php echo $role_class; ?>">
                                            <i class="fa-solid <?php echo $role_icon; ?>"></i>
                                            <?php echo ucfirst(htmlspecialchars($user['role'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if($is_blocked): ?>
                                            <span class="badge badge-blocked">
                                                <i class="fa-solid fa-ban"></i> Blocked
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-active">
                                                <i class="fa-regular fa-circle-check"></i> Active
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small style="color:var(--muted-text);">
                                            <?php if($user['role'] === 'student'): ?>
                                                <i class="fa-regular fa-graduation-cap"></i> <?php echo htmlspecialchars($user['placement_type'] ?? 'N/A'); ?>
                                            <?php else: ?>
                                                <i class="fa-regular fa-building"></i> <?php echo htmlspecialchars($user['company_name'] ?? 'N/A'); ?>
                                            <?php endif; ?>
                                            <br>
                                            <i class="fa-regular fa-clock"></i> <?php echo date('M d, Y', strtotime($user['created_at'])); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <?php if($is_blocked): ?>
                                                <a href="view_users.php?unblock_id=<?php echo $user['user_id']; ?>" class="btn-action btn-unblock" onclick="return confirm('Unblock this user?')">
                                                    <i class="fa-regular fa-circle-check"></i> Unblock
                                                </a>
                                            <?php else: ?>
                                                <a href="view_users.php?block_id=<?php echo $user['user_id']; ?>" class="btn-action btn-block" onclick="return confirm('Block this user? They will not be able to access the system.')">
                                                    <i class="fa-solid fa-ban"></i> Block
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});
</script>
</body>
</html>