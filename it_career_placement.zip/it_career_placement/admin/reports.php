<?php
session_start();
include('../includes/db_connect.php');

// Strict Admin Authorization Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];

// 1. COLLECT HIGH-LEVEL METRIC MATRICES
// Total Students partitioned by designated Track Pathway Configurations
$stmt_students = $pdo->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN placement_type = 'Internship' THEN 1 ELSE 0 END) as internship_count,
        SUM(CASE WHEN placement_type = 'Field Study' THEN 1 ELSE 0 END) as field_study_count
    FROM student_profiles
");
$stmt_students->execute();
$student_stats = $stmt_students->fetch(PDO::FETCH_ASSOC);

$total_students = $student_stats['total'] ?? 0;
$internship_students = $student_stats['internship_count'] ?? 0;
$field_study_students = $student_stats['field_study_count'] ?? 0;

// Corporate Entity Vetting Statistics
$stmt_orgs = $pdo->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN verification_status = 'Approved' THEN 1 ELSE 0 END) as verified_count,
        SUM(CASE WHEN verification_status = 'Pending' THEN 1 ELSE 0 END) as pending_count
    FROM organizations
");
$stmt_orgs->execute();
$org_stats = $stmt_orgs->fetch(PDO::FETCH_ASSOC);

$total_companies = $org_stats['total'] ?? 0;
$verified_companies = $org_stats['verified_count'] ?? 0;

// Opportunities & Slot Accumulation Ratios
$stmt_opps = $pdo->prepare("SELECT COUNT(*) as total_roles, SUM(slots_available) as total_slots FROM company_opportunities");
$stmt_opps->execute();
$opp_stats = $stmt_opps->fetch(PDO::FETCH_ASSOC);

$total_positions = $opp_stats['total_roles'] ?? 0;
$open_slots = $opp_stats['total_slots'] ?? 0;

// Math Percentages safely avoiding division-by-zero vectors
$internship_pct = $total_students > 0 ? round(($internship_students / $total_students) * 100) : 0;
$field_study_pct = $total_students > 0 ? round(($field_study_students / $total_students) * 100) : 0;
$verified_company_pct = $total_companies > 0 ? round(($verified_companies / $total_companies) * 100) : 0;

// 2. FETCH LATEST SYSTEM PLACEMENT ENGAGEMENTS (RECENT APPLICATIONS ACTIVITY)
$stmt_recent_apps = $pdo->prepare("
    SELECT a.applied_at, a.status, u.full_name, co.title as job_title, co.company_name
    FROM applications a
    INNER JOIN users u ON a.student_id = u.user_id
    INNER JOIN company_opportunities co ON a.opportunity_id = co.opp_id
    ORDER BY a.applied_at DESC LIMIT 5
");
$stmt_recent_apps->execute();
$recent_activities = $stmt_recent_apps->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Statistical Analytics | Admin Control</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* BALANCED BRAND COLOR MATRIX PALETTE:
           Chocolate Brown: #5C4033 | Mustard: #E1AD01 | Sky Blue: #87CEEB | Milk Black: #1A1A1B 
        */
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #fdfbf7; display: flex; }
        
        /* SYNCHRONIZED NAVIGATION BAR PANEL */
        .sidebar { width: 280px; background: #1A1A1B; color: #ffffff; min-height: 100vh; position: fixed; box-shadow: 4px 0 15px rgba(0,0,0,0.1); z-index: 100; }
        .sidebar-header { padding: 40px 20px; background: #5C4033; color: #E1AD01; text-align: center; font-weight: 900; letter-spacing: 1px; font-size: 1.2rem; border-bottom: 3px solid #E1AD01; }
        
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; }
        .sidebar-menu li { margin-bottom: 2px; }
        .sidebar-menu li a { display: flex; align-items: center; padding: 15px 30px; color: #87CEEB; text-decoration: none; transition: 0.3s ease; font-weight: bold; font-size: 0.95rem; }
        .sidebar-menu li a i { margin-right: 18px; width: 24px; font-size: 1.15rem; text-align: center; }
        .sidebar-menu li a:hover { background: rgba(225, 173, 1, 0.1); color: #E1AD01; }
        .sidebar-menu li a.active-page { color: #E1AD01; background: rgba(92, 64, 51, 0.2); border-left: 4px solid #E1AD01; padding-left: 26px; }

        /* ANALYTICS WORKSPACE GRIDS */
        .main-content { flex: 1; margin-left: 280px; padding: 40px; box-sizing: border-box; }
        .container { background: #fff; padding: 35px; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.03); border-top: 6px solid #5C4033; margin-bottom: 35px; }
        
        h2 { margin-top: 0; font-weight: 800; color: #1A1A1B; display: flex; align-items: center; gap: 12px; }
        .section-desc { color: #666; margin-bottom: 30px; font-weight: 600; }
        
        /* SCOREBOARD METRIC CHIPS GRID */
        .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 35px; }
        .metric-card { background: #fff; border: 2px solid #f5f2eb; padding: 24px; border-radius: 14px; position: relative; transition: 0.3s; overflow: hidden; }
        .metric-card:hover { transform: translateY(-3px); border-color: #87CEEB; box-shadow: 0 8px 20px rgba(135,206,235,0.1); }
        .metric-card h3 { margin: 0; color: #666; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 700; }
        .metric-card .value { font-size: 2.2rem; font-weight: 900; color: #1A1A1B; margin: 8px 0 4px 0; }
        .metric-card i { position: absolute; right: 20px; bottom: 20px; font-size: 2.5rem; color: #f5f2eb; z-index: 1; }
        .metric-card .sub-info { font-size: 0.8rem; font-weight: 600; color: #5C4033; display: flex; align-items: center; gap: 4px; }

        /* ANALYTICAL VISUALIZATION SEGMENT */
        .charts-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 25px; margin-bottom: 35px; }
        .chart-box { background: #fff; border: 2px solid #f5f2eb; border-radius: 14px; padding: 25px; }
        .chart-box h4 { margin-top: 0; margin-bottom: 20px; color: #1A1A1B; font-weight: 800; display: flex; align-items: center; gap: 8px; border-bottom: 2px solid #faf9f5; padding-bottom: 12px; }
        
        /* DATA PROGRESS RING BARS COMPONENT */
        .progress-bar-group { margin-bottom: 18px; }
        .progress-bar-label { display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 700; color: #333; margin-bottom: 6px; }
        .progress-track { background: #f5f2eb; height: 12px; border-radius: 10px; overflow: hidden; display: flex; }
        .progress-fill { height: 100%; border-radius: 10px; transition: width 1s ease-in-out; }
        .fill-mustard { background: #E1AD01; }
        .fill-sky { background: #87CEEB; }
        .fill-brown { background: #5C4033; }

        /* REPORT TIMELINE TRANSACTIONS */
        .activity-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 15px; border-bottom: 1px solid #f5f2eb; font-size: 0.9rem; }
        .activity-item:last-child { border-bottom: none; }
        .activity-details { font-weight: 600; color: #333; }
        .activity-time { font-size: 0.75rem; color: #888; font-weight: bold; }
        
        .badge-status { font-size: 0.7rem; padding: 3px 8px; border-radius: 10px; font-weight: 800; text-transform: uppercase; }
        .status-Pending { background: #fff7e6; color: #d46b08; }
        .status-Approved { background: #eef9f0; color: #2b7a43; }
        
        /* EXPORT TRIGGER HOVER PANEL */
        .print-btn-panel { display: flex; gap: 15px; margin-bottom: 30px; }
        .btn-export { background: #1A1A1B; color: #E1AD01; font-weight: 800; text-transform: uppercase; font-size: 0.85rem; padding: 12px 24px; border-radius: 8px; border: none; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: 0.2s; }
        .btn-export:hover { background: #5C4033; color: #fff; }

        @media print {
            .sidebar, .print-btn-panel { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
            .container { box-shadow: none !important; border: none !important; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">ADMIN PANEL</div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Control Overview</a></li>
        <li><a href="request.php"><i class="fa-solid fa-building-circle-check"></i> Verify Organizations</a></li>
        <li><a href="manage_students.php"><i class="fa-solid fa-graduation-cap"></i> Manage Student Tracks</a></li>
        <li><a href="opportunities.php"><i class="fa-solid fa-briefcase"></i> Postings Directory</a></li>
        <li><a href="logs.php"><i class="fa-solid fa-clock-rotate-left"></i> System Audit Logs</a></li>
        <li><a href="reports.php" class="active-page"><i class="fa-solid fa-chart-column"></i> System Reports</a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> Global Settings</a></li>
        <li><a href="../logout.php"><i class="fa-solid fa-power-off"></i> Logout Matrix</a></li>
    </ul>
</div>

<div class="main-content">
    
    <div class="print-btn-panel">
        <button class="btn-export" onclick="window.print()"><i class="fa-solid fa-print"></i> Print Audit Summary Report</button>
    </div>

    <div class="container">
        <h2><i class="fa-solid fa-chart-line" style="color: #5C4033;"></i> System Placement Metrics & KPI Reports</h2>
        <p class="section-desc">Real-time analytical metrics snapshot tracking configuration pipelines, verified industrial affiliates, and active operations.</p>

        <div class="metrics-grid">
            <div class="metric-card">
                <h3>Total Managed Students</h3>
                <div class="value"><?php echo $total_students; ?></div>
                <div class="sub-info"><i class="fa-solid fa-user-graduate"></i> Enrolled Profiles</div>
            </div>
            <div class="metric-card">
                <h3>Affiliated Corporations</h3>
                <div class="value"><?php echo $total_companies; ?></div>
                <div class="sub-info"><i class="fa-solid fa-building"></i> Registered Entities</div>
            </div>
            <div class="metric-card">
                <h3>Published Opportunities</h3>
                <div class="value"><?php echo $total_positions; ?></div>
                <div class="sub-info"><i class="fa-solid fa-briefcase"></i> Vacancy Modules</div>
            </div>
            <div class="metric-card">
                <h3>Available Placements</h3>
                <div class="value"><?php echo $open_slots; ?></div>
                <div class="sub-info"><i class="fa-solid fa-door-open"></i> Remaining Open Slots</div>
            </div>
        </div>

        <div class="charts-row">
            
            <div class="chart-box">
                <h4><i class="fa-solid fa-code-branch" style="color: #87CEEB;"></i> Student Tracking Allocations</h4>
                
                <div class="progress-bar-group">
                    <div class="progress-bar-label">
                        <span>Internship Track System</span>
                        <span><?php echo $internship_students; ?> Students (<?php echo $internship_pct; ?>%)</span>
                    </div>
                    <div class="progress-track">
                        <div class="progress-fill fill-mustard" style="width: <?php echo $internship_pct; ?>%"></div>
                    </div>
                </div>

                <div class="progress-bar-group">
                    <div class="progress-bar-label">
                        <span>Field Study Route System</span>
                        <span><?php echo $field_study_students; ?> Students (<?php echo $field_study_pct; ?>%)</span>
                    </div>
                    <div class="progress-track">
                        <div class="progress-fill fill-sky" style="width: <?php echo $field_study_pct; ?>%"></div>
                    </div>
                </div>
            </div>

            <div class="chart-box">
                <h4><i class="fa-solid fa-shield-check" style="color: #E1AD01;"></i> Enterprise Compliance Levels</h4>
                
                <div class="progress-bar-group">
                    <div class="progress-bar-label">
                        <span>Verified Corporate Affiliates</span>
                        <span><?php echo $verified_companies; ?> Approved (<?php echo $verified_company_pct; ?>%)</span>
                    </div>
                    <div class="progress-track">
                        <div class="progress-fill fill-brown" style="width: <?php echo $verified_company_pct; ?>%"></div>
                    </div>
                </div>
                <p style="font-size: 0.8rem; color:#777; margin: 0; line-height: 1.4; font-weight: 600;">
                    <i class="fa-solid fa-circle-info"></i> Unverified companies are barred from filling student placement slots until authorized via verification queues.
                </p>
            </div>
        </div>

        <div class="chart-box" style="margin-top: 15px;">
            <h4 style="margin-bottom: 15px;"><i class="fa-solid fa-bolt" style="color:#5C4033;"></i> Latest System Pipeline Interactions</h4>
            <div style="background: #faf9f5; border-radius: 10px; border: 1px solid #f5f2eb; overflow: hidden;">
                <?php foreach ($recent_activities as $activity): ?>
                    <div class="activity-item">
                        <div>
                            <span class="activity-details"><?php echo htmlspecialchars($activity['full_name']); ?></span> 
                            <span style="color:#666;">applied for</span> 
                            <strong><?php echo htmlspecialchars($activity['job_title']); ?></strong> 
                            <span style="color:#666;">at <?php echo htmlspecialchars($activity['company_name']); ?></span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <span class="badge-status status-<?php echo $activity['status']; ?>"><?php echo $activity['status']; ?></span>
                            <span class="activity-time"><?php echo date('M d, H:i', strtotime($activity['applied_at'])); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if (empty($recent_activities)): ?>
                    <div style="padding: 25px; text-align: center; color: #999;">
                        No pipeline deployment or application activities logged in system tables yet.
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

</body>
</html>