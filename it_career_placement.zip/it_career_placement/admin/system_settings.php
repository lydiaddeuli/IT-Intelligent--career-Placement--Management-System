<?php
session_start();
include('../includes/db_connect.php');

// Security Check: Only Admin Access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];
$display_title = "System Admin";
$admin_avatar = "https://ui-avatars.com/api/?name=Admin&background=0091DF&color=fff&size=40";

$success_msg = "";
$error_msg = "";

// Fetch Admin profile
try {
    $stmt = $pdo->prepare("SELECT username, email, profile_pic, full_name FROM users WHERE user_id = ?");
    $stmt->execute([$admin_id]);
    $admin = $stmt->fetch();
    if ($admin) {
        $display_title = htmlspecialchars($admin['full_name'] ?? $admin['username'] ?? explode('@', $admin['email'])[0]);
        if (!empty($admin['profile_pic'])) { 
            $admin_avatar = "../" . $admin['profile_pic']; 
        } else {
            $admin_avatar = "https://ui-avatars.com/api/?name=" . urlencode($display_title) . "&background=0091DF&color=fff&size=40";
        }
    }
} catch (PDOException $e) {}

// Fetch current system settings
$settings = [];
try {
    $settings_query = $pdo->query("SELECT * FROM system_settings")->fetchAll(PDO::FETCH_KEY_PAIR);
    $settings = $settings_query;
} catch (PDOException $e) {
    // Table might not exist yet - create it
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
            setting_key VARCHAR(50) PRIMARY KEY,
            setting_value VARCHAR(50) NOT NULL
        )");
    } catch (PDOException $ex) {}
}

// Set default values if not set
$allow_student_reg = isset($settings['allow_student_reg']) ? $settings['allow_student_reg'] : '1';
$allow_company_reg = isset($settings['allow_company_reg']) ? $settings['allow_company_reg'] : '1';
$enable_vacancy_board = isset($settings['enable_vacancy_board']) ? $settings['enable_vacancy_board'] : '1';

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Handle Email Update
    if (isset($_POST['update_email'])) {
        $new_email = trim($_POST['new_email']);
        $confirm_email = trim($_POST['confirm_email']);
        
        if (empty($new_email) || empty($confirm_email)) {
            $error_msg = "Please fill in both email fields.";
        } elseif ($new_email !== $confirm_email) {
            $error_msg = "Emails do not match.";
        } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            $error_msg = "Please enter a valid email address.";
        } else {
            try {
                $update = $pdo->prepare("UPDATE users SET email = ? WHERE user_id = ?");
                $update->execute([$new_email, $admin_id]);
                $success_msg = "Email updated successfully!";
            } catch (PDOException $e) {
                $error_msg = "Error updating email: " . $e->getMessage();
            }
        }
    }
    
    // Handle Password Change
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error_msg = "Please fill in all password fields.";
        } elseif ($new_password !== $confirm_password) {
            $error_msg = "New passwords do not match.";
        } elseif (strlen($new_password) < 6) {
            $error_msg = "Password must be at least 6 characters long.";
        } else {
            try {
                $stmt = $pdo->prepare("SELECT password FROM users WHERE user_id = ?");
                $stmt->execute([$admin_id]);
                $current_hash = $stmt->fetchColumn();
                
                if (password_verify($current_password, $current_hash)) {
                    $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
                    $update = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                    $update->execute([$new_hash, $admin_id]);
                    $success_msg = "Password changed successfully!";
                } else {
                    $error_msg = "Current password is incorrect.";
                }
            } catch (PDOException $e) {
                $error_msg = "Error changing password: " . $e->getMessage();
            }
        }
    }
    
    // Handle System Settings Update
    if (isset($_POST['update_settings'])) {
        // Checkbox values: 1 if checked, 0 if not (isset handles this)
        $student_reg = isset($_POST['allow_student_reg']) ? '1' : '0';
        $company_reg = isset($_POST['allow_company_reg']) ? '1' : '0';
        $vacancy_access = isset($_POST['enable_vacancy_board']) ? '1' : '0';
        
        try {
            // Make sure table exists
            $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
                setting_key VARCHAR(50) PRIMARY KEY,
                setting_value VARCHAR(50) NOT NULL
            )");
            
            // Update or insert settings
            $settings_data = [
                'allow_student_reg' => $student_reg,
                'allow_company_reg' => $company_reg,
                'enable_vacancy_board' => $vacancy_access
            ];
            
            foreach ($settings_data as $key => $value) {
                $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$key, $value, $value]);
            }
            
            // Update local variables
            $allow_student_reg = $student_reg;
            $allow_company_reg = $company_reg;
            $enable_vacancy_board = $vacancy_access;
            
            $success_msg = "System settings updated successfully!";
        } catch (PDOException $e) {
            $error_msg = "Error updating settings: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings | Control Tower</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F9F9FB;           
            --border-light: #E2E8F0;
            --alert-red: #EF4444;
            --aloe-green: #008543;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }

        /* --- SIDEBAR --- */
        .admin-sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu-container { 
            flex: 1; 
            overflow-y: auto; 
            padding: 15px 0; 
            background: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 0; 
            margin: 0; 
        }
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        /* --- MAIN CONTENT --- */
        .admin-container { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--cream-bg);
        }

        /* --- TOP HEADER --- */
        .admin-top-header { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .admin-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .admin-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        /* Profile Dropdown */
        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--cream-bg);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        /* --- PAGE CONTENT --- */
        .admin-main { 
            padding: 30px 35px; 
        }

        .admin-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .admin-page-header h2 { 
            margin: 0; 
            font-weight: 800; 
            font-size: 1.4rem; 
        }
        .admin-page-header h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }

        /* Settings Grid */
        .settings-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }

        .settings-card {
            background: var(--white);
            border-radius: 12px;
            border: 1px solid var(--border-light);
            padding: 24px 28px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
        }

        .settings-card.full-width {
            grid-column: span 2;
        }

        .settings-card h3 {
            margin-top: 0;
            margin-bottom: 18px;
            font-weight: 800;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 10px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border-light);
        }

        .settings-card h3 i {
            color: var(--softcare-blue);
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            font-weight: 700;
            font-size: 0.85rem;
            margin-bottom: 5px;
            color: var(--dark-text);
        }

        .form-group label i {
            margin-right: 6px;
            color: var(--softcare-blue);
        }

        .form-control {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid var(--border-light);
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 0.95rem;
            background: var(--cream-bg);
            transition: border-color 0.2s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--softcare-blue);
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }

        .password-wrapper {
            position: relative;
        }

        .password-wrapper input {
            padding-right: 45px;
        }

        .password-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--muted-text);
            cursor: pointer;
            font-size: 1rem;
        }

        .password-toggle:hover {
            color: var(--softcare-blue);
        }

        .checkbox-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 5px;
        }

        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            color: var(--dark-text);
            padding: 8px 12px;
            border-radius: 8px;
            background: var(--cream-bg);
            transition: background 0.2s;
        }

        .checkbox-group label:hover {
            background: var(--softcare-light-blue);
        }

        .checkbox-group label input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--softcare-blue);
            cursor: pointer;
            flex-shrink: 0;
        }

        .checkbox-group label .status-indicator {
            margin-left: auto;
            font-size: 0.75rem;
            font-weight: 700;
            padding: 2px 12px;
            border-radius: 20px;
        }

        .checkbox-group label .status-indicator.enabled {
            background: #DCFCE7;
            color: var(--aloe-green);
        }

        .checkbox-group label .status-indicator.disabled {
            background: #FEF2F2;
            color: var(--alert-red);
        }

        .btn-action {
            padding: 10px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: var(--softcare-blue);
            color: white;
        }

        .btn-primary:hover {
            background: #0077b6;
        }

        .btn-success {
            background: var(--aloe-green);
            color: white;
        }

        .btn-success:hover {
            background: #006B36;
        }

        .btn-full {
            width: 100%;
            justify-content: center;
        }

        .success-message {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 14px 20px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .error-message {
            background: #FEF2F2;
            color: var(--alert-red);
            padding: 14px 20px;
            border-radius: 8px;
            border: 1px solid #FEE2E2;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Profile Header inside card */
        .profile-header {
            display: flex;
            align-items: center;
            gap: 20px;
            padding-bottom: 15px;
            margin-bottom: 15px;
            border-bottom: 1px solid var(--border-light);
        }

        .profile-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--softcare-blue);
        }

        .profile-info h4 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 800;
        }

        .profile-info p {
            margin: 2px 0 0 0;
            color: var(--muted-text);
            font-size: 0.85rem;
        }

        .profile-info .role-badge {
            display: inline-block;
            padding: 2px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
            margin-top: 4px;
        }

        /* Mobile Responsive */
        @media (max-width: 992px) {
            .settings-grid {
                grid-template-columns: 1fr;
            }
            .settings-card.full-width {
                grid-column: span 1;
            }
        }

        @media (max-width: 768px) {
            .admin-sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .admin-container { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .admin-top-header { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .admin-name { font-size: 0.75rem; max-width: 80px; }
            .admin-avatar-circle { width: 28px; height: 28px; }
            .admin-main { padding: 16px; }
            .admin-page-header { flex-direction: column; align-items: flex-start; }
            .admin-page-header h2 { font-size: 1.1rem; }
            .settings-card { padding: 18px 16px; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
            .profile-header { flex-direction: column; text-align: center; }
        }

        @media (max-width: 576px) {
            .admin-sidebar { width: 60px; }
            .admin-container { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .admin-top-header { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .admin-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .admin-avatar-circle { width: 26px; height: 26px; }
            .admin-main { padding: 12px; }
            .admin-page-header h2 { font-size: 1rem; }
            .settings-card { padding: 14px 12px; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<aside class="admin-sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <div class="sidebar-menu-container">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Overview</span></a></li>
            <li><a href="verify_orgs.php"><i class="fa-solid fa-user-shield"></i> <span>Verify Organizations</span></a></li>
            <li><a href="reset_requests.php"><i class="fa-solid fa-key"></i> <span>Password Resets</span></a></li>
            <li><a href="view_users.php"><i class="fa-solid fa-users-gear"></i> <span>View Users Hub</span></a></li>
            <li><a href="system_settings.php" class="active"><i class="fa-solid fa-sliders"></i> <span>System Settings</span></a></li>
            <li><a href="audit_logs.php"><i class="fa-solid fa-clock-rotate-left"></i> <span>Audit Metric Logs</span></a></li>
        </ul>
    </div>
</aside>

<div class="admin-container">
    <header class="admin-top-header">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-sliders"></i> System Settings
            </div>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $admin_avatar; ?>" alt="Admin Avatar" class="admin-avatar-circle">
                <span class="admin-name"><?php echo $display_title; ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo $display_title; ?></h5>
                    <p>System Administrator</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="admin-main">
        <?php if($success_msg): ?>
            <div class="success-message">
                <i class="fa-solid fa-circle-check"></i> <?php echo $success_msg; ?>
            </div>
        <?php endif; ?>
        <?php if($error_msg): ?>
            <div class="error-message">
                <i class="fa-solid fa-circle-exclamation"></i> <?php echo $error_msg; ?>
            </div>
        <?php endif; ?>

        <div class="admin-page-header">
            <h2><i class="fa-solid fa-sliders"></i> System Settings Configuration</h2>
        </div>

        <div class="settings-grid">
            <!-- Admin Profile Card -->
            <div class="settings-card">
                <h3><i class="fa-solid fa-user-shield"></i> Admin Profile</h3>
                <div class="profile-header">
                    <img src="<?php echo $admin_avatar; ?>" alt="Admin Avatar" class="profile-avatar">
                    <div class="profile-info">
                        <h4><?php echo $display_title; ?></h4>
                        <p><?php echo htmlspecialchars($admin['email'] ?? ''); ?></p>
                        <span class="role-badge"><i class="fa-solid fa-shield-halved"></i> Administrator</span>
                    </div>
                </div>
            </div>

            <!-- Change Email Card -->
            <div class="settings-card">
                <h3><i class="fa-regular fa-envelope"></i> Change Email</h3>
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fa-regular fa-envelope"></i> New Email Address</label>
                        <input type="email" class="form-control" name="new_email" placeholder="Enter new email" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-regular fa-envelope"></i> Confirm Email</label>
                        <input type="email" class="form-control" name="confirm_email" placeholder="Confirm new email" required>
                    </div>
                    <button type="submit" name="update_email" class="btn-action btn-primary btn-full">
                        <i class="fa-regular fa-floppy-disk"></i> Update Email
                    </button>
                </form>
            </div>

            <!-- Change Password Card -->
            <div class="settings-card">
                <h3><i class="fa-solid fa-key"></i> Change Password</h3>
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fa-solid fa-lock"></i> Current Password</label>
                        <div class="password-wrapper">
                            <input type="password" class="form-control" name="current_password" id="current_password" placeholder="Enter current password" required>
                            <i class="fa-regular fa-eye password-toggle" onclick="togglePassword('current_password', this)"></i>
                        </div>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-solid fa-key"></i> New Password</label>
                        <div class="password-wrapper">
                            <input type="password" class="form-control" name="new_password" id="new_password" placeholder="Enter new password (min 6 chars)" required>
                            <i class="fa-regular fa-eye password-toggle" onclick="togglePassword('new_password', this)"></i>
                        </div>
                    </div>
                    <div class="form-group">
                        <label><i class="fa-solid fa-key"></i> Confirm New Password</label>
                        <div class="password-wrapper">
                            <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm new password" required>
                            <i class="fa-regular fa-eye password-toggle" onclick="togglePassword('confirm_password', this)"></i>
                        </div>
                    </div>
                    <button type="submit" name="change_password" class="btn-action btn-success btn-full">
                        <i class="fa-solid fa-rotate"></i> Change Password
                    </button>
                </form>
            </div>

            <!-- System Settings Card -->
            <div class="settings-card full-width">
                <h3><i class="fa-solid fa-gears"></i> System Settings</h3>
                <p style="color:var(--muted-text); margin-bottom:15px; font-size:0.9rem;">
                    Toggle the switches below to enable or disable system features.
                </p>
                <form method="POST">
                    <div class="checkbox-group">
                        <label>
                            <input type="checkbox" name="allow_student_reg" <?php echo ($allow_student_reg == '1') ? 'checked' : ''; ?>>
                            <span><i class="fa-solid fa-user-graduate"></i> Enable Student Registration</span>
                            <span class="status-indicator <?php echo ($allow_student_reg == '1') ? 'enabled' : 'disabled'; ?>">
                                <?php echo ($allow_student_reg == '1') ? 'Enabled' : 'Disabled'; ?>
                            </span>
                        </label>
                        <label>
                            <input type="checkbox" name="allow_company_reg" <?php echo ($allow_company_reg == '1') ? 'checked' : ''; ?>>
                            <span><i class="fa-solid fa-building"></i> Enable Company Registration</span>
                            <span class="status-indicator <?php echo ($allow_company_reg == '1') ? 'enabled' : 'disabled'; ?>">
                                <?php echo ($allow_company_reg == '1') ? 'Enabled' : 'Disabled'; ?>
                            </span>
                        </label>
                        <label>
                            <input type="checkbox" name="enable_vacancy_board" <?php echo ($enable_vacancy_board == '1') ? 'checked' : ''; ?>>
                            <span><i class="fa-solid fa-briefcase"></i> Enable Vacancy Board Access</span>
                            <span class="status-indicator <?php echo ($enable_vacancy_board == '1') ? 'enabled' : 'disabled'; ?>">
                                <?php echo ($enable_vacancy_board == '1') ? 'Enabled' : 'Disabled'; ?>
                            </span>
                        </label>
                    </div>
                    <br>
                    <button type="submit" name="update_settings" class="btn-action btn-primary btn-full">
                        <i class="fa-regular fa-floppy-disk"></i> Save System Settings
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});

function togglePassword(fieldId, iconElement) {
    const field = document.getElementById(fieldId);
    if (field.type === "password") {
        field.type = "text";
        iconElement.classList.remove('fa-eye');
        iconElement.classList.add('fa-eye-slash');
    } else {
        field.type = "password";
        iconElement.classList.remove('fa-eye-slash');
        iconElement.classList.add('fa-eye');
    }
}
</script>
</body>
</html>