<?php
session_start();
include('includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];
$display_title = "System Admin";
$admin_avatar = "https://ui-avatars.com/api/?name=Admin&background=FFF&color=0091DF";

// Safe dynamic name and avatar string locator context
try {
    $admin_stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $admin_stmt->execute([$admin_id]);
    $admin_profile = $admin_stmt->fetch();
    if ($admin_profile) {
        if (isset($admin_profile['username'])) { $display_title = htmlspecialchars($admin_profile['username']); }
        elseif (isset($admin_profile['email'])) { $display_title = htmlspecialchars(explode('@', $admin_profile['email'])[0]); }
        
        if (!empty($admin_profile['profile_pic'])) { 
            $admin_avatar = "../" . $admin_profile['profile_pic']; 
        } else {
            $admin_avatar = "https://ui-avatars.com/api/?name=" . urlencode($display_title) . "&background=FFF&color=0091DF";
        }
    }
} catch (PDOException $e) {}

$all_orgs = $pdo->query("SELECT * FROM organizations ORDER BY org_id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Corporate Fees | Admin Workspace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --mustard-yellow: #F59E0B;     
            --dark-text: #111111;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           
            --border-light: #E2E8F0;
        }

        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--cream-bg); display: flex; min-height: 100vh; color: var(--dark-text); }

        /* --- SIDEBAR SHARING CONFIGURATION --- */
        .admin-sidebar { width: 280px; background: var(--white); color: var(--dark-text); display: flex; flex-direction: column; border-right: 1px solid var(--border-light); position: fixed; height: 100vh; z-index: 100; }
        .sidebar-brand { padding: 24px 20px; display: flex; align-items: center; gap: 12px; font-size: 1.15rem; font-weight: 800; border-bottom: 1px solid var(--border-light); }
        .sidebar-brand img { height: 45px; width: auto; object-fit: contain; border-radius: 6px; }
        
        .sidebar-menu-container { flex: 1; overflow-y: auto; padding: 15px 0; }
        .menu-label { padding: 10px 25px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: var(--muted-text); letter-spacing: 0.5px; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0 0 20px 0; }
        .sidebar-menu li a { display: flex; align-items: center; gap: 15px; color: #555555; text-decoration: none; padding: 12px 25px; font-weight: 700; font-size: 0.92rem; transition: 0.2s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { color: var(--dark-text); background: var(--cream-bg); border-left: 4px solid var(--softcare-blue); }

        .admin-container { margin-left: 280px; flex: 1; display: flex; flex-direction: column; }
        
        /* --- STANDARDIZED BLUE COMPLIANCE HEADER HUB --- */
        .admin-top-header { background: var(--softcare-blue); padding: 0 40px; display: flex; justify-content: space-between; align-items: center; height: 80px; box-sizing: border-box; position: relative; color: white; }
        
        .profile-trigger-zone { display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 6px 12px; border-radius: 50px; transition: 0.2s; user-select: none; }
        .profile-trigger-zone:hover { background: rgba(255, 255, 255, 0.15); }
        .admin-avatar-circle { width: 42px; height: 42px; border-radius: 50%; object-fit: cover; border: 2px solid white; }
        .profile-trigger-zone span { font-weight: 700; font-size: 0.9rem; }

        /* --- ACCORDION AVATAR DROPDOWN COMPONENT --- */
        .header-dropdown-card { display: none; position: absolute; top: 75px; right: 40px; background: var(--white); border: 1px solid var(--border-light); border-radius: 12px; width: 250px; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08); z-index: 1000; overflow: hidden; color: var(--dark-text); }
        .dropdown-user-info { padding: 18px; background: var(--cream-bg); border-bottom: 1px solid var(--border-light); text-align: center; }
        .dropdown-user-info h5 { margin: 0; font-size: 0.95rem; font-weight: 800; }
        .dropdown-user-info p { margin: 3px 0 0 0; font-size: 0.78rem; color: var(--muted-text); text-transform: uppercase; font-weight: 700; }
        .dropdown-menu-list { list-style: none; padding: 0; margin: 0; }
        .dropdown-menu-list li a, .dropdown-menu-list li button { width: 100%; box-sizing: border-box; display: flex; align-items: center; gap: 12px; padding: 14px 20px; color: var(--dark-text); text-decoration: none; font-size: 0.9rem; font-weight: 700; background: none; border: none; text-align: left; cursor: pointer; transition: 0.2s; }
        .dropdown-menu-list li a:hover, .dropdown-menu-list li button:hover { background: var(--softcare-light-blue); color: var(--softcare-blue); }
        .dropdown-menu-list li .logout-item { color: #EF4444; border-top: 1px solid var(--border-light); }
        .dropdown-menu-list li .logout-item:hover { background: #FEE2E2; color: #991B1B; }

        .admin-main { padding: 40px; }
        .admin-page-header h2 { margin: 0 0 30px 0; font-weight: 800; font-size: 1.75rem; letter-spacing: -0.5px; }

        .data-table-card { background: var(--white); border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.02); border-top: 4px solid var(--softcare-blue); overflow: hidden; }
        .table-responsive { width: 100%; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.95rem; }
        th { background: #F8FAFC; color: var(--dark-text); padding: 16px 20px; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 0.5px; border-bottom: 2px solid var(--border-light); }
        td { padding: 16px 20px; border-bottom: 1px solid var(--border-light); color: var(--dark-text); vertical-align: middle; }
        tr:hover td { background: #F8FAFC; }

        .badge { padding: 6px 12px; border-radius: 50px; font-size: 0.8rem; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; }
        .badge-pending { background: #FEF3C7; color: #B45309; }
        .badge-approved { background: #D1FAE5; color: #065F46; }
    </style>
</head>
<body>

<div class="admin-sidebar">
    <div class="sidebar-brand">
        <img src="../images/logo.jpeg" alt="Logo" onerror="this.style.display='none';">
        <span>CareerConnect Hub</span>
    </div>
    <div class="sidebar-menu-container">
        <div class="menu-label">Core Operations</div>
        <ul class="sidebar-menu">
        <li><a href="dashboard.php" class="active"><i class="fa-solid fa-chart-pie"></i> Dashboard Overview</a></li>
            <li><a href="verify_orgs.php"><i class="fa-solid fa-user-shield"></i> Verify Organizations</a></li>
            <li><a href="manage_organizations.php"><i class="fa-solid fa-building"></i> Manage Corporate Fees</a></li>
            <li><a href="reset_requests.php"><i class="fa-solid fa-key"></i> Password Resets</a></li>
            <li><a href="view_users.php"><i class="fa-solid fa-users-gear"></i> View Users Hub</a></li>
            <li><a href="student_records.php"><i class="fa-solid fa-graduation-cap"></i> Student Profiles</a></li>
            <li><a href="system_settings.php"><i class="fa-solid fa-sliders"></i> System Settings</a></li>
            <li><a href="audit_logs.php"><i class="fa-solid fa-clock-rotate-left"></i> Audit Metric Logs</a></li>
        </ul>
    </div>
</div>

<div class="admin-container">
    <div class="admin-top-header">
        <div style="font-weight: 600; opacity: 0.95;"><i class="fa-solid fa-wallet"></i> Financial Matrix Hub</div>
        <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
            <img src="<?php echo $admin_avatar; ?>" alt="Admin Avatar" class="admin-avatar-circle">
            <span><?php echo $display_title; ?></span>
            <i class="fa-solid fa-angle-down" style="font-size: 0.8rem;"></i>
        </div>
        <div class="header-dropdown-card" id="profileDropdown">
            <div class="dropdown-user-info">
                <h5><?php echo $display_title; ?></h5>
                <p>Root Manager</p>
            </div>
            <ul class="dropdown-menu-list">
                <li><a href="dashboard.php?action=settings"><i class="fa-solid fa-camera"></i> Profile Settings</a></li>
                <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
            </ul>
        </div>
    </div>

    <div class="admin-main">
        <div class="admin-page-header">
            <h2>Manage Corporate Fees</h2>
        </div>

        <div class="data-table-card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Organization Title</th>
                            <th>Fee Framework Profile</th>
                            <th>Registration Cost</th>
                            <th>Direct Field Cost</th>
                            <th>Justification Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($all_orgs as $org): 
                            $fees = json_decode($org['fee_amounts_json'] ?? '{"registration_fee":0,"direct_field_cost":0}', true);
                            $reg = floatval($fees['registration_fee'] ?? 0);
                            $dir = floatval($fees['direct_field_cost'] ?? 0);
                        ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($org['org_name']); ?></strong><br>
                                    <small style="color:var(--muted-text);"><?php echo htmlspecialchars($org['contact_email']); ?></small>
                                </td>
                                <td>
                                    <?php if($org['has_fees'] == 'None' || $org['has_fees'] == ''): ?>
                                        <span class="badge badge-approved"><i class="fa-solid fa-heart"></i> 100% Free Field Study</span>
                                    <?php else: ?>
                                        <span class="badge badge-pending"><i class="fa-solid fa-hand-holding-dollar"></i> <?php echo htmlspecialchars($org['has_fees']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?php echo number_format($reg, 2); ?> TZS</strong></td>
                                <td><strong><?php echo number_format($dir, 2); ?> TZS</strong></td>
                                <td>
                                    <?php if(!empty($org['fee_reason'])): ?>
                                        <div style="max-width:250px; font-size:0.85rem; color:var(--muted-text); line-height:1.3;">
                                            <?php echo htmlspecialchars($org['fee_reason']); ?>
                                        </div>
                                    <?php else: ?>
                                        <em style="color:#CBD5E1;">None (Free Matrix)</em>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}
document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});
</script>
</body>
</html>