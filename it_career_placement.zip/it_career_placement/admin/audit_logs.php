<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];
$display_title = "System Admin";
$admin_avatar = "https://ui-avatars.com/api/?name=Admin&background=0091DF&color=fff&size=40";

try {
    $admin_stmt = $pdo->prepare("SELECT username, email, profile_pic, full_name FROM users WHERE user_id = ?");
    $admin_stmt->execute([$admin_id]);
    $admin = $admin_stmt->fetch();
    if ($admin) {
        $display_title = htmlspecialchars($admin['full_name'] ?? $admin['username'] ?? explode('@', $admin['email'])[0]);
        if (!empty($admin['profile_pic'])) { 
            $admin_avatar = "../" . $admin['profile_pic']; 
        } else {
            $admin_avatar = "https://ui-avatars.com/api/?name=" . urlencode($display_title) . "&background=0091DF&color=fff&size=40";
        }
    }
} catch (PDOException $e) {}

// Check if audit_logs table exists, create if not
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'audit_logs'");
    if ($check_table->rowCount() == 0) {
        $pdo->exec("CREATE TABLE audit_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NULL,
            action VARCHAR(100) NOT NULL,
            details TEXT NULL,
            ip_address VARCHAR(45) NULL,
            user_agent VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
    }
} catch (PDOException $e) {}

// Get filter parameters
$action_filter = isset($_GET['action']) ? $_GET['action'] : 'all';
$role_filter = isset($_GET['role']) ? $_GET['role'] : 'all';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query - use actual audit_logs table
$query = "SELECT l.*, u.full_name, u.email, u.role 
          FROM audit_logs l
          LEFT JOIN users u ON l.user_id = u.user_id
          WHERE 1=1";
$params = [];

if ($action_filter !== 'all') {
    $query .= " AND l.action = ?";
    $params[] = $action_filter;
}

if ($role_filter !== 'all') {
    $query .= " AND u.role = ?";
    $params[] = $role_filter;
}

if (!empty($search)) {
    $query .= " AND (l.action LIKE ? OR l.details LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
}

$query .= " ORDER BY l.created_at DESC LIMIT 100";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$logs = $stmt->fetchAll();

// Get statistics
$total_logs = count($logs);
$login_count = 0;
$logout_count = 0;
$registration_count = 0;
$verification_count = 0;
$approval_count = 0;
$rejection_count = 0;
$other_count = 0;

foreach ($logs as $log) {
    $action = $log['action'] ?? '';
    if (stripos($action, 'Login') !== false) $login_count++;
    elseif (stripos($action, 'Logout') !== false) $logout_count++;
    elseif (stripos($action, 'Registration') !== false || stripos($action, 'Registered') !== false) $registration_count++;
    elseif (stripos($action, 'Verification') !== false || stripos($action, 'Verified') !== false) $verification_count++;
    elseif (stripos($action, 'Approved') !== false) $approval_count++;
    elseif (stripos($action, 'Rejected') !== false) $rejection_count++;
    else $other_count++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Metric Logs | Admin Workspace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F9F9FB;           
            --border-light: #E2E8F0;
            --alert-red: #EF4444;
            --aloe-green: #008543;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }

        /* --- SIDEBAR --- */
        .admin-sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu-container { 
            flex: 1; 
            overflow-y: auto; 
            padding: 15px 0; 
            background: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 0; 
            margin: 0; 
        }
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        /* --- MAIN CONTENT --- */
        .admin-container { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--cream-bg);
        }

        /* --- TOP HEADER --- */
        .admin-top-header { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .admin-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .admin-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        /* Profile Dropdown */
        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--cream-bg);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        /* --- PAGE CONTENT --- */
        .admin-main { 
            padding: 30px 35px; 
        }

        .admin-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .admin-page-header h2 { 
            margin: 0; 
            font-weight: 800; 
            font-size: 1.4rem; 
        }
        .admin-page-header h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }

        /* Filter Navigation */
        .filter-nav {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-btn {
            padding: 6px 16px;
            border-radius: 6px;
            border: 1px solid var(--border-light);
            background: var(--white);
            text-decoration: none;
            color: var(--dark-text);
            font-weight: 600;
            font-size: 0.78rem;
            transition: 0.2s;
        }

        .filter-btn:hover {
            background: var(--softcare-light-blue);
            border-color: var(--softcare-blue);
        }

        .filter-btn.active {
            background: var(--softcare-blue);
            color: white;
            border-color: var(--softcare-blue);
        }

        .search-box {
            display: flex;
            gap: 8px;
            align-items: center;
            margin-bottom: 20px;
        }

        .search-box input {
            padding: 8px 14px;
            border: 1px solid var(--border-light);
            border-radius: 6px;
            font-size: 0.9rem;
            flex: 1;
            max-width: 300px;
            background: var(--white);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--softcare-blue);
        }

        /* Status Summary Cards */
        .summary-dashboard-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 25px;
        }

        .metric-card-box {
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            padding: 14px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }

        .metric-card-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        }

        .metric-card-box .metric-info h5 {
            margin: 0 0 2px 0;
            font-size: 0.65rem;
            color: var(--muted-text);
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
        }

        .metric-card-box .metric-info .metric-val {
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .metric-card-box .metric-icon {
            width: 34px;
            height: 34px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            color: var(--white);
            flex-shrink: 0;
        }

        .metric-card-box .metric-icon.blue { background: var(--softcare-blue); }
        .metric-card-box .metric-icon.green { background: var(--aloe-green); }
        .metric-card-box .metric-icon.yellow { background: var(--mustard-yellow); }
        .metric-card-box .metric-icon.red { background: var(--alert-red); }

        /* Table Card */
        .data-table-card { 
            background: var(--white); 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.02); 
            border: 1px solid var(--border-light);
            overflow: hidden; 
        }

        .table-responsive { 
            width: 100%; 
            overflow-x: auto; 
        }

        table { 
            width: 100%; 
            border-collapse: collapse; 
            text-align: left; 
            font-size: 0.92rem; 
        }
        th { 
            background: var(--cream-bg); 
            color: var(--dark-text); 
            padding: 12px 18px; 
            font-weight: 700; 
            text-transform: uppercase; 
            font-size: 0.7rem; 
            letter-spacing: 0.5px; 
            border-bottom: 2px solid var(--border-light); 
        }
        td { 
            padding: 12px 18px; 
            border-bottom: 1px solid var(--border-light); 
            color: var(--dark-text); 
            vertical-align: middle; 
        }
        tr:hover td { 
            background: var(--softcare-light-blue); 
        }
        tr:last-child td { 
            border-bottom: none; 
        }

        .badge-action {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
        }

        .badge-action.login { background: #DCFCE7; color: var(--aloe-green); }
        .badge-action.logout { background: #FEF2F2; color: var(--alert-red); }
        .badge-action.registration { background: #FFFBEB; color: #B45309; }
        .badge-action.verification { background: #E6F4FC; color: var(--softcare-blue); }
        .badge-action.approved { background: #DCFCE7; color: var(--aloe-green); }
        .badge-action.rejected { background: #FEF2F2; color: var(--alert-red); }
        .badge-action.default { background: var(--border-light); color: var(--muted-text); }

        .badge-role {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.65rem;
            font-weight: 700;
        }

        .badge-role.admin { background: #E6F4FC; color: var(--softcare-blue); }
        .badge-role.student { background: #FFFBEB; color: #B45309; }
        .badge-role.company { background: #DCFCE7; color: var(--aloe-green); }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted-text);
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--border-light);
            margin-bottom: 15px;
            display: block;
        }

        /* Mobile Responsive */
        @media (max-width: 992px) {
            .summary-dashboard-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .admin-sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .admin-container { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .admin-top-header { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .admin-name { font-size: 0.75rem; max-width: 80px; }
            .admin-avatar-circle { width: 28px; height: 28px; }
            .admin-main { padding: 16px; }
            .admin-page-header { flex-direction: column; align-items: flex-start; }
            .admin-page-header h2 { font-size: 1.1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr 1fr; gap: 10px; }
            .metric-card-box { padding: 12px 14px; }
            .metric-card-box .metric-info .metric-val { font-size: 1.1rem; }
            .metric-card-box .metric-icon { width: 30px; height: 30px; font-size: 0.8rem; }
            .filter-nav { gap: 4px; }
            .filter-btn { padding: 4px 10px; font-size: 0.7rem; }
            .search-box input { max-width: 100%; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
        }

        @media (max-width: 576px) {
            .admin-sidebar { width: 60px; }
            .admin-container { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .admin-top-header { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .admin-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .admin-avatar-circle { width: 26px; height: 26px; }
            .admin-main { padding: 12px; }
            .admin-page-header h2 { font-size: 1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr; gap: 8px; }
            .metric-card-box { padding: 10px 12px; }
            .metric-card-box .metric-info .metric-val { font-size: 1rem; }
            .metric-card-box .metric-icon { width: 26px; height: 26px; font-size: 0.7rem; }
            .filter-btn { padding: 3px 8px; font-size: 0.65rem; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<aside class="admin-sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <div class="sidebar-menu-container">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Overview</span></a></li>
            <li><a href="verify_orgs.php"><i class="fa-solid fa-user-shield"></i> <span>Verify Organizations</span></a></li>
            <li><a href="reset_requests.php"><i class="fa-solid fa-key"></i> <span>Password Resets</span></a></li>
            <li><a href="view_users.php"><i class="fa-solid fa-users-gear"></i> <span>View Users Hub</span></a></li>
            <li><a href="system_settings.php"><i class="fa-solid fa-sliders"></i> <span>System Settings</span></a></li>
            <li><a href="audit_logs.php" class="active"><i class="fa-solid fa-clock-rotate-left"></i> <span>Audit Metric Logs</span></a></li>
        </ul>
    </div>
</aside>

<div class="admin-container">
    <header class="admin-top-header">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-clock-rotate-left"></i> Audit Metric Logs
            </div>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $admin_avatar; ?>" alt="Admin Avatar" class="admin-avatar-circle">
                <span class="admin-name"><?php echo $display_title; ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo $display_title; ?></h5>
                    <p>System Administrator</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="admin-main">
        <div class="admin-page-header">
            <h2><i class="fa-solid fa-clock-rotate-left"></i> System Transaction Audit Metrics</h2>
        </div>

        <!-- Status Summary Cards -->
        <div class="summary-dashboard-cards">
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Total Logs</h5>
                    <div class="metric-val"><?php echo $total_logs; ?></div>
                </div>
                <div class="metric-icon blue">
                    <i class="fa-solid fa-list"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Login Activity</h5>
                    <div class="metric-val"><?php echo $login_count; ?></div>
                </div>
                <div class="metric-icon green">
                    <i class="fa-solid fa-right-to-bracket"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Verifications</h5>
                    <div class="metric-val"><?php echo $verification_count; ?></div>
                </div>
                <div class="metric-icon yellow">
                    <i class="fa-solid fa-user-shield"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Registrations</h5>
                    <div class="metric-val"><?php echo $registration_count; ?></div>
                </div>
                <div class="metric-icon red">
                    <i class="fa-solid fa-user-plus"></i>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="filter-nav">
            <a href="?action=all&role=all" class="filter-btn <?php echo ($action_filter === 'all' && $role_filter === 'all' ? 'active' : ''); ?>">All Logs</a>
            <a href="?action=Login&role=all" class="filter-btn <?php echo ($action_filter === 'Login' ? 'active' : ''); ?>">Logins</a>
            <a href="?action=Logout&role=all" class="filter-btn <?php echo ($action_filter === 'Logout' ? 'active' : ''); ?>">Logouts</a>
            <a href="?action=Registration&role=all" class="filter-btn <?php echo ($action_filter === 'Registration' ? 'active' : ''); ?>">Registrations</a>
            <a href="?action=Verification&role=all" class="filter-btn <?php echo ($action_filter === 'Verification' ? 'active' : ''); ?>">Verifications</a>
            <a href="?action=Approved&role=all" class="filter-btn <?php echo ($action_filter === 'Approved' ? 'active' : ''); ?>">Approvals</a>
            <a href="?action=Rejected&role=all" class="filter-btn <?php echo ($action_filter === 'Rejected' ? 'active' : ''); ?>">Rejections</a>
        </div>

        <div class="filter-nav" style="margin-top:-10px;">
            <a href="?role=all&action=<?php echo $action_filter; ?>" class="filter-btn <?php echo ($role_filter === 'all' ? 'active' : ''); ?>">All Roles</a>
            <a href="?role=admin&action=<?php echo $action_filter; ?>" class="filter-btn <?php echo ($role_filter === 'admin' ? 'active' : ''); ?>">Admins</a>
            <a href="?role=student&action=<?php echo $action_filter; ?>" class="filter-btn <?php echo ($role_filter === 'student' ? 'active' : ''); ?>">Students</a>
            <a href="?role=company&action=<?php echo $action_filter; ?>" class="filter-btn <?php echo ($role_filter === 'company' ? 'active' : ''); ?>">Companies</a>
        </div>

        <!-- Search -->
        <div class="search-box">
            <form method="GET" style="display:flex; gap:8px; flex:1; flex-wrap:wrap;">
                <input type="hidden" name="action" value="<?php echo $action_filter; ?>">
                <input type="hidden" name="role" value="<?php echo $role_filter; ?>">
                <input type="text" name="search" placeholder="Search logs..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="filter-btn active" style="border:none; cursor:pointer;">Search</button>
                <?php if(!empty($search)): ?>
                    <a href="?action=<?php echo $action_filter; ?>&role=<?php echo $role_filter; ?>" class="filter-btn" style="background:var(--border-light);">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="data-table-card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User</th>
                            <th>Role</th>
                            <th>Action</th>
                            <th>Details</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($logs)): ?>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <i class="fa-regular fa-clock"></i>
                                        <h4>No Audit Logs Found</h4>
                                        <p>No system activity logs match your filters.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            $counter = 1;
                            foreach($logs as $log): 
                                $action = $log['action'] ?? 'Unknown';
                                $action_class = 'default';
                                if (stripos($action, 'Login') !== false) $action_class = 'login';
                                elseif (stripos($action, 'Logout') !== false) $action_class = 'logout';
                                elseif (stripos($action, 'Registration') !== false || stripos($action, 'Registered') !== false) $action_class = 'registration';
                                elseif (stripos($action, 'Verification') !== false || stripos($action, 'Verified') !== false) $action_class = 'verification';
                                elseif (stripos($action, 'Approved') !== false) $action_class = 'approved';
                                elseif (stripos($action, 'Rejected') !== false) $action_class = 'rejected';
                                
                                $role = $log['role'] ?? 'N/A';
                                $role_class = 'default';
                                if ($role === 'admin') $role_class = 'admin';
                                elseif ($role === 'student') $role_class = 'student';
                                elseif ($role === 'company') $role_class = 'company';
                                
                                $display_name = $log['full_name'] ?? $log['email'] ?? 'System';
                                $user_identifier = $log['user_id'] ? 'User #' . $log['user_id'] : 'System';
                            ?>
                                <tr>
                                    <td><strong><?php echo $counter++; ?></strong></td>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:8px;">
                                            <div style="width:28px; height:28px; border-radius:50%; background:var(--softcare-light-blue); display:flex; align-items:center; justify-content:center; color:var(--softcare-blue); font-size:0.7rem;">
                                                <i class="fa-solid fa-user"></i>
                                            </div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($display_name); ?></strong>
                                                <div style="font-size:0.7rem; color:var(--muted-text);"><?php echo htmlspecialchars($user_identifier); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge-role <?php echo $role_class; ?>">
                                            <?php echo ucfirst(htmlspecialchars($role)); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge-action <?php echo $action_class; ?>">
                                            <?php echo htmlspecialchars($action); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div style="max-width:300px; font-size:0.85rem; color:var(--muted-text);">
                                            <?php echo htmlspecialchars($log['details'] ?? 'No additional details'); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <small style="color:var(--muted-text);">
                                            <i class="fa-regular fa-clock"></i>
                                            <?php echo date('M d, Y H:i', strtotime($log['created_at'] ?? 'now')); ?>
                                        </small>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});
</script>
</body>
</html>