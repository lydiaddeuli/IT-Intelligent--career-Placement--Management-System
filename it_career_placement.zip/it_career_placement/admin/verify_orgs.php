<?php
session_start();
include('includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];
$display_title = "System Admin";
$admin_avatar = "https://ui-avatars.com/api/?name=Admin&background=0091DF&color=fff&size=40";

try {
    $admin_stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $admin_stmt->execute([$admin_id]);
    $admin_profile = $admin_stmt->fetch();
    if ($admin_profile) {
        if (isset($admin_profile['username'])) { $display_title = htmlspecialchars($admin_profile['username']); }
        elseif (isset($admin_profile['email'])) { $display_title = htmlspecialchars(explode('@', $admin_profile['email'])[0]); }
        
        if (!empty($admin_profile['profile_pic'])) { 
            $admin_avatar = "../" . $admin_profile['profile_pic']; 
        } else {
            $admin_avatar = "https://ui-avatars.com/api/?name=" . urlencode($display_title) . "&background=0091DF&color=fff&size=40";
        }
    }
} catch (PDOException $e) {}

// Handle Approve
if (isset($_GET['approve_id'])) {
    $org_id = intval($_GET['approve_id']);
    $update = $pdo->prepare("UPDATE organizations SET verification_status = 'Approved', rejection_reason = NULL WHERE org_id = ?");
    $update->execute([$org_id]);
    $_SESSION['verify_success'] = "Organization approved successfully!";
    header("Location: verify_orgs.php");
    exit();
}

// Handle Reject with reason
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $org_id = intval($_POST['org_id']);
    $action = $_POST['status_action'];
    
    if ($action === 'Approved') {
        $update = $pdo->prepare("UPDATE organizations SET verification_status = 'Approved', rejection_reason = NULL WHERE org_id = ?");
        $update->execute([$org_id]);
        $_SESSION['verify_success'] = "Organization approved successfully!";
    } else {
        $missing_items = isset($_POST['missing_items']) ? $_POST['missing_items'] : [];
        $custom_notes = trim($_POST['custom_notes']);
        
        $reason_text = "Missing/Incorrect Items: " . implode(', ', $missing_items);
        if (!empty($custom_notes)) {
            $reason_text .= ". Administrative Notes: " . $custom_notes;
        }

        $update = $pdo->prepare("UPDATE organizations SET verification_status = 'Action Required', rejection_reason = ? WHERE org_id = ?");
        $update->execute([$reason_text, $org_id]);
        $_SESSION['verify_success'] = "Requirements notification sent to organization.";
    }
    header("Location: verify_orgs.php");
    exit();
}

// Fetch ALL organizations
$all_orgs = $pdo->query("SELECT * FROM organizations ORDER BY FIELD(verification_status, 'Pending', 'Action Required', 'Approved', 'Rejected'), org_id DESC")->fetchAll();

// Separate lists
$pending_orgs = array_filter($all_orgs, function($org) {
    return $org['verification_status'] === 'Pending' || $org['verification_status'] === 'Action Required';
});

$verified_orgs = array_filter($all_orgs, function($org) {
    return $org['verification_status'] === 'Approved';
});

$rejected_orgs = array_filter($all_orgs, function($org) {
    return $org['verification_status'] === 'Rejected';
});

// Counts
$pending_count = count($pending_orgs);
$verified_count = count($verified_orgs);
$rejected_count = count($rejected_orgs);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Organizations | Admin Workspace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F9F9FB;           
            --border-light: #E2E8F0;
            --alert-red: #EF4444;
            --aloe-green: #008543;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }

        /* --- SIDEBAR --- */
        .admin-sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu-container { 
            flex: 1; 
            overflow-y: auto; 
            padding: 15px 0; 
            background: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 0; 
            margin: 0; 
        }
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        /* --- MAIN CONTENT --- */
        .admin-container { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--cream-bg);
        }

        /* --- TOP HEADER --- */
        .admin-top-header { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .admin-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .admin-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        /* Profile Dropdown */
        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--cream-bg);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        /* --- PAGE CONTENT --- */
        .admin-main { 
            padding: 30px 35px; 
        }

        .admin-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .admin-page-header h2 { 
            margin: 0; 
            font-weight: 800; 
            font-size: 1.4rem; 
        }
        .admin-page-header h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }

        .btn-verify-new {
            background: var(--softcare-blue);
            color: white;
            padding: 10px 24px;
            border-radius: 8px;
            border: none;
            font-weight: 700;
            font-size: 0.9rem;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-verify-new:hover {
            background: #0077b6;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 145, 223, 0.3);
        }

        /* --- TABS --- */
        .tabs-container {
            display: flex;
            gap: 5px;
            margin-bottom: 25px;
            border-bottom: 2px solid var(--border-light);
            flex-wrap: wrap;
        }

        .tab-btn {
            padding: 10px 24px;
            border: none;
            background: transparent;
            font-weight: 700;
            font-size: 0.9rem;
            color: var(--muted-text);
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .tab-btn:hover {
            color: var(--dark-text);
        }

        .tab-btn.active {
            color: var(--softcare-blue);
            border-bottom-color: var(--softcare-blue);
        }

        .tab-btn .tab-count {
            background: var(--cream-bg);
            padding: 1px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            color: var(--muted-text);
        }

        .tab-btn.active .tab-count {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Table Card */
        .data-table-card { 
            background: var(--white); 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.02); 
            border: 1px solid var(--border-light);
            overflow: hidden; 
        }

        .table-responsive { 
            width: 100%; 
            overflow-x: auto; 
        }

        table { 
            width: 100%; 
            border-collapse: collapse; 
            text-align: left; 
            font-size: 0.92rem; 
        }
        th { 
            background: var(--cream-bg); 
            color: var(--dark-text); 
            padding: 14px 20px; 
            font-weight: 700; 
            text-transform: uppercase; 
            font-size: 0.72rem; 
            letter-spacing: 0.5px; 
            border-bottom: 2px solid var(--border-light); 
        }
        td { 
            padding: 14px 20px; 
            border-bottom: 1px solid var(--border-light); 
            color: var(--dark-text); 
            vertical-align: middle; 
        }
        tr:hover td { 
            background: var(--softcare-light-blue); 
        }
        tr:last-child td { 
            border-bottom: none; 
        }

        .badge { 
            padding: 4px 12px; 
            border-radius: 20px; 
            font-size: 0.72rem; 
            font-weight: 700; 
            display: inline-flex; 
            align-items: center; 
            gap: 5px; 
        }
        .badge-pending { background: #FFFBEB; color: #B45309; border: 1px solid #FCD34D; }
        .badge-action { background: #FEF2F2; color: #991B1B; border: 1px solid #FEE2E2; }
        .badge-approved { background: #DCFCE7; color: var(--aloe-green); border: 1px solid #BBF7D0; }
        .badge-rejected { background: #FEF2F2; color: var(--alert-red); border: 1px solid #FEE2E2; }

        .btn-action { 
            padding: 6px 14px; 
            border-radius: 6px; 
            font-weight: 700; 
            font-size: 0.75rem; 
            cursor: pointer; 
            text-decoration: none; 
            display: inline-flex; 
            align-items: center; 
            gap: 5px; 
            border: none; 
            transition: 0.2s; 
        }
        .btn-view { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .btn-view:hover { 
            background: #BAE0F7; 
        }
        .btn-approve { 
            background: #DCFCE7; 
            color: var(--aloe-green); 
        }
        .btn-approve:hover { 
            background: #BBF7D0; 
        }
        .btn-reject { 
            background: #FEF2F2; 
            color: var(--alert-red); 
        }
        .btn-reject:hover { 
            background: #FEE2E2; 
        }

        .action-buttons {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }

        .success-message {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 14px 20px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--muted-text);
        }

        .empty-state i {
            font-size: 2.5rem;
            color: var(--border-light);
            margin-bottom: 12px;
            display: block;
        }

        .empty-state h4 {
            margin: 0 0 5px 0;
            color: var(--dark-text);
        }

        /* --- VERIFICATION MODAL --- */
        .modal-backdrop { 
            display: none; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.5); 
            z-index: 2000; 
            justify-content: center; 
            align-items: center; 
            backdrop-filter: blur(4px);
        }
        .modal-box { 
            background: var(--white); 
            padding: 30px; 
            border-radius: 12px; 
            width: 550px; 
            max-width: 95%; 
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); 
            border-top: 4px solid var(--softcare-blue); 
            color: var(--dark-text); 
        }
        .modal-box h3 { 
            margin-top: 0; 
            font-weight: 800; 
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.2rem;
        }
        .modal-box .close-modal {
            margin-left: auto;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--muted-text);
        }
        .modal-box .close-modal:hover {
            color: var(--alert-red);
        }

        .modal-section {
            margin: 20px 0;
            padding: 16px;
            background: var(--cream-bg);
            border-radius: 8px;
            border: 1px solid var(--border-light);
        }

        .modal-section .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            border-bottom: 1px solid var(--border-light);
        }

        .modal-section .detail-row:last-child {
            border-bottom: none;
        }

        .modal-section .detail-label {
            font-weight: 600;
            color: var(--muted-text);
        }

        .modal-section .detail-value {
            font-weight: 700;
            color: var(--dark-text);
        }

        .modal-actions { 
            display: flex; 
            justify-content: flex-end; 
            gap: 10px; 
            margin-top: 20px; 
            flex-wrap: wrap;
        }

        .checkbox-group { 
            margin: 15px 0; 
            display: flex; 
            flex-direction: column; 
            gap: 8px; 
        }
        .checkbox-group label { 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-weight: 600; 
            font-size: 0.85rem; 
            cursor: pointer; 
        }
        .textarea-notes { 
            width: 100%; 
            height: 80px; 
            box-sizing: border-box; 
            border: 1px solid var(--border-light); 
            padding: 10px; 
            border-radius: 6px; 
            resize: vertical; 
            font-family: inherit; 
            margin-top: 10px; 
        }

        .btn-primary {
            background: var(--softcare-blue);
            color: white;
            padding: 10px 24px;
            border: none;
            border-radius: 6px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-primary:hover {
            background: #0077b6;
        }

        .btn-danger {
            background: var(--alert-red);
            color: white;
            padding: 10px 24px;
            border: none;
            border-radius: 6px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-danger:hover {
            background: #DC2626;
        }

        .btn-success {
            background: var(--aloe-green);
            color: white;
            padding: 10px 24px;
            border: none;
            border-radius: 6px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-success:hover {
            background: #006B36;
        }

        .btn-secondary {
            background: var(--border-light);
            color: var(--dark-text);
            padding: 10px 24px;
            border: none;
            border-radius: 6px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-secondary:hover {
            background: #CBD5E0;
        }

        /* --- Fee and Document Modals --- */
        .sub-modal-backdrop {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 3000;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(4px);
        }

        .sub-modal-box {
            background: var(--white);
            padding: 30px;
            border-radius: 12px;
            width: 450px;
            max-width: 95%;
            max-height: 85vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border-top: 4px solid var(--softcare-blue);
            color: var(--dark-text);
        }

        .sub-modal-box h3 {
            margin-top: 0;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.1rem;
        }

        .sub-modal-box .close-sub-modal {
            margin-left: auto;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--muted-text);
        }

        .sub-modal-box .close-sub-modal:hover {
            color: var(--alert-red);
        }

        .doc-item {
            padding: 10px 0;
            border-bottom: 1px solid var(--border-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .doc-item:last-child {
            border-bottom: none;
        }

        .doc-item .doc-name {
            font-weight: 600;
            color: var(--dark-text);
        }

        .doc-item .doc-link {
            color: var(--softcare-blue);
            text-decoration: none;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 4px;
            background: var(--softcare-light-blue);
        }

        .doc-item .doc-link:hover {
            background: #BAE0F7;
        }

        .fee-detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid var(--border-light);
        }

        .fee-detail-row:last-child {
            border-bottom: none;
        }

        .fee-detail-row .fee-label {
            font-weight: 600;
            color: var(--muted-text);
        }

        .fee-detail-row .fee-value {
            font-weight: 700;
            color: var(--dark-text);
        }

        .fee-total {
            background: var(--cream-bg);
            padding: 12px;
            border-radius: 6px;
            margin-top: 10px;
            display: flex;
            justify-content: space-between;
            font-weight: 800;
            font-size: 1.05rem;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .admin-sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .admin-container { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .admin-top-header { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .admin-name { font-size: 0.75rem; max-width: 80px; }
            .admin-avatar-circle { width: 28px; height: 28px; }
            .admin-main { padding: 16px; }
            .admin-page-header { flex-direction: column; align-items: flex-start; }
            .admin-page-header h2 { font-size: 1.1rem; }
            .btn-verify-new { width: 100%; justify-content: center; }
            .tabs-container { gap: 2px; }
            .tab-btn { padding: 8px 14px; font-size: 0.8rem; }
            .action-buttons { flex-direction: column; align-items: flex-start; gap: 4px; }
            th, td { padding: 10px 12px; font-size: 0.8rem; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
            .modal-box { padding: 20px; width: 95%; }
            .modal-box h3 { font-size: 1rem; }
            .sub-modal-box { padding: 20px; width: 95%; }
        }

        @media (max-width: 576px) {
            .admin-sidebar { width: 60px; }
            .admin-container { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .admin-top-header { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .admin-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .admin-avatar-circle { width: 26px; height: 26px; }
            .admin-main { padding: 12px; }
            .admin-page-header h2 { font-size: 1rem; }
            .tab-btn { padding: 6px 10px; font-size: 0.7rem; }
            .tab-btn .tab-count { font-size: 0.65rem; padding: 0 6px; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
            .modal-box { padding: 16px; }
            .modal-actions { flex-direction: column; }
            .modal-actions button { width: 100%; justify-content: center; }
            .sub-modal-box { padding: 16px; }
        }
    </style>
</head>
<body>

<aside class="admin-sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <div class="sidebar-menu-container">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Overview</span></a></li>
            <li><a href="verify_orgs.php" class="active"><i class="fa-solid fa-user-shield"></i> <span>Verify Organizations</span></a></li>
            
            <li><a href="reset_requests.php"><i class="fa-solid fa-key"></i> <span>Password Resets</span></a></li>
            <li><a href="view_users.php"><i class="fa-solid fa-users-gear"></i> <span>View Users Hub</span></a></li>
            
            <li><a href="system_settings.php"><i class="fa-solid fa-sliders"></i> <span>System Settings</span></a></li>
            <li><a href="audit_logs.php"><i class="fa-solid fa-clock-rotate-left"></i> <span>Audit Metric Logs</span></a></li>
        </ul>
    </div>
</aside>

<div class="admin-container">
    <header class="admin-top-header">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-user-shield"></i> Verify Organizations
            </div>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $admin_avatar; ?>" alt="Admin Avatar" class="admin-avatar-circle">
                <span class="admin-name"><?php echo $display_title; ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo $display_title; ?></h5>
                    <p>System Administrator</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="admin-main">
        <?php if (isset($_SESSION['verify_success'])): ?>
            <div class="success-message">
                <i class="fa-solid fa-circle-check"></i> <?php echo $_SESSION['verify_success']; unset($_SESSION['verify_success']); ?>
            </div>
        <?php endif; ?>

        <div class="admin-page-header">
            <h2><i class="fa-solid fa-user-shield"></i> Verify Corporate Profiles</h2>
            <button class="btn-verify-new" onclick="openVerifyModal()">
                <i class="fa-solid fa-plus-circle"></i> Verify Company
            </button>
        </div>

        <!-- Tabs -->
        <div class="tabs-container">
            <button class="tab-btn active" data-tab="pending" onclick="switchTab('pending')">
                <i class="fa-regular fa-clock"></i> Pending
                <span class="tab-count"><?php echo $pending_count; ?></span>
            </button>
            <button class="tab-btn" data-tab="verified" onclick="switchTab('verified')">
                <i class="fa-regular fa-circle-check"></i> Verified
                <span class="tab-count"><?php echo $verified_count; ?></span>
            </button>
            <button class="tab-btn" data-tab="rejected" onclick="switchTab('rejected')">
                <i class="fa-regular fa-times-circle"></i> Rejected
                <span class="tab-count"><?php echo $rejected_count; ?></span>
            </button>
        </div>

        <!-- Pending Tab -->
        <div class="tab-content active" id="tab-pending">
            <div class="data-table-card">
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Organization</th>
                                <th>Contact Email</th>
                                <th>TIN / Reg</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($pending_orgs)): ?>
                                <tr>
                                    <td colspan="6">
                                        <div class="empty-state">
                                            <i class="fa-regular fa-circle-check"></i>
                                            <h4>No Pending Verifications</h4>
                                            <p>All organizations have been reviewed.</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($pending_orgs as $org): 
                                    $status = $org['verification_status'] ?? 'Pending';
                                    $statusClass = strtolower(str_replace(' ', '-', $status));
                                ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($org['org_name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($org['contact_email']); ?></td>
                                        <td>
                                            <small style="color:var(--muted-text);">
                                                TIN: <?php echo htmlspecialchars($org['tin_number'] ?? 'N/A'); ?><br>
                                                Reg: <?php echo htmlspecialchars($org['reg_number'] ?? 'N/A'); ?>
                                            </small>
                                        </td>
                                        <td><?php echo htmlspecialchars($org['location'] ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $statusClass; ?>">
                                                <?php if($status === 'Pending'): ?>
                                                    <i class="fa-regular fa-clock"></i> Pending
                                                <?php else: ?>
                                                    <i class="fa-solid fa-triangle-exclamation"></i> Action Required
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <button class="btn-action btn-view" onclick="viewCompanyDetails(<?php echo htmlspecialchars(json_encode($org)); ?>)">
                                                    <i class="fa-solid fa-eye"></i> View
                                                </button>
                                                <a href="?approve_id=<?php echo $org['org_id']; ?>" class="btn-action btn-approve" onclick="return confirm('Approve this organization?')">
                                                    <i class="fa-regular fa-circle-check"></i> Approve
                                                </a>
                                                <button class="btn-action btn-reject" onclick="openFeedbackModal(<?php echo $org['org_id']; ?>, '<?php echo htmlspecialchars($org['org_name'], ENT_QUOTES); ?>')">
                                                    <i class="fa-regular fa-envelope"></i> Notify
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Verified Tab -->
        <div class="tab-content" id="tab-verified">
            <div class="data-table-card">
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Organization</th>
                                <th>Contact Email</th>
                                <th>Website</th>
                                <th>TIN / Reg</th>
                                <th>Location</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($verified_orgs)): ?>
                                <tr>
                                    <td colspan="6">
                                        <div class="empty-state">
                                            <i class="fa-regular fa-building"></i>
                                            <h4>No Verified Companies</h4>
                                            <p>Companies you approve will appear here.</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($verified_orgs as $org): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($org['org_name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($org['contact_email']); ?></td>
                                        <td>
                                            <?php if(!empty($org['website'])): ?>
                                                <a href="<?php echo htmlspecialchars($org['website']); ?>" target="_blank" style="color:var(--softcare-blue); text-decoration:none;">
                                                    <?php echo htmlspecialchars($org['website']); ?>
                                                </a>
                                            <?php else: ?>
                                                <span style="color:var(--muted-text);">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small style="color:var(--muted-text);">
                                                TIN: <?php echo htmlspecialchars($org['tin_number'] ?? 'N/A'); ?><br>
                                                Reg: <?php echo htmlspecialchars($org['reg_number'] ?? 'N/A'); ?>
                                            </small>
                                        </td>
                                        <td><?php echo htmlspecialchars($org['location'] ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge badge-approved">
                                                <i class="fa-regular fa-circle-check"></i> Approved
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Rejected Tab -->
        <div class="tab-content" id="tab-rejected">
            <div class="data-table-card">
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Organization</th>
                                <th>Contact Email</th>
                                <th>TIN / Reg</th>
                                <th>Location</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($rejected_orgs)): ?>
                                <tr>
                                    <td colspan="5">
                                        <div class="empty-state">
                                            <i class="fa-regular fa-building"></i>
                                            <h4>No Rejected Companies</h4>
                                            <p>No organizations have been rejected yet.</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($rejected_orgs as $org): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($org['org_name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($org['contact_email']); ?></td>
                                        <td>
                                            <small style="color:var(--muted-text);">
                                                TIN: <?php echo htmlspecialchars($org['tin_number'] ?? 'N/A'); ?><br>
                                                Reg: <?php echo htmlspecialchars($org['reg_number'] ?? 'N/A'); ?>
                                            </small>
                                        </td>
                                        <td><?php echo htmlspecialchars($org['location'] ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge badge-rejected">
                                                <i class="fa-regular fa-times-circle"></i> Rejected
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Verify Company Modal -->
<div class="modal-backdrop" id="verifyModal">
    <div class="modal-box">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h3><i class="fa-solid fa-user-shield" style="color:var(--softcare-blue);"></i> Verify Company</h3>
            <button class="close-modal" onclick="closeVerifyModal()">&times;</button>
        </div>
        <p style="color:var(--muted-text); margin-bottom:20px;">Review company details below. Click View Documents or View Fees for more information.</p>
        
        <div class="modal-section">
            <div class="detail-row">
                <span class="detail-label">Company Name</span>
                <span class="detail-value" id="v_org_name">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Contact Email</span>
                <span class="detail-value" id="v_org_email">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Website</span>
                <span class="detail-value" id="v_org_website">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Location</span>
                <span class="detail-value" id="v_org_location">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">TIN Number</span>
                <span class="detail-value" id="v_org_tin">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Registration Number</span>
                <span class="detail-value" id="v_org_reg">-</span>
            </div>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap; margin:15px 0;">
            <button type="button" class="btn-action btn-view" onclick="viewDocuments()">
                <i class="fa-solid fa-file-pdf"></i> View Documents
            </button>
            <button type="button" class="btn-action btn-view" onclick="viewFees()">
                <i class="fa-solid fa-hand-holding-dollar"></i> View Fees
            </button>
        </div>

        <form method="POST">
            <input type="hidden" name="org_id" id="modalOrgId">
            <input type="hidden" name="status_action" value="Approved">
            
            <div class="checkbox-group">
                <label><input type="checkbox" name="missing_items[]" value="Incomplete Payment Descriptions"> Incomplete Payment Descriptions</label>
                <label><input type="checkbox" name="missing_items[]" value="Invalid BRELA Certificate / Missing"> Invalid BRELA Certificate / Missing</label>
                <label><input type="checkbox" name="missing_items[]" value="Invalid TIN Verification Number"> Invalid TIN Verification Number</label>
                <label><input type="checkbox" name="missing_items[]" value="Incorrect Industry Mapping"> Incorrect Industry Mapping</label>
                <label><input type="checkbox" name="missing_items[]" value="Missing Compliance Documents"> Missing Compliance Documents</label>
            </div>

            <label style="font-weight:700; font-size:0.85rem; display:block; margin-top:15px;">Additional Guidance Notes:</label>
            <textarea name="custom_notes" class="textarea-notes" placeholder="Type clarification details here to assist the organization..."></textarea>

            <div class="modal-actions">
                <button type="button" class="btn-secondary" onclick="closeVerifyModal()">Cancel</button>
                <button type="submit" name="update_status" class="btn-success" onclick="document.getElementById('modalOrgId').value = currentOrgId">Approve Company</button>
                <button type="submit" name="update_status" class="btn-danger" onclick="document.getElementById('modalOrgId').value = currentOrgId; this.form.querySelector('input[name=status_action]').value='Action Required'">Send Feedback</button>
            </div>
        </form>
    </div>
</div>

<!-- Documents Modal -->
<div class="sub-modal-backdrop" id="documentsModal">
    <div class="sub-modal-box">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h3><i class="fa-solid fa-file-pdf" style="color:var(--softcare-blue);"></i> Company Documents</h3>
            <button class="close-sub-modal" onclick="closeDocumentsModal()">&times;</button>
        </div>
        <div id="documentsList">
            <div class="doc-item">
                <span class="doc-name">BRELA Registration Certificate</span>
                <a href="#" class="doc-link" id="doc_brela" target="_blank"><i class="fa-solid fa-download"></i> View</a>
            </div>
            <div class="doc-item">
                <span class="doc-name">TIN Certificate</span>
                <a href="#" class="doc-link" id="doc_tin" target="_blank"><i class="fa-solid fa-download"></i> View</a>
            </div>
            <div class="doc-item">
                <span class="doc-name">Compliance Documents</span>
                <a href="#" class="doc-link" id="doc_compliance" target="_blank"><i class="fa-solid fa-download"></i> View</a>
            </div>
        </div>
        <div style="margin-top:15px; color:var(--muted-text); font-size:0.85rem;">
            <i class="fa-regular fa-info-circle"></i> Documents are uploaded by the company during registration.
        </div>
        <div class="modal-actions">
            <button type="button" class="btn-secondary" onclick="closeDocumentsModal()">Close</button>
        </div>
    </div>
</div>

<!-- Fees Modal -->
<div class="sub-modal-backdrop" id="feesModal">
    <div class="sub-modal-box">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h3><i class="fa-solid fa-hand-holding-dollar" style="color:var(--mustard-yellow);"></i> Fee Structure</h3>
            <button class="close-sub-modal" onclick="closeFeesModal()">&times;</button>
        </div>
        <div id="feesDetails">
            <div class="fee-detail-row">
                <span class="fee-label">Fee Framework</span>
                <span class="fee-value" id="fee_framework">-</span>
            </div>
            <div class="fee-detail-row">
                <span class="fee-label">Registration Fee</span>
                <span class="fee-value" id="fee_registration">-</span>
            </div>
            <div class="fee-detail-row">
                <span class="fee-label">Direct Field Cost</span>
                <span class="fee-value" id="fee_direct">-</span>
            </div>
            <div class="fee-detail-row">
                <span class="fee-label">Justification</span>
                <span class="fee-value" id="fee_reason">-</span>
            </div>
            <div class="fee-total">
                <span>Total Fees</span>
                <span id="fee_total">-</span>
            </div>
        </div>
        <div class="modal-actions">
            <button type="button" class="btn-secondary" onclick="closeFeesModal()">Close</button>
        </div>
    </div>
</div>

<!-- Feedback Modal -->
<div class="modal-backdrop" id="feedbackModal">
    <div class="modal-box">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h3><i class="fa-solid fa-envelope-open-text" style="color:var(--mustard-yellow);"></i> Notify Missing Requirements</h3>
            <button class="close-modal" onclick="closeFeedbackModal()">&times;</button>
        </div>
        <p id="modalOrgTitle" style="color:var(--muted-text); margin-bottom:15px;">Send feedback to organization</p>
        <form method="POST">
            <input type="hidden" name="org_id" id="feedbackOrgId">
            <input type="hidden" name="status_action" value="Action Required">
            
            <div class="checkbox-group">
                <label><input type="checkbox" name="missing_items[]" value="Incomplete Payment Descriptions"> Incomplete Payment Descriptions</label>
                <label><input type="checkbox" name="missing_items[]" value="Invalid BRELA Certificate / Missing"> Invalid BRELA Certificate / Missing</label>
                <label><input type="checkbox" name="missing_items[]" value="Invalid TIN Verification Number"> Invalid TIN Verification Number</label>
                <label><input type="checkbox" name="missing_items[]" value="Incorrect Industry Mapping"> Incorrect Industry Mapping</label>
                <label><input type="checkbox" name="missing_items[]" value="Missing Compliance Documents"> Missing Compliance Documents</label>
            </div>

            <label style="font-weight:700; font-size:0.85rem; display:block; margin-top:15px;">Additional Guidance Notes:</label>
            <textarea name="custom_notes" class="textarea-notes" placeholder="Type clarification details here to assist the organization..."></textarea>

            <div class="modal-actions">
                <button type="button" class="btn-secondary" onclick="closeFeedbackModal()">Cancel</button>
                <button type="submit" name="update_status" class="btn-danger">Send Feedback</button>
            </div>
        </form>
    </div>
</div>

<script>
// Current organization data for modals
var currentOrg = null;
var currentOrgId = null;

function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});

function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.getElementById('tab-' + tabName).classList.add('active');
    document.querySelector('.tab-btn[data-tab="' + tabName + '"]').classList.add('active');
}

function openVerifyModal() {
    document.getElementById('verifyModal').style.display = 'flex';
    document.getElementById('v_org_name').textContent = 'Select a pending company to verify';
    document.getElementById('v_org_email').textContent = '-';
    document.getElementById('v_org_website').textContent = '-';
    document.getElementById('v_org_location').textContent = '-';
    document.getElementById('v_org_tin').textContent = '-';
    document.getElementById('v_org_reg').textContent = '-';
    currentOrgId = null;
}

function closeVerifyModal() {
    document.getElementById('verifyModal').style.display = 'none';
}

function viewCompanyDetails(org) {
    currentOrg = org;
    currentOrgId = org.org_id;
    document.getElementById('verifyModal').style.display = 'flex';
    document.getElementById('v_org_name').textContent = org.org_name || '-';
    document.getElementById('v_org_email').textContent = org.contact_email || '-';
    document.getElementById('v_org_website').textContent = org.website || 'Not provided';
    document.getElementById('v_org_location').textContent = org.location || 'Not provided';
    document.getElementById('v_org_tin').textContent = org.tin_number || 'Not provided';
    document.getElementById('v_org_reg').textContent = org.reg_number || 'Not provided';
    document.getElementById('modalOrgId').value = org.org_id;
}

function viewDocuments() {
    if (!currentOrg) {
        alert('Please select a company first by clicking "View" on a pending company.');
        return;
    }
    
    // Set document links
    var docPath = currentOrg.verification_documents || '';
    var basePath = '../';
    
    if (docPath) {
        document.getElementById('doc_compliance').href = basePath + docPath;
        document.getElementById('doc_compliance').style.display = 'inline-block';
        document.getElementById('doc_compliance').innerHTML = '<i class="fa-solid fa-file-pdf"></i> View Document';
    } else {
        document.getElementById('doc_compliance').style.display = 'inline-block';
        document.getElementById('doc_compliance').href = '#';
        document.getElementById('doc_compliance').innerHTML = '<i class="fa-solid fa-circle-exclamation"></i> No Document';
        document.getElementById('doc_compliance').style.color = 'var(--alert-red)';
    }
    
    // For BRELA and TIN - they might be separate or combined
    if (currentOrg.reg_number) {
        document.getElementById('doc_brela').style.display = 'inline-block';
        document.getElementById('doc_brela').innerHTML = '<i class="fa-solid fa-file-lines"></i> Reg: ' + currentOrg.reg_number;
        document.getElementById('doc_brela').href = '#';
        document.getElementById('doc_brela').style.cursor = 'default';
    } else {
        document.getElementById('doc_brela').style.display = 'inline-block';
        document.getElementById('doc_brela').innerHTML = '<i class="fa-solid fa-circle-exclamation"></i> Not provided';
        document.getElementById('doc_brela').style.color = 'var(--alert-red)';
    }
    
    if (currentOrg.tin_number) {
        document.getElementById('doc_tin').style.display = 'inline-block';
        document.getElementById('doc_tin').innerHTML = '<i class="fa-solid fa-file-invoice"></i> TIN: ' + currentOrg.tin_number;
        document.getElementById('doc_tin').href = '#';
        document.getElementById('doc_tin').style.cursor = 'default';
    } else {
        document.getElementById('doc_tin').style.display = 'inline-block';
        document.getElementById('doc_tin').innerHTML = '<i class="fa-solid fa-circle-exclamation"></i> Not provided';
        document.getElementById('doc_tin').style.color = 'var(--alert-red)';
    }
    
    document.getElementById('documentsModal').style.display = 'flex';
}

function closeDocumentsModal() {
    document.getElementById('documentsModal').style.display = 'none';
}

function viewFees() {
    if (!currentOrg) {
        alert('Please select a company first by clicking "View" on a pending company.');
        return;
    }
    
    var fees = {};
    try {
        fees = JSON.parse(currentOrg.fee_amounts_json || '{"registration_fee":0,"direct_field_cost":0}');
    } catch(e) {
        fees = {registration_fee: 0, direct_field_cost: 0};
    }
    
    var regFee = parseFloat(fees.registration_fee || 0);
    var dirFee = parseFloat(fees.direct_field_cost || 0);
    var totalFee = regFee + dirFee;
    
    document.getElementById('fee_framework').textContent = currentOrg.has_fees || 'None';
    document.getElementById('fee_registration').textContent = 'TZS ' + regFee.toLocaleString();
    document.getElementById('fee_direct').textContent = 'TZS ' + dirFee.toLocaleString();
    document.getElementById('fee_reason').textContent = currentOrg.fee_reason || 'No justification provided';
    document.getElementById('fee_total').textContent = 'TZS ' + totalFee.toLocaleString();
    
    document.getElementById('feesModal').style.display = 'flex';
}

function closeFeesModal() {
    document.getElementById('feesModal').style.display = 'none';
}

function openFeedbackModal(orgId, orgName) {
    document.getElementById('feedbackOrgId').value = orgId;
    document.getElementById('modalOrgTitle').innerHTML = '<strong>' + orgName + '</strong> - Flag missing requirements';
    document.getElementById('feedbackModal').style.display = 'flex';
}

function closeFeedbackModal() {
    document.getElementById('feedbackModal').style.display = 'none';
}

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal-backdrop')) {
        event.target.style.display = 'none';
    }
    if (event.target.classList.contains('sub-modal-backdrop')) {
        event.target.style.display = 'none';
    }
}
</script>
</body>
</html>