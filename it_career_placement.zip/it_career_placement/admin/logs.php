<?php
session_start();
include('../includes/db_connect.php');

// Strict Admin Authorization Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];

// Handle Log Purge Clear Action cleanly if authorized
if (isset($_POST['purge_logs'])) {
    $purge = $pdo->prepare("DELETE FROM system_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $purge->execute();
    $msg = "System Cleanup Executed: System audit logs older than 30 days have been cleared.";
}

// Fetch Filters
$filter_role = $_GET['role_filter'] ?? 'all';
$search_query = trim($_GET['search'] ?? '');

// Construct SQL query parameters dynamically
$sql = "SELECT * FROM system_logs WHERE 1=1";
$params = [];

if ($filter_role !== 'all') {
    $sql .= " AND role = ?";
    $params[] = $filter_role;
}

if (!empty($search_query)) {
    $sql .= " AND (full_name LIKE ? OR action LIKE ? OR details LIKE ?)";
    $bind_search = "%$search_query%";
    $params[] = $bind_search;
    $params[] = $bind_search;
    $params[] = $bind_search;
}

$sql .= " ORDER BY created_at DESC LIMIT 250";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Audit Logs | Admin Control Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* SYSTEM INTEGRATED RECONCILED COLOR PALETTE:
           Chocolate Brown: #5C4033 | Mustard: #E1AD01 | Sky Blue: #87CEEB | Milk Black: #1A1A1B 
        */
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #fdfbf7; display: flex; }
        
        /* ADMIN PORTAL PANEL SIDEBAR */
        .sidebar { width: 280px; background: #1A1A1B; color: #ffffff; min-height: 100vh; position: fixed; box-shadow: 4px 0 15px rgba(0,0,0,0.1); z-index: 100; }
        .sidebar-header { padding: 40px 20px; background: #5C4033; color: #E1AD01; text-align: center; font-weight: 900; letter-spacing: 1px; font-size: 1.2rem; border-bottom: 3px solid #E1AD01; }
        
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; }
        .sidebar-menu li { margin-bottom: 2px; }
        .sidebar-menu li a { display: flex; align-items: center; padding: 15px 30px; color: #87CEEB; text-decoration: none; transition: 0.3s ease; font-weight: bold; font-size: 0.95rem; }
        .sidebar-menu li a i { margin-right: 18px; width: 24px; font-size: 1.15rem; text-align: center; }
        .sidebar-menu li a:hover { background: rgba(225, 173, 1, 0.1); color: #E1AD01; }
        .sidebar-menu li a.active-page { color: #E1AD01; background: rgba(92, 64, 51, 0.2); border-left: 4px solid #E1AD01; padding-left: 26px; }

        /* WORKSPACE OPERATIONS CONTROLS */
        .main-content { flex: 1; margin-left: 280px; padding: 40px; box-sizing: border-box; }
        .container { background: #fff; padding: 35px; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.03); border-top: 6px solid #5C4033; }
        
        h2 { margin-top: 0; font-weight: 800; color: #1A1A1B; display: flex; align-items: center; gap: 12px; }
        
        /* FILTER MODULE CONTROLLERS */
        .filter-bar { display: flex; gap: 15px; margin-bottom: 25px; background: #faf9f5; padding: 20px; border-radius: 12px; border: 2px solid #f5f2eb; align-items: center; flex-wrap: wrap; }
        .filter-bar form { display: flex; gap: 15px; flex: 1; align-items: center; flex-wrap: wrap; }
        
        .form-control { padding: 11px 15px; border: 2px solid #e2ded6; border-radius: 8px; font-size: 0.9rem; background: #fff; font-family: inherit; font-weight: 600; }
        .form-control:focus { outline: none; border-color: #E1AD01; }
        .search-input { flex: 1; min-width: 200px; }
        
        .btn-action { padding: 11px 20px; border-radius: 8px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; border: none; cursor: pointer; transition: 0.2s; font-size: 0.85rem; display: inline-flex; align-items: center; gap: 8px; }
        .btn-search { background: #1A1A1B; color: #87CEEB; }
        .btn-search:hover { background: #5C4033; color: #fff; }
        .btn-purge { background: #fff1f0; color: #cf1322; border: 1px solid #ffa39e; margin-left: auto; }
        .btn-purge:hover { background: #cf1322; color: #fff; }

        /* LOG TRACK TABLES DESIGN MATRIX */
        .table-responsive { overflow-x: auto; border-radius: 12px; border: 2px solid #f5f2eb; }
        .log-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }
        .log-table th { background: #5C4033; color: #ffffff; padding: 16px; font-weight: 700; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.5px; }
        .log-table td { padding: 15px 16px; border-bottom: 1px solid #f5f2eb; color: #333; line-height: 1.4; vertical-align: middle; }
        .log-table tr:hover { background-color: #faf9f5; }
        
        /* ROLE ACTOR ENGINE BADGES */
        .role-badge { font-size: 0.7rem; padding: 4px 10px; border-radius: 12px; font-weight: 800; text-transform: uppercase; display: inline-block; letter-spacing: 0.3px; }
        .role-student { background: rgba(135,206,235,0.15); color: #1a6280; }
        .role-company { background: rgba(225,173,1,0.15); color: #8a6d01; }
        .role-admin { background: rgba(92,64,51,0.15); color: #5C4033; }
        
        /* AI ANOMALY SECURITY WARNING DETECTOR INDICATORS */
        .ai-indicator { background: #1A1A1B; color: #E1AD01; font-size: 0.65rem; padding: 2px 6px; border-radius: 4px; font-weight: 900; margin-left: 6px; cursor: help; display: inline-flex; align-items: center; gap: 3px; }
        .risk-highlight { background: #fff1f0 !important; }

        .alert-message { padding: 15px; border-radius: 8px; font-weight: 600; margin-bottom: 20px; background: #eef9f0; color: #2b7a43; border-left: 5px solid #2b7a43; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">ADMIN PANEL</div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Control Overview</a></li>
        <li><a href="verify_companies.php"><i class="fa-solid fa-building-circle-check"></i> Verify Organizations</a></li>
        <li><a href="manage_students.php"><i class="fa-solid fa-graduation-cap"></i> Manage Student Tracks</a></li>
        <li><a href="opportunities.php"><i class="fa-solid fa-briefcase"></i> Postings Directory</a></li>
        <li><a href="logs.php" class="active-page"><i class="fa-solid fa-clock-rotate-left"></i> System Audit Logs</a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> Global Settings</a></li>
        <li><a href="../logout.php"><i class="fa-solid fa-power-off"></i> Logout Matrix</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="container">
        <h2><i class="fa-solid fa-clock-rotate-left" style="color: #5C4033;"></i> System Audit Logs & Operational History</h2>
        <p style="color: #666; margin-bottom: 25px; font-weight: 600;">Monitor structural transaction records, account setups, system changes, and matching process traces.</p>

        <?php if (isset($msg)): ?>
            <div class="alert-message"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($msg); ?></div>
        <?php endif; ?>

        <div class="filter-bar">
            <form method="GET" action="logs.php">
                <select name="role_filter" class="form-control" onchange="this.form.submit()">
                    <option value="all">All Structural Roles</option>
                    <option value="student" <?php echo $filter_role === 'student' ? 'selected' : ''; ?>>Students Only</option>
                    <option value="company" <?php echo $filter_role === 'company' ? 'selected' : ''; ?>>Companies Only</option>
                    <option value="admin" <?php echo $filter_role === 'admin' ? 'selected' : ''; ?>>Administrators</option>
                </select>
                
                <input type="text" name="search" class="form-control search-input" placeholder="Search by name, action or event logs parameters..." value="<?php echo htmlspecialchars($search_query); ?>">
                
                <button type="submit" class="btn-action btn-search"><i class="fa-solid fa-magnifying-glass"></i> Filter Logs</button>
            </form>
            
            <form method="POST" onsubmit="return confirm('Purge audit records older than 30 days safely from memory?');">
                <button type="submit" name="purge_logs" class="btn-action btn-purge"><i class="fa-solid fa-trash-can"></i> Purge History</button>
            </form>
        </div>

        <div class="table-responsive">
            <table class="log-table">
                <thead>
                    <tr>
                        <th>Timestamp Reference</th>
                        <th>User Identity Actor</th>
                        <th>System Role</th>
                        <th>Action Log Statement</th>
                        <th>Execution Event Details</th>
                        <th>Network IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <?php 
                          // AI Security Risk Analyzer simulation vector parsing
                          $isSuspicious = (stripos($log['action'], 'failed') !== false || stripos($log['details'], 'unauthorized') !== false);
                        ?>
                        <tr class="<?php echo $isSuspicious ? 'risk-highlight' : ''; ?>">
                            <td style="font-weight: 700; color: #5C4033; white-space: nowrap;">
                                <?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?>
                            </td>
                            <td style="font-weight: bold; color: #1A1A1B;">
                                <?php echo htmlspecialchars($log['full_name']); ?>
                                <small style="display:block; color:#777; font-weight:normal;">UID: #<?php echo $log['user_id']; ?></small>
                            </td>
                            <td>
                                <span class="role-badge role-<?php echo $log['role']; ?>">
                                    <?php echo $log['role']; ?>
                                </span>
                            </td>
                            <td style="font-weight: 700;">
                                <?php echo htmlspecialchars($log['action']); ?>
                                <?php if ($isSuspicious): ?>
                                    <span class="ai-indicator" title="AI Security Scanner flagged this execution as a risk anomaly."><i class="fa-solid fa-shield-cat"></i> AI RISK</span>
                                <?php endif; ?>
                            </td>
                            <td style="color: #555; font-size: 0.85rem; max-width: 320px;">
                                <?php echo htmlspecialchars($log['details']); ?>
                            </td>
                            <td style="font-family: monospace; color: #1a6280;">
                                <?php echo htmlspecialchars($log['ip_address'] ?? '127.0.0.1'); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <?php if (empty($logs)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #999; padding: 40px;">
                                <i class="fa-solid fa-database" style="font-size: 2.5rem; display:block; margin-bottom:10px; color:#ccc;"></i>
                                No system logging records matched the specified criteria parameters.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>