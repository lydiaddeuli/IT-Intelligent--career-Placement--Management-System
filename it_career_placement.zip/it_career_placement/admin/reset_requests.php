<?php
session_start();
include('../includes/db_connect.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];
$display_title = "System Admin";
$admin_avatar = "https://ui-avatars.com/api/?name=Admin&background=0091DF&color=fff&size=40";

try {
    $admin_stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $admin_stmt->execute([$admin_id]);
    $admin_profile = $admin_stmt->fetch();
    if ($admin_profile) {
        if (isset($admin_profile['username'])) { $display_title = htmlspecialchars($admin_profile['username']); }
        elseif (isset($admin_profile['email'])) { $display_title = htmlspecialchars(explode('@', $admin_profile['email'])[0]); }
        if (!empty($admin_profile['profile_pic'])) { $admin_avatar = "../" . $admin_profile['profile_pic']; }
    }
} catch (PDOException $e) {}

// Handle Resolve
if (isset($_GET['resolve'])) {
    $notif_id = intval($_GET['resolve']);
    try {
        $update = $pdo->prepare("UPDATE system_notifications SET is_resolved = 1 WHERE id = ?");
        $update->execute([$notif_id]);
        $_SESSION['reset_success'] = "Password reset request resolved successfully!";
    } catch(PDOException $e) {}
    header("Location: reset_requests.php");
    exit();
}

// Handle Delete (completely remove)
if (isset($_GET['delete'])) {
    $notif_id = intval($_GET['delete']);
    try {
        $delete = $pdo->prepare("DELETE FROM system_notifications WHERE id = ?");
        $delete->execute([$notif_id]);
        $_SESSION['reset_success'] = "Password reset request deleted successfully!";
    } catch(PDOException $e) {}
    header("Location: reset_requests.php");
    exit();
}

// Fetch all requests
$requests = [];
$total_count = 0;
$active_count = 0;
$resolved_count = 0;

try {
    // Get all requests
    $all_requests = $pdo->query("SELECT * FROM system_notifications ORDER BY id DESC")->fetchAll();
    
    // Separate active and resolved
    foreach ($all_requests as $req) {
        if ($req['is_resolved'] == 0) {
            $requests[] = $req;
            $active_count++;
        } else {
            $resolved_count++;
        }
    }
    $total_count = count($all_requests);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Resets | Core Operations</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F9F9FB;           
            --border-light: #E2E8F0;
            --alert-red: #EF4444;
            --aloe-green: #008543;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            min-height: 100vh; 
            color: var(--dark-text); 
        }

        /* --- SIDEBAR --- */
        .admin-sidebar { 
            width: 280px; 
            background: var(--white); 
            position: fixed; 
            top: 0; 
            bottom: 0; 
            box-shadow: 1px 0 10px rgba(0,0,0,0.02); 
            z-index: 100; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid var(--border-light); 
        }
        .sidebar-header { 
            padding: 16px 24px; 
            background: var(--softcare-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            font-weight: 900; 
            font-size: 1.15rem; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }
        .sidebar-logo { 
            height: 36px; 
            width: auto; 
            border-radius: 6px; 
            background: var(--white); 
            padding: 2px; 
            border: 2px solid rgba(255,255,255,0.3);
        }
        .sidebar-header span {
            color: var(--white);
        }
        .sidebar-menu-container { 
            flex: 1; 
            overflow-y: auto; 
            padding: 15px 0; 
            background: var(--white);
        }
        .sidebar-menu { 
            list-style: none; 
            padding: 0; 
            margin: 0; 
        }
        .sidebar-menu li a { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 12px 24px; 
            color: var(--dark-text); 
            text-decoration: none; 
            font-weight: 600; 
            font-size: 0.92rem; 
            transition: 0.2s; 
        }
        .sidebar-menu li a i { 
            width: 20px; 
            text-align: center; 
            color: var(--muted-text);
        }
        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active { 
            background: var(--softcare-light-blue); 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active i { 
            color: var(--softcare-blue); 
        }
        .sidebar-menu li a.active { 
            border-left: 4px solid var(--softcare-blue); 
            padding-left: 20px; 
        }

        /* --- MAIN CONTENT --- */
        .admin-container { 
            flex: 1; 
            margin-left: 280px; 
            display: flex;
            flex-direction: column;
            background: var(--cream-bg);
        }

        /* --- TOP HEADER --- */
        .admin-top-header { 
            background: var(--softcare-blue); 
            padding: 16px 28px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: var(--white);
            min-height: 60px;
            flex-shrink: 0;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .brand-title {
            font-size: 1.1rem; 
            font-weight: 700; 
        }
        .header-left .brand-title i {
            margin-right: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
            border-left: 1px solid rgba(255,255,255,0.2);
            padding-left: 16px;
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .admin-avatar-circle {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .admin-name {
            font-weight: 700;
            font-size: 0.85rem;
            color: var(--white);
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        /* Profile Dropdown */
        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 14px 18px;
            background: var(--cream-bg);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.88rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.68rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        /* --- PAGE CONTENT --- */
        .admin-main { 
            padding: 30px 35px; 
        }

        .admin-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .admin-page-header h2 { 
            margin: 0; 
            font-weight: 800; 
            font-size: 1.4rem; 
        }
        .admin-page-header h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }

        /* Status Summary Cards */
        .summary-dashboard-cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .metric-card-box {
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }

        .metric-card-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        }

        .metric-card-box .metric-info h5 {
            margin: 0 0 2px 0;
            font-size: 0.7rem;
            color: var(--muted-text);
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
        }

        .metric-card-box .metric-info .metric-val {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .metric-card-box .metric-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: var(--white);
            flex-shrink: 0;
        }

        .metric-card-box .metric-icon.active { background: var(--mustard-yellow); }
        .metric-card-box .metric-icon.resolved { background: var(--aloe-green); }
        .metric-card-box .metric-icon.total { background: var(--softcare-blue); }

        /* Table Card */
        .data-table-card { 
            background: var(--white); 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.02); 
            border: 1px solid var(--border-light);
            overflow: hidden; 
        }

        .table-responsive { 
            width: 100%; 
            overflow-x: auto; 
        }

        table { 
            width: 100%; 
            border-collapse: collapse; 
            text-align: left; 
            font-size: 0.92rem; 
        }
        th { 
            background: var(--cream-bg); 
            color: var(--dark-text); 
            padding: 14px 20px; 
            font-weight: 700; 
            text-transform: uppercase; 
            font-size: 0.72rem; 
            letter-spacing: 0.5px; 
            border-bottom: 2px solid var(--border-light); 
        }
        td { 
            padding: 14px 20px; 
            border-bottom: 1px solid var(--border-light); 
            color: var(--dark-text); 
            vertical-align: middle; 
        }
        tr:hover td { 
            background: var(--softcare-light-blue); 
        }
        tr:last-child td { 
            border-bottom: none; 
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.72rem;
            font-weight: 700;
        }

        .badge-active {
            background: #FFFBEB;
            color: #B45309;
            border: 1px solid #FCD34D;
        }

        .badge-resolved {
            background: #DCFCE7;
            color: var(--aloe-green);
            border: 1px solid #BBF7D0;
        }

        .btn-action { 
            padding: 6px 14px; 
            border-radius: 6px; 
            font-weight: 700; 
            font-size: 0.75rem; 
            cursor: pointer; 
            text-decoration: none; 
            display: inline-flex; 
            align-items: center; 
            gap: 5px; 
            border: none; 
            transition: 0.2s; 
        }
        .btn-resolve { 
            background: #DCFCE7; 
            color: var(--aloe-green); 
        }
        .btn-resolve:hover { 
            background: #BBF7D0; 
        }
        .btn-delete { 
            background: #FEF2F2; 
            color: var(--alert-red); 
        }
        .btn-delete:hover { 
            background: #FEE2E2; 
        }

        .action-buttons {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }

        .success-message {
            background: #DCFCE7;
            color: var(--aloe-green);
            padding: 14px 20px;
            border-radius: 8px;
            border: 1px solid #BBF7D0;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted-text);
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--border-light);
            margin-bottom: 15px;
            display: block;
        }

        .empty-state h4 {
            margin: 0 0 8px 0;
            color: var(--dark-text);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .admin-sidebar { width: 70px; }
            .sidebar-header span { display: none; }
            .sidebar-header { padding: 14px 16px; justify-content: center; min-height: 56px; }
            .sidebar-logo { height: 32px; }
            .admin-container { margin-left: 70px; }
            .sidebar-menu li a span { display: none; }
            .sidebar-menu li a { padding: 12px 16px; justify-content: center; }
            .sidebar-menu li a i { margin: 0; font-size: 1.1rem; }
            .sidebar-menu li a.active { padding-left: 16px; border-left: 3px solid var(--softcare-blue); }
            .admin-top-header { padding: 12px 16px; min-height: 56px; flex-wrap: wrap; gap: 8px; }
            .header-left .brand-title { font-size: 0.95rem; }
            .profile-trigger-zone .admin-name { font-size: 0.75rem; max-width: 80px; }
            .admin-avatar-circle { width: 28px; height: 28px; }
            .admin-main { padding: 16px; }
            .admin-page-header { flex-direction: column; align-items: flex-start; }
            .admin-page-header h2 { font-size: 1.1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr 1fr; gap: 12px; }
            .metric-card-box { padding: 14px 16px; }
            .metric-card-box .metric-info .metric-val { font-size: 1.2rem; }
            .metric-card-box .metric-icon { width: 34px; height: 34px; font-size: 0.9rem; }
            .action-buttons { flex-direction: column; align-items: flex-start; gap: 4px; }
            th, td { padding: 10px 12px; font-size: 0.8rem; }
            .header-dropdown-card { right: 10px; top: 56px; width: 190px; }
        }

        @media (max-width: 576px) {
            .admin-sidebar { width: 60px; }
            .admin-container { margin-left: 60px; }
            .sidebar-header { padding: 12px 12px; min-height: 50px; }
            .sidebar-logo { height: 28px; }
            .sidebar-menu li a { padding: 10px 12px; }
            .sidebar-menu li a i { font-size: 1rem; }
            .admin-top-header { padding: 10px 12px; min-height: 50px; flex-direction: column; align-items: stretch; gap: 8px; }
            .header-left { flex-wrap: wrap; gap: 8px; justify-content: center; }
            .header-left .brand-title { font-size: 0.85rem; }
            .header-right { justify-content: center; }
            .profile-trigger-zone .admin-name { display: none; }
            .profile-trigger-zone .dropdown-arrow { display: none; }
            .profile-trigger-zone { padding: 3px 6px; background: rgba(255,255,255,0.15); border-left: none; }
            .admin-avatar-circle { width: 26px; height: 26px; }
            .admin-main { padding: 12px; }
            .admin-page-header h2 { font-size: 1rem; }
            .summary-dashboard-cards { grid-template-columns: 1fr; gap: 10px; }
            .metric-card-box { padding: 12px 14px; }
            .metric-card-box .metric-info .metric-val { font-size: 1.1rem; }
            .metric-card-box .metric-icon { width: 30px; height: 30px; font-size: 0.8rem; }
            .header-dropdown-card { right: 6px; top: 48px; width: 170px; }
        }
    </style>
</head>
<body>

<aside class="admin-sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.jpeg" alt="CareerConnect Logo" class="sidebar-logo">
        <span>CareerConnect</span>
    </div>
    <div class="sidebar-menu-container">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Overview</span></a></li>
            <li><a href="verify_orgs.php"><i class="fa-solid fa-user-shield"></i> <span>Verify Organizations</span></a></li>
            <li><a href="reset_requests.php" class="active"><i class="fa-solid fa-key"></i> <span>Password Resets</span></a></li>
            <li><a href="view_users.php"><i class="fa-solid fa-users-gear"></i> <span>View Users Hub</span></a></li>
            <li><a href="system_settings.php"><i class="fa-solid fa-sliders"></i> <span>System Settings</span></a></li>
            <li><a href="audit_logs.php"><i class="fa-solid fa-clock-rotate-left"></i> <span>Audit Metric Logs</span></a></li>
        </ul>
    </div>
</aside>

<div class="admin-container">
    <header class="admin-top-header">
        <div class="header-left">
            <div class="brand-title">
                <i class="fa-solid fa-key"></i> Account Access Gateway Resets
            </div>
        </div>
        
        <div class="header-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $admin_avatar; ?>" alt="Admin Avatar" class="admin-avatar-circle">
                <span class="admin-name"><?php echo $display_title; ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo $display_title; ?></h5>
                    <p>System Administrator</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="admin-main">
        <?php if (isset($_SESSION['reset_success'])): ?>
            <div class="success-message">
                <i class="fa-solid fa-circle-check"></i> <?php echo $_SESSION['reset_success']; unset($_SESSION['reset_success']); ?>
            </div>
        <?php endif; ?>

        <div class="admin-page-header">
            <h2><i class="fa-solid fa-key"></i> Awaiting Password Reset Triggers</h2>
        </div>

        <!-- Status Summary Cards -->
        <div class="summary-dashboard-cards">
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Active Requests</h5>
                    <div class="metric-val"><?php echo $active_count; ?></div>
                </div>
                <div class="metric-icon active">
                    <i class="fa-solid fa-clock"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Resolved</h5>
                    <div class="metric-val"><?php echo $resolved_count; ?></div>
                </div>
                <div class="metric-icon resolved">
                    <i class="fa-solid fa-circle-check"></i>
                </div>
            </div>
            <div class="metric-card-box">
                <div class="metric-info">
                    <h5>Total Requests</h5>
                    <div class="metric-val"><?php echo $total_count; ?></div>
                </div>
                <div class="metric-icon total">
                    <i class="fa-solid fa-list"></i>
                </div>
            </div>
        </div>

        <div class="data-table-card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Notification Details</th>
                            <th>Status Matrix</th>
                            <th>Administrative Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($requests)): ?>
                            <tr>
                                <td colspan="4">
                                    <div class="empty-state">
                                        <i class="fa-regular fa-circle-check"></i>
                                        <h4>No Active Password Reset Requests</h4>
                                        <p>All reset requests have been resolved.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            $counter = 1;
                            foreach($requests as $req): 
                            ?>
                                <tr>
                                    <td><strong>#<?php echo $counter++; ?></strong></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($req['message'] ?? 'Password reset request.'); ?></strong>
                                        <br>
                                        <small style="color:var(--muted-text); font-size:0.75rem;">
                                            <i class="fa-regular fa-clock"></i> 
                                            <?php echo date('M d, Y h:i A', strtotime($req['created_at'] ?? 'now')); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge badge-active">
                                            <i class="fa-solid fa-circle-exclamation"></i> Active
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="reset_requests.php?resolve=<?php echo $req['id']; ?>" class="btn-action btn-resolve" onclick="return confirm('Mark this request as resolved?')">
                                                <i class="fa-regular fa-circle-check"></i> Mark Resolved
                                            </a>
                                            <a href="reset_requests.php?delete=<?php echo $req['id']; ?>" class="btn-action btn-delete" onclick="return confirm('Delete this request permanently?')">
                                                <i class="fa-regular fa-trash-can"></i> Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});
</script>
</body>
</html>