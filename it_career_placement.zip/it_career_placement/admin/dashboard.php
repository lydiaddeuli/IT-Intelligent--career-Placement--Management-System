<?php
session_start();
include('../includes/db_connect.php'); 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];
$display_title = "System Admin";
$admin_avatar = "https://ui-avatars.com/api/?name=Admin&background=0091DF&color=fff";

// Safe Table Check & Asset Loading Mechanics
try {
    $check_col = $pdo->query("SHOW COLUMNS FROM users LIKE 'profile_pic'");
    $has_pic_col = $check_col->fetch();

    if ($has_pic_col) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_pic'])) {
            $target_dir = "../uploads/profile_pics/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            
            $file_extension = strtolower(pathinfo($_FILES["profile_pic"]["name"], PATHINFO_EXTENSION));
            $new_filename = "admin_" . $admin_id . "_" . time() . "." . $file_extension;
            $target_file = $target_dir . $new_filename;
            
            if (in_array($file_extension, ['jpg', 'jpeg', 'png'])) {
                if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
                    $db_path = "uploads/profile_pics/" . $new_filename;
                    $update_stmt = $pdo->prepare("UPDATE users SET profile_pic = ? WHERE user_id = ?");
                    $update_stmt->execute([$db_path, $admin_id]);
                    header("Location: dashboard.php?upload=success");
                    exit();
                }
            }
        }

        $admin_stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
        $admin_stmt->execute([$admin_id]);
        $admin_profile = $admin_stmt->fetch();

        if ($admin_profile) {
            if (isset($admin_profile['username'])) { $display_title = htmlspecialchars($admin_profile['username']); }
            elseif (isset($admin_profile['email'])) { $display_title = htmlspecialchars(explode('@', $admin_profile['email'])[0]); }
            
            if (!empty($admin_profile['profile_pic'])) { 
                $admin_avatar = "../" . $admin_profile['profile_pic']; 
            } else {
                $admin_avatar = "https://ui-avatars.com/api/?name=" . urlencode($display_title) . "&background=0091DF&color=fff";
            }
        }
    }
} catch (PDOException $e) {
    // Silent fallback
}

// System Counters Logic Block
$total_students = 0; $pending_orgs = 0; $active_orgs = 0; $pending_resets = 0;
try {
    $total_students = $pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
    $pending_orgs = $pdo->query("SELECT COUNT(*) FROM organizations WHERE verification_status='Pending'")->fetchColumn();
    $active_orgs = $pdo->query("SELECT COUNT(*) FROM organizations WHERE verification_status='Approved'")->fetchColumn();
    $pending_resets = $pdo->query("SELECT COUNT(*) FROM system_notifications WHERE is_resolved = 0")->fetchColumn();
} catch (PDOException $e) {
    // Handle gracefully
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Overview | Admin Workspace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      
            --softcare-light-blue: #E6F4FC;
            --aloe-green: #008543;
            --mustard-yellow: #F59E0B;     
            --dark-text: #1C2D42;          
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F9F9FB;           
            --border-light: #E2E8F0;
            --alert-red: #EF4444;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--cream-bg);
            display: flex;
            min-height: 100vh;
            color: var(--dark-text);
        }

        /* --- SIDEBAR WITH HEADER INTEGRATED --- */
        .admin-sidebar {
            width: 280px;
            background: var(--white);
            display: flex;
            flex-direction: column;
            border-right: 1px solid var(--border-light);
            position: fixed;
            height: 100vh;
            z-index: 100;
            top: 0;
            left: 0;
        }

        .sidebar-brand {
            padding: 20px 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.15rem;
            font-weight: 900;
            background: var(--softcare-blue);
            color: var(--white);
            letter-spacing: -0.5px;
            border-bottom: none;
        }

        .sidebar-brand img {
            height: 38px;
            width: auto;
            object-fit: contain;
            border-radius: 6px;
            border: 2px solid rgba(255,255,255,0.3);
            padding: 2px;
            background: var(--white);
        }

        .sidebar-brand span {
            color: var(--white);
        }

        .sidebar-menu-container {
            flex: 1;
            overflow-y: auto;
            padding: 10px 0;
            background: var(--white);
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li a {
            display: flex;
            align-items: center;
            gap: 14px;
            color: var(--dark-text);
            text-decoration: none;
            padding: 12px 24px;
            font-weight: 600;
            font-size: 0.9rem;
            transition: 0.2s;
        }

        .sidebar-menu li a i {
            width: 20px;
            text-align: center;
            font-size: 1rem;
            color: var(--muted-text);
        }

        .sidebar-menu li a:hover, 
        .sidebar-menu li a.active {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .sidebar-menu li a:hover i,
        .sidebar-menu li a.active i {
            color: var(--softcare-blue);
        }

        .sidebar-menu li a.active {
            border-left: 4px solid var(--softcare-blue);
            padding-left: 20px;
        }

        /* --- MAIN CONTAINER --- */
        .admin-container {
            margin-left: 280px;
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* --- TOP BAR - Integrated with sidebar --- */
        .admin-top-bar {
            background: var(--softcare-blue);
            padding: 14px 30px;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            min-height: 76px;
        }

        .top-bar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .profile-trigger-zone {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 4px 12px 4px 6px;
            border-radius: 50px;
            transition: 0.2s;
            user-select: none;
            background: rgba(255,255,255,0.1);
        }

        .profile-trigger-zone:hover {
            background: rgba(255,255,255,0.2);
        }

        .admin-avatar-circle {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255,255,255,0.6);
        }

        .profile-trigger-zone .admin-name {
            font-weight: 700;
            font-size: 0.9rem;
            color: var(--white);
        }

        .profile-trigger-zone .dropdown-arrow {
            color: rgba(255,255,255,0.6);
            font-size: 0.7rem;
        }

        /* --- PROFILE DROPDOWN --- */
        .header-dropdown-card {
            display: none;
            position: absolute;
            top: 68px;
            right: 30px;
            background: var(--white);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            width: 230px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            z-index: 1000;
            overflow: hidden;
        }

        .dropdown-user-info {
            padding: 16px 18px;
            background: var(--cream-bg);
            border-bottom: 1px solid var(--border-light);
            text-align: center;
        }

        .dropdown-user-info h5 {
            margin: 0;
            font-size: 0.92rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .dropdown-user-info p {
            margin: 2px 0 0 0;
            font-size: 0.72rem;
            color: var(--muted-text);
            text-transform: uppercase;
            font-weight: 700;
        }

        .dropdown-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dropdown-menu-list li a, 
        .dropdown-menu-list li button {
            width: 100%;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 18px;
            color: var(--dark-text);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            background: none;
            border: none;
            text-align: left;
            cursor: pointer;
            transition: 0.2s;
        }

        .dropdown-menu-list li a:hover, 
        .dropdown-menu-list li button:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .dropdown-menu-list li .logout-item {
            color: var(--alert-red);
            border-top: 1px solid var(--border-light);
        }

        .dropdown-menu-list li .logout-item:hover {
            background: #FEF2F2;
            color: #991B1B;
        }

        /* --- MAIN CONTENT --- */
        .admin-main {
            padding: 30px 35px;
            flex: 1;
            background: var(--cream-bg);
        }

        .page-header {
            margin-bottom: 28px;
        }

        .page-header h2 {
            margin: 0 0 4px 0;
            font-size: 1.4rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .page-header h2 i {
            color: var(--softcare-blue);
            margin-right: 10px;
        }

        .page-header p {
            margin: 0;
            color: var(--muted-text);
            font-size: 0.88rem;
        }

        .page-header p i {
            margin-right: 6px;
        }

        /* --- METRICS GRID --- */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
        }

        .metric-card {
            background: var(--white);
            padding: 16px 20px;
            border-radius: 12px;
            border: 1px solid var(--border-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
        }

        .metric-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        }

        .metric-card .metric-info h5 {
            margin: 0 0 2px 0;
            color: var(--muted-text);
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
        }

        .metric-card .metric-info .num {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--dark-text);
        }

        .metric-card .metric-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: var(--white);
            flex-shrink: 0;
        }

        .metric-card .metric-icon.blue { background: var(--softcare-blue); }
        .metric-card .metric-icon.yellow { background: var(--mustard-yellow); }
        .metric-card .metric-icon.green { background: var(--aloe-green); }
        .metric-card .metric-icon.red { background: var(--alert-red); }

        /* --- MODAL --- */
        .modal-backdrop {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.4);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        .modal-box {
            background: var(--white);
            padding: 28px 30px;
            border-radius: 12px;
            width: 400px;
            max-width: 92%;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            border-top: 4px solid var(--softcare-blue);
        }
        .modal-box h3 {
            margin: 0 0 12px 0;
            font-weight: 800;
            font-size: 1.1rem;
        }
        .modal-box h3 i {
            color: var(--softcare-blue);
            margin-right: 8px;
        }
        .file-input-wrapper {
            border: 2px dashed var(--border-light);
            padding: 18px;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 18px;
            cursor: pointer;
            transition: 0.2s;
        }
        .file-input-wrapper:hover {
            border-color: var(--softcare-blue);
            background: var(--softcare-light-blue);
        }
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .btn-panel {
            padding: 9px 18px;
            border-radius: 6px;
            font-weight: 700;
            border: none;
            cursor: pointer;
            font-size: 0.85rem;
            transition: 0.2s;
        }
        .btn-panel.cancel {
            background: var(--border-light);
            color: var(--dark-text);
        }
        .btn-panel.cancel:hover {
            background: #CBD5E0;
        }
        .btn-panel.save {
            background: var(--softcare-blue);
            color: white;
        }
        .btn-panel.save:hover {
            background: #0077B8;
        }

        /* ======================================== */
        /* ========== MOBILE VIEW ONLY ============ */
        /* ======================================== */

        @media (max-width: 1024px) {
            .metrics-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                width: 70px;
            }
            .admin-sidebar .sidebar-brand span {
                display: none;
            }
            .admin-sidebar .sidebar-brand {
                padding: 14px 16px;
                justify-content: center;
            }
            .admin-sidebar .sidebar-brand img {
                height: 34px;
                border: 2px solid rgba(255,255,255,0.4);
            }
            .admin-container {
                margin-left: 70px;
            }
            .sidebar-menu li a span {
                display: none;
            }
            .sidebar-menu li a {
                padding: 12px 16px;
                justify-content: center;
            }
            .sidebar-menu li a i {
                margin: 0;
                font-size: 1.2rem;
                color: var(--dark-text);
            }
            .sidebar-menu li a.active {
                padding-left: 16px;
                border-left: 3px solid var(--softcare-blue);
            }
            .admin-top-bar {
                padding: 10px 16px;
                min-height: 60px;
            }
            .profile-trigger-zone .admin-name {
                font-size: 0.8rem;
            }
            .admin-avatar-circle {
                width: 30px;
                height: 30px;
            }
            .admin-main {
                padding: 16px;
            }
            .page-header h2 {
                font-size: 1.1rem;
            }
            .page-header p {
                font-size: 0.8rem;
            }
            .header-dropdown-card {
                right: 10px;
                top: 58px;
                width: 200px;
            }
            .metrics-grid {
                grid-template-columns: 1fr 1fr;
                gap: 12px;
            }
            .metric-card {
                padding: 14px 16px;
            }
            .metric-card .metric-info h5 {
                font-size: 0.65rem;
            }
            .metric-card .metric-info .num {
                font-size: 1.3rem;
            }
            .metric-card .metric-icon {
                width: 34px;
                height: 34px;
                font-size: 0.9rem;
            }
        }

        @media (max-width: 480px) {
            .admin-sidebar {
                width: 60px;
            }
            .admin-sidebar .sidebar-brand {
                padding: 12px 12px;
            }
            .admin-sidebar .sidebar-brand img {
                height: 30px;
            }
            .admin-container {
                margin-left: 60px;
            }
            .sidebar-menu li a {
                padding: 10px 12px;
            }
            .sidebar-menu li a i {
                font-size: 1.1rem;
            }
            .admin-top-bar {
                padding: 8px 12px;
                min-height: 54px;
            }
            .profile-trigger-zone {
                padding: 3px 8px 3px 4px;
                background: rgba(255,255,255,0.15);
            }
            .profile-trigger-zone .admin-name {
                display: none;
            }
            .profile-trigger-zone .dropdown-arrow {
                display: none;
            }
            .admin-avatar-circle {
                width: 28px;
                height: 28px;
            }
            .admin-main {
                padding: 12px;
            }
            .page-header {
                margin-bottom: 16px;
            }
            .page-header h2 {
                font-size: 1rem;
            }
            .page-header h2 i {
                margin-right: 6px;
            }
            .page-header p {
                font-size: 0.75rem;
            }
            .metrics-grid {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
            }
            .metric-card {
                padding: 12px 14px;
                border-radius: 10px;
            }
            .metric-card .metric-info h5 {
                font-size: 0.6rem;
                letter-spacing: 0.3px;
            }
            .metric-card .metric-info .num {
                font-size: 1.2rem;
            }
            .metric-card .metric-icon {
                width: 30px;
                height: 30px;
                border-radius: 8px;
                font-size: 0.8rem;
            }
            .header-dropdown-card {
                right: 6px;
                top: 52px;
                width: 180px;
            }
            .dropdown-user-info h5 {
                font-size: 0.82rem;
            }
            .dropdown-menu-list li a, 
            .dropdown-menu-list li button {
                padding: 10px 14px;
                font-size: 0.8rem;
            }
            .modal-box {
                padding: 20px;
                width: 95%;
            }
            .modal-box h3 {
                font-size: 0.95rem;
            }
            .file-input-wrapper {
                padding: 14px;
            }
            .btn-panel {
                padding: 8px 14px;
                font-size: 0.8rem;
            }
        }

        @media (max-width: 400px) {
            .admin-sidebar {
                width: 50px;
            }
            .admin-container {
                margin-left: 50px;
            }
            .admin-sidebar .sidebar-brand img {
                height: 26px;
            }
            .sidebar-menu li a {
                padding: 8px 10px;
            }
            .sidebar-menu li a i {
                font-size: 1rem;
            }
            .metrics-grid {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }
            .metric-card {
                padding: 10px 12px;
            }
            .metric-card .metric-info .num {
                font-size: 1rem;
            }
            .metric-card .metric-icon {
                width: 26px;
                height: 26px;
                font-size: 0.7rem;
                border-radius: 6px;
            }
            .admin-top-bar {
                padding: 6px 10px;
                min-height: 48px;
            }
            .admin-avatar-circle {
                width: 24px;
                height: 24px;
            }
            .admin-main {
                padding: 10px;
            }
            .page-header h2 {
                font-size: 0.85rem;
            }
            .page-header p {
                font-size: 0.65rem;
            }
        }
    </style>
</head>
<body>

<div class="admin-sidebar">
    <div class="sidebar-brand">
        <img src="../images/logo.jpeg" alt="Logo" onerror="this.style.display='none';">
        <span>CareerConnect</span>
    </div>
    <div class="sidebar-menu-container">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="active"><i class="fa-solid fa-chart-pie"></i> <span>Dashboard Overview</span></a></li>
            <li><a href="verify_orgs.php"><i class="fa-solid fa-user-shield"></i> <span>Verify Organizations</span></a></li>
           
            <li><a href="reset_requests.php"><i class="fa-solid fa-key"></i> <span>Password Resets</span></a></li>
            <li><a href="view_users.php"><i class="fa-solid fa-users-gear"></i> <span>View Users Hub</span></a></li>
           
            <li><a href="system_settings.php"><i class="fa-solid fa-sliders"></i> <span>System Settings</span></a></li>
            <li><a href="audit_logs.php"><i class="fa-solid fa-clock-rotate-left"></i> <span>Audit Metric Logs</span></a></li>
        </ul>
    </div>
</div>

<div class="admin-container">
    <!-- TOP BAR - Integrated with sidebar -->
    <div class="admin-top-bar">
        <div class="top-bar-right">
            <div class="profile-trigger-zone" onclick="toggleDropdown(event)">
                <img src="<?php echo $admin_avatar; ?>" alt="Admin Avatar" class="admin-avatar-circle">
                <span class="admin-name"><?php echo $display_title; ?></span>
                <i class="fa-solid fa-angle-down dropdown-arrow"></i>
            </div>

            <div class="header-dropdown-card" id="profileDropdown">
                <div class="dropdown-user-info">
                    <h5><?php echo $display_title; ?></h5>
                    <p>System Administrator</p>
                </div>
                <ul class="dropdown-menu-list">
                    <li><button onclick="openSettingsModal()"><i class="fa-solid fa-camera"></i> Profile Settings</button></li>
                    <li><a href="../logout.php" class="logout-item"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="admin-main">
        <div class="page-header">
            <h2><i class="fa-solid fa-chart-pie"></i> Dashboard Overview</h2>
            <p><i class="fa-regular fa-calendar"></i> <?php echo date('l, F j, Y'); ?></p>
        </div>

        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-info">
                    <h5>Registered Students</h5>
                    <div class="num"><?php echo $total_students; ?></div>
                </div>
                <div class="metric-icon blue">
                    <i class="fa-solid fa-user-graduate"></i>
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-info">
                    <h5>Awaiting Verification</h5>
                    <div class="num"><?php echo $pending_orgs; ?></div>
                </div>
                <div class="metric-icon yellow">
                    <i class="fa-solid fa-hourglass-half"></i>
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-info">
                    <h5>Verified Partners</h5>
                    <div class="num"><?php echo $active_orgs; ?></div>
                </div>
                <div class="metric-icon green">
                    <i class="fa-solid fa-building-circle-check"></i>
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-info">
                    <h5>Password Resets</h5>
                    <div class="num"><?php echo $pending_resets; ?></div>
                </div>
                <div class="metric-icon red">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL -->
<div class="modal-backdrop" id="settingsModal">
    <div class="modal-box">
        <h3><i class="fa-solid fa-camera"></i> Update Profile Avatar</h3>
        <p style="color: var(--muted-text); font-size: 0.85rem; margin-bottom: 18px;">Upload a new photo to update your profile picture.</p>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="file-input-wrapper" onclick="document.getElementById('fileInput').click()">
                <i class="fa-solid fa-cloud-arrow-up" style="font-size: 1.8rem; color: var(--softcare-blue); margin-bottom: 6px; display: block;"></i>
                <span id="fileLabel" style="font-size: 0.85rem; font-weight:600;">Choose image file (.jpg, .png)</span>
                <input type="file" name="profile_pic" id="fileInput" accept="image/*" style="display:none;" onchange="updateLabel(this)">
            </div>
            <div class="modal-actions">
                <button type="button" class="btn-panel cancel" onclick="closeSettingsModal()">Cancel</button>
                <button type="submit" class="btn-panel save">Save Updates</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('profileDropdown');
    dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
}

document.addEventListener('click', function() {
    document.getElementById('profileDropdown').style.display = 'none';
});

function openSettingsModal() {
    document.getElementById('settingsModal').style.display = 'flex';
}
function closeSettingsModal() {
    document.getElementById('settingsModal').style.display = 'none';
}
function updateLabel(input) {
    if (input.files && input.files[0]) {
        document.getElementById('fileLabel').innerText = input.files[0].name;
    }
}
</script>
</body>
</html>