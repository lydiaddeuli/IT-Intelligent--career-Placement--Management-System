<?php
session_start();
include('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php"); 
    exit();
}

$msg = "";
if (isset($_GET['msg'])) { $msg = $_GET['msg']; }

// Determine active tab context safely (Default to student list view)
$current_tab = isset($_GET['tab']) ? $_GET['tab'] : 'student';

// --- LOGIC: RESET PASSWORD ---
if (isset($_GET['reset_id'])) {
    $new_pass = password_hash("123456", PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
    $stmt->execute([$new_pass, $_GET['reset_id']]);
    header("Location: users.php?tab=" . $current_tab . "&msg=Password reset to 123456 successfully!");
    exit();
}

// --- LOGIC: DELETE USER ---
if (isset($_GET['delete_id'])) {
    if ($_GET['delete_id'] != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->execute([$_GET['delete_id']]);
        header("Location: users.php?tab=" . $current_tab . "&msg=User account permanently deleted.");
        exit();
    }
}

// --- FETCH FILTERED USER GROUPS ---
if ($current_tab === 'company') {
    $stmt = $pdo->prepare("SELECT user_id, full_name, email, role, created_at FROM users WHERE role = 'company' ORDER BY full_name ASC");
} else {
    $stmt = $pdo->prepare("SELECT user_id, full_name, email, role, created_at FROM users WHERE role = 'student' ORDER BY full_name ASC");
}
$stmt->execute();
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF; --softcare-light-blue: #E6F4FC; --aloe-green: #008543;
            --mustard-yellow: #F59E0B; --dark-text: #1C2D42; --muted-text: #64748B;
            --white: #FFFFFF; --milky-white: #F9F9FB; --border-light: #E2E8F0;
            --pure-black: #000000; --alert-red: #EF4444;
        }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--white); display: flex; min-height: 100vh; color: var(--dark-text); }
        
        /* SIDEBAR SYSTEM MIGRATION - Matched to dashboard ecosystem */
        .sidebar { width: 280px; background: var(--milky-white); position: fixed; top: 0; bottom: 0; box-shadow: 1px 0 10px rgba(226, 230, 229, 0.05); z-index: 100; display: flex; flex-direction: column; border-right: 1px solid var(--border-light); }
        .sidebar-header { padding: 25px 20px; background: var(--white); display: flex; align-items: center; gap: 12px; font-weight: 900; font-size: 1.15rem; border-bottom: 2px solid var(--border-light); color: var(--dark-text); }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; flex: 1; }
        .sidebar-menu li a { display: flex; align-items: center; padding: 12px 24px; color: var(--pure-black); text-decoration: none; font-weight: 700; font-size: 0.95rem; }
        .sidebar-menu li a i { margin-right: 12px; width: 20px; text-align: center; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active-link { background: var(--softcare-light-blue); color: var(--softcare-blue); }
        .sidebar-menu li a.active-link { border-left: 4px solid var(--softcare-blue); }

        /* MAIN CONTENT AREA LAYOUT */
        .main-content { flex: 1; margin-left: 280px; padding: 30px 40px; box-sizing: border-box; }
        .app-header-bar { background: var(--softcare-blue); padding: 16px 24px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; border-radius: 12px; color: var(--white); }
        
        /* CONTENT CONTAINERS */
        .container { background: var(--white); padding: 30px; border-radius: 12px; border: 1px solid var(--border-light); }
        .container h2 { margin-top: 0; margin-bottom: 10px; color: var(--dark-text); font-weight: 800; font-size: 1.4rem; display: flex; align-items: center; gap: 10px; }
        
        /* TAB CONTROLLER NAVIGATION SYSTEM */
        .tab-navigation { display: flex; gap: 10px; margin: 25px 0 15px 0; border-bottom: 1px solid var(--border-light); padding-bottom: 12px; }
        .tab-btn { padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: 700; font-size: 0.9rem; transition: 0.2s; color: var(--dark-text); background: var(--milky-white); border: 1px solid var(--border-light); display: inline-flex; align-items: center; gap: 8px; }
        .tab-btn:hover { background: var(--softcare-light-blue); color: var(--softcare-blue); }
        .tab-btn.active-tab { background: var(--softcare-blue); color: var(--white); border-color: var(--softcare-blue); }

        /* RE-ENGINEERED STRUCTURAL USER TABLES */
        .user-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .user-table th { background: var(--milky-white); color: var(--dark-text); padding: 16px 20px; text-align: left; font-size: 0.9rem; font-weight: 700; border-bottom: 2px solid var(--border-light); }
        .user-table td { padding: 16px 20px; border-bottom: 1px solid var(--border-light); font-size: 0.95rem; color: var(--dark-text); vertical-align: middle; }
        .user-table tr:hover td { background: rgba(230, 244, 252, 0.2); }
        
        /* CLASS / ROLE COMPONENT PILLS */
        .role-badge { padding: 6px 14px; border-radius: 20px; font-size: 0.75rem; font-weight: bold; text-transform: uppercase; display: inline-flex; align-items: center; gap: 6px; }
        .role-company { background: var(--softcare-light-blue); color: var(--softcare-blue); border: 1px solid #bae6fd; }
        .role-student { background: #FEF3C7; color: #D97706; border: 1px solid #fef08a; }

        /* COMPACT INTERACTION DIRECTIVES GRID */
        .actions-cell { display: flex; gap: 8px; }
        .btn-action { display: inline-flex; align-items: center; gap: 6px; padding: 8px 14px; text-decoration: none; border-radius: 6px; font-weight: 700; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px; transition: 0.2s; border: none; cursor: pointer; }
        .btn-reset { background: var(--mustard-yellow); color: var(--white); }
        .btn-reset:hover { opacity: 0.9; }
        .btn-delete { background: var(--alert-red); color: var(--white); }
        .btn-delete:hover { opacity: 0.9; }
        
        /* ALERT BAR STRIP */
        .alert-box { padding: 15px 20px; border-radius: 8px; font-weight: 700; margin-bottom: 25px; font-size: 0.95rem; display: flex; align-items: center; gap: 10px; background: #DCFCE7; color: var(--aloe-green); border-left: 4px solid var(--aloe-green); }
        .empty-records-placeholder { text-align: center; color: var(--muted-text); padding: 40px !important; font-style: italic; }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header"><i class="fa-solid fa-screwdriver-wrench" style="color:var(--softcare-blue);"></i> System Admin</div>
    <ul class="sidebar-menu">
        <li><a href="dashboard.php"><i class="fa-solid fa-gauge-high"></i> Control Panel</a></li>
        <li><a href="users.php" class="active-link"><i class="fa-solid fa-users"></i> User Management</a></li>
        <li><a href="manage_organizations.php"><i class="fa-solid fa-building-circle-check"></i> Verify Companies</a></li>
        <li><a href="reset_requests.php"><i class="fa-solid fa-key"></i> Reset Requests</a></li>
        <li><a href="logs.php"><i class="fa-solid fa-clipboard-list"></i> System Logs</a></li> 
        <li><a href="reports.php"><i class="fa-solid fa-chart-pie"></i> System Reports</a></li>
        <li><a href="settings.php"><i class="fa-solid fa-gears"></i> System Settings</a></li>
    </ul>
</aside>

<main class="main-content">
    <header class="app-header-bar">
        <div class="header-title-left">Identity Access Layer Workbench</div>
        <div class="header-controls-right">
            <a href="dashboard.php" style="color: var(--white); text-decoration: none; font-weight: 700; font-size: 0.95rem;"><i class="fa-solid fa-arrow-left"></i> Workspace Control</a>
        </div>
    </header>

    <?php if($msg): ?>
        <div class="alert-box"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <div class="container">
        <h2><i class="fa-solid fa-users-gear" style="color: var(--softcare-blue);"></i> User Management Control</h2>
        <p style="color: var(--muted-text); margin: 0;">Monitor account creation parameters, update login safety credentials, or delete user listings.</p>
        
        <div class="tab-navigation">
            <a href="users.php?tab=student" class="tab-btn <?php echo ($current_tab === 'student') ? 'active-tab' : ''; ?>">
                <i class="fa-solid fa-user-graduate"></i> Student Registers
            </a>
            <a href="users.php?tab=company" class="tab-btn <?php echo ($current_tab === 'company') ? 'active-tab' : ''; ?>">
                <i class="fa-solid fa-building"></i> Corporate Registers
            </a>
        </div>

        <table class="user-table">
            <thead>
                <tr>
                    <th>Full Legal Name</th>
                    <th>Email Address String</th>
                    <th>Account Class</th>
                    <th style="width: 260px; text-align: left; padding-left: 20px;">Operational Directives</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $u): ?>
                <tr>
                    <td>
                        <strong style="color: var(--dark-text); font-size: 1.05rem; display: block;"><?php echo htmlspecialchars($u['full_name']); ?></strong>
                        <span style="color: var(--muted-text); font-size: 0.8rem;"><i class="fa-regular fa-clock"></i> Joined: <?php echo date("M d, Y", strtotime($u['created_at'])); ?></span>
                    </td>
                    <td><i class="fa-regular fa-envelope" style="color: var(--softcare-blue); margin-right: 5px;"></i> <?php echo htmlspecialchars($u['email']); ?></td>
                    <td>
                        <span class="role-badge role-<?php echo strtolower($u['role']); ?>">
                            <i class="fa-solid <?php echo ($u['role'] === 'company') ? 'fa-building' : 'fa-user-graduate'; ?>" style="font-size: 0.8rem;"></i>
                            <?php echo htmlspecialchars($u['role']); ?>
                        </span>
                    </td>
                    <td>
                        <div class="actions-cell">
                            <a href="?tab=<?php echo $current_tab; ?>&reset_id=<?php echo $u['user_id']; ?>" class="btn-action btn-reset" onclick="return confirm('Force password reset to \'123456\'?')">
                                <i class="fa-solid fa-key"></i> Reset Pass
                            </a>
                            <a href="?tab=<?php echo $current_tab; ?>&delete_id=<?php echo $u['user_id']; ?>" class="btn-action btn-delete" onclick="return confirm('Permanently delete this account profile?')">
                                <i class="fa-solid fa-trash-can"></i> Delete
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <?php if(empty($users)): ?>
                <tr>
                    <td colspan="4" class="empty-records-placeholder">
                        <i class="fa-solid fa-users-slash" style="font-size: 2.5rem; color: #cbd5e1; display: block; margin-bottom: 10px;"></i>
                        No users registered under this category yet.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

</body>
</html>