<?php
session_start();
include('includes/db_connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - IT Intelligent Career Placement System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            /* Softcare Package Palette Integration Matrix */
            --softcare-blue: #0091DF;      /* Primary Brand Blue */
            --softcare-light-blue: #E6F4FC;/* Accent fresh background tint */
            --aloe-green: #008543;         /* Natural highlight secure green */
            --mustard-yellow: #F59E0B;     /* Beautiful contrast highlight */
            --dark-text: #1C2D42;          /* Readable deep blue-grey text */
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           /* Ultra Clean background structure */
            --border-light: #E2E8F0;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, sans-serif; 
            background: var(--cream-bg); 
            color: var(--dark-text);
            display: flex; 
            flex-direction: column;
            min-height: 100vh;
        }

        /* --- HORIZONTAL HEADER NAVIGATION CONTROLLER --- */
        .global-header {
            background: var(--white);
            border-bottom: 3px solid var(--softcare-blue);
            box-shadow: 0 4px 20px rgba(0, 145, 223, 0.06);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 900;
            color: #000000; /* Solid Deep Black */
            text-decoration: none;
            letter-spacing: -0.5px;
        }

        .brand-logo-img {
            height: 80px;
            width: auto;
            object-fit: contain;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 15px;
        }

        .nav-menu li a {
            color: var(--dark-text);
            text-decoration: none;
            font-weight: 700;
            font-size: 0.95rem;
            padding: 10px 18px;
            border-radius: 8px;
            transition: 0.2s ease-in-out;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-menu li a:hover {
            background: var(--softcare-light-blue);
            color: var(--softcare-blue);
        }

        .nav-menu li a.active-link {
            background: var(--softcare-blue);
            color: var(--white);
        }

        /* Unified Portal Link Setup */
        .btn-login-nav {
            background: var(--softcare-blue) !important;
            color: var(--white) !important;
            border-bottom: 2px solid #00669e;
        }
        .btn-login-nav:hover {
            background: var(--dark-text) !important;
            color: var(--mustard-yellow) !important;
        }

        /* --- MAIN INTERFACE CONTENT WRAPPER --- */
        .main-container {
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            padding: 40px 25px;
            box-sizing: border-box;
            flex: 1;
        }

        /* About Subpage Mini Hero */
        .about-hero {
            text-align: center;
            padding: 60px 20px;
            margin-bottom: 40px;
            border-radius: 20px;
            background: linear-gradient(135deg, rgba(28, 45, 66, 0.9) 0%, rgba(0, 145, 223, 0.8) 100%), url('images/career.jpeg');
            background-size: cover;
            background-position: center;
            box-shadow: 0 10px 30px rgba(0, 145, 223, 0.1);
        }

        .about-hero h1 {
            color: var(--white);
            font-size: 2.8rem;
            font-weight: 900;
            margin: 0 0 10px 0;
            letter-spacing: -1px;
        }

        .about-hero p {
            color: var(--softcare-light-blue);
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto;
            font-weight: 500;
        }

        /* --- CONTENT CARDS GRID --- */
        .about-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }

        .info-card {
            background: var(--white);
            border-radius: 16px;
            padding: 35px;
            box-shadow: 0 10px 30px rgba(28, 45, 66, 0.03);
            border: 1px solid var(--border-light);
            transition: transform 0.2s;
        }

        .info-card:hover {
            transform: translateY(-5px);
            border-color: var(--softcare-blue);
        }

        .card-icon {
            font-size: 2.2rem;
            color: var(--softcare-blue);
            margin-bottom: 20px;
            display: inline-block;
        }

        .info-card h3 {
            font-size: 1.4rem;
            font-weight: 800;
            margin: 0 0 15px 0;
            color: var(--dark-text);
        }

        .info-card p {
            color: var(--muted-text);
            font-size: 0.95rem;
            line-height: 1.6;
            margin: 0;
        }

        /* Mission Statement Banner */
        .statement-box {
            background: var(--white);
            border-left: 5px solid var(--mustard-yellow);
            border-radius: 4px 16px 16px 4px;
            padding: 30px;
            margin-bottom: 40px;
            box-shadow: 0 10px 30px rgba(28, 45, 66, 0.02);
        }

        .statement-box h4 {
            margin: 0 0 10px 0;
            font-size: 1.2rem;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--softcare-blue);
            letter-spacing: 1px;
        }

        .statement-box p {
            margin: 0;
            font-size: 1.1rem;
            line-height: 1.6;
            color: var(--dark-text);
            font-style: italic;
        }

        /* --- SYSTEM UTILITY FOOTER --- */
        .system-footer {
            background: var(--dark-text);
            color: #94A3B8;
            padding: 50px 25px 30px 25px;
            border-top: 4px solid var(--mustard-yellow);
            margin-top: auto;
        }

        .footer-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            text-align: left;
        }

        .footer-column h5 {
            color: var(--white);
            font-size: 1.1rem;
            margin: 0 0 20px 0;
            font-weight: 700;
        }

        .footer-column p {
            font-size: 0.9rem;
            line-height: 1.6;
            margin: 0;
        }

        .footer-column p a.learn-more-link {
            color: var(--mustard-yellow);
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-left: 5px;
        }

        .footer-links-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links-list li {
            margin-bottom: 12px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-links-list li a {
            color: #94A3B8;
            text-decoration: none;
            transition: 0.2s;
        }

        .footer-links-list li a:hover {
            color: var(--mustard-yellow);
        }

        .footer-base {
            max-width: 1200px;
            margin: 40px auto 0 auto;
            border-top: 1px solid #334155;
            padding-top: 25px;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 600;
        }
    </style>
</head>
<body>

<header class="global-header">
    <div class="nav-container">
        <a href="index.php" class="brand-logo">
            <img src="images/logo.jpeg" alt="CareerConnect Logo" class="brand-logo-img"> CareerConnect
        </a>
        
        <ul class="nav-menu">
            <li><a href="index.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="index.php#vacancies-section"><i class="fa-solid fa-briefcase"></i> Vacancies</a></li>
            <li><a href="index.php#feedback-section"><i class="fa-solid fa-comments"></i> Feedback</a></li>
            
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php"><i class="fa-solid fa-power-off"></i> Sign Out</a></li>
            <?php else: ?>
                <li><a href="register.php"><i class="fa-solid fa-user-plus"></i> Join Us</a></li>
                <li><a href="login.php" class="btn-login-nav"><i class="fa-solid fa-right-to-bracket"></i> Account Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
</header>

<div class="main-container">
    <section class="about-hero">
        <h1>About CareerConnect</h1>
        <p>Empowering the next generation of IT professionals through automated database architecture integration.</p>
    </section>

    <div class="statement-box">
        <h4>Our Core Purpose</h4>
        <p>"To streamline the complex matching parameters of field study application processing, transforming manual vacancy hunting into an intelligent, seamless pipeline for institutions, corporations, and students."</p>
    </div>

    <section class="about-grid">
        <div class="info-card">
            <i class="fa-solid fa-graduation-cap card-icon"></i>
            <h3>For Students</h3>
            <p>Skip the paperwork. Complete your academic training placement protocols instantly by presenting verified structural IT profiles straight to approved companies searching for fresh talents.</p>
        </div>

        <div class="info-card">
            <i class="fa-solid fa-building-shield card-icon" style="color: var(--aloe-green);"></i>
            <h3>For Organizations</h3>
            <p>Access background-checked IT profiles and field applicants directly from authorized universities. Manage live slots, monitor application streams, and securely acquire competent tech assets.</p>
        </div>

        <div class="info-card">
            <i class="fa-solid fa-server card-icon" style="color: var(--mustard-yellow);"></i>
            <h3>Central System</h3>
            <p>Built over a secure Softcare architectural design matrix. Handles real-time verification parameters, rapid dynamic indexing, and zero-clutter coordination tables across Tanzania.</p>
        </div>
    </section>
</div>

<footer id="feedback-section" class="system-footer">
    <div class="footer-inner">
        <div class="footer-column">
            <h5>About Us</h5>
            <p>
                CareerConnect is a specialized platform designed to bridge the gap between brilliant IT students looking for field study positions and verified corporate organizations.
            </p>
        </div>
        <div class="footer-column">
            <h5>Get In Touch</h5>
            <ul class="footer-links-list">
                <li><i class="fa-solid fa-envelope" style="color: var(--softcare-blue);"></i> info@softcareplacement.co.tz</li>
                <li><i class="fa-solid fa-envelope" style="color: var(--softcare-blue);"></i> support@softcareplacement.co.tz</li>
                <li><i class="fa-solid fa-phone" style="color: var(--aloe-green);"></i> +255 712 345 678</li>
            </ul>
        </div>
        <div class="footer-column">
            <h5>Our Location</h5>
            <ul class="footer-links-list">
                <li><i class="fa-solid fa-map-location-dot" style="color: var(--mustard-yellow);"></i> Main Corporate Hub, 3rd Floor</li>
                <li>Dar es Salaam, Tanzania</li>
            </ul>
        </div>
        <div class="footer-column">
            <h5>Quick Portals</h5>
            <ul class="footer-links-list">
                <li><a href="login.php">Account Sign-In</a></li>
                <li><a href="register.php">Create Free Profile</a></li>
                <li><a href="index.php">Live Vacancy Board</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-base">
        <strong>&copy; This is my Mfumo. All Rights Reserved.</strong>
    </div>
</footer>

</body>
</html>