<?php
session_start();
include('includes/db_connect.php');

// Block access if they haven't bypassed the OTP verification screen
if (!isset($_SESSION['reset_user_id']) || !isset($_SESSION['otp_verified'])) {
    header("Location: forgot_password.php");
    exit();
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $user_id = $_SESSION['reset_user_id'];
    $notif_id = $_SESSION['active_notif_id'];

    if ($new_password !== $confirm_password) {
        $error = "Password confirmation failed. Entries must match identically.";
    } else {
        try {
            $pdo->beginTransaction();
            
            // 1. Securely encrypt the user's custom chosen password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $update->execute([$hashed_password, $user_id]);
            
            // 2. Mark the OTP request complete
            $resolve = $pdo->prepare("UPDATE system_notifications SET is_resolved = 1 WHERE id = ?");
            $resolve->execute([$notif_id]);
            
            $pdo->commit();
            
            // Clear configuration states completely
            session_unset();
            session_destroy();
            
            echo "<script>alert('Password updated cleanly! Sign in with your new custom credentials.'); window.location.href='login.php';</script>";
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "System exception encountered: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Establish New Password | CareerConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --softcare-blue: #0091DF;      /* Primary Corporate Blue */
            --softcare-light-blue: #E6F4FC;/* Clean Fresh Accent Tint */
            --mustard-yellow: #F59E0B;     /* Sharp Contrast Structural Border Color */
            --dark-text: #1C2D42;          /* Deep Slate Grey Text */
            --muted-text: #64748B;
            --white: #FFFFFF;
            --cream-bg: #F8FAFC;           /* Workspace Canvas Background */
            --border-light: #E2E8F0;
        }

        body { 
            margin: 0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--cream-bg); 
            display: flex; 
            flex-direction: column;
            min-height: 100vh;
            color: var(--dark-text);
        }
        
        /* --- NAVIGATION HEADER --- */
        .global-header {
            background: var(--white);
            border-bottom: 3px solid var(--softcare-blue);
            box-shadow: 0 4px 20px rgba(0, 145, 223, 0.06);
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
            box-sizing: border-box;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 900;
            color: #000000;
            text-decoration: none;
            letter-spacing: -0.5px;
        }

        .brand-logo-img {
            height: 80px;
            width: auto;
            object-fit: contain;
        }

        /* --- CARD WORKSPACE --- */
        .main-workspace {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 60px 20px;
            box-sizing: border-box;
        }
        
        .card { 
            background: var(--white); 
            width: 100%;
            max-width: 450px; 
            margin: auto; 
            border-radius: 16px; 
            box-shadow: 0 10px 30px rgba(28, 45, 66, 0.04); 
            overflow: hidden; 
            border-top: 6px solid var(--mustard-yellow); 
        }

        .card-header { 
            padding: 40px 40px 15px 40px; 
            background: var(--white); 
            text-align: center; 
        }

        .card-header h3 { 
            margin: 0; 
            color: var(--dark-text); 
            font-size: 1.6rem; 
            font-weight: 900; 
            letter-spacing: -0.5px;
            text-transform: uppercase;
        }

        .card-header span { 
            color: var(--softcare-blue); 
            font-weight: 800; 
            font-size: 0.85rem; 
            text-transform: uppercase; 
            letter-spacing: 1.5px; 
            display: block;
            margin-bottom: 8px;
        }

        .card-body { padding: 15px 40px 40px 40px; }

        .form-group { margin-bottom: 24px; position: relative; }

        .form-group > i.field-icon { 
            position: absolute; 
            left: 16px; 
            top: 44px; 
            color: var(--muted-text); 
            z-index: 5; 
            font-size: 1.05rem;
        }
        
        label { 
            display: block; 
            font-weight: 700; 
            margin-bottom: 9px; 
            color: var(--dark-text); 
            font-size: 0.85rem; 
            text-transform: uppercase; 
            letter-spacing: 0.3px;
        }

        input { 
            width: 100%; 
            padding: 14px 45px 14px 45px; 
            border: 2px solid var(--border-light); 
            border-radius: 8px; 
            box-sizing: border-box; 
            font-size: 1rem; 
            background: var(--cream-bg); 
            color: var(--dark-text); 
            transition: 0.2s ease-in-out;
        }

        input:focus { 
            border-color: var(--softcare-blue); 
            outline: none; 
            background: var(--white); 
            box-shadow: 0 0 0 4px rgba(0, 145, 223, 0.1);
        }

        .eye { 
            position: absolute; 
            right: 16px; 
            top: 44px; 
            cursor: pointer; 
            color: var(--muted-text); 
            z-index: 5;
            font-size: 1.05rem;
            transition: 0.2s;
        }
        
        .eye:hover {
            color: var(--softcare-blue);
        }

        button { 
            background: var(--softcare-blue); 
            color: var(--white); 
            border: none; 
            padding: 16px; 
            width: 100%; 
            border-radius: 8px; 
            font-weight: 800; 
            font-size: 1.05rem; 
            cursor: pointer; 
            transition: 0.2s ease-in-out; 
            margin-top: 10px; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
            box-shadow: 0 4px 12px rgba(0, 145, 223, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        button:hover { 
            background: var(--dark-text); 
            box-shadow: 0 4px 12px rgba(28, 45, 66, 0.2);
            color: var(--white);
        }

        .error-box { 
            background: #FFF5F5; 
            color: #E53E3E; 
            padding: 14px; 
            border-radius: 8px; 
            margin-bottom: 25px; 
            font-weight: 600; 
            border: 1px solid #FED7D7;
            border-left: 5px solid #E53E3E; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 0.9rem;
        }

        /* --- SYSTEM FOOTER --- */
        .system-footer {
            background: var(--dark-text);
            color: #94A3B8;
            padding: 40px 25px 30px 25px;
            border-top: 4px solid var(--mustard-yellow);
            width: 100%;
            box-sizing: border-box;
        }

        .footer-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
        }

        .footer-column h5 {
            color: var(--white);
            font-size: 1.1rem;
            margin: 0 0 15px 0;
            font-weight: 700;
        }

        .footer-column p {
            font-size: 0.9rem;
            line-height: 1.6;
            margin: 0;
        }

        .footer-base {
            max-width: 1200px;
            margin: 30px auto 0 auto;
            border-top: 1px solid #2E3E52;
            padding-top: 20px;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 600;
        }
    </style>
</head>
<body>

<header class="global-header">
    <div class="nav-container">
        <a href="index.php" class="brand-logo">
            <img src="images/logo.jpeg" alt="CareerConnect Logo" class="brand-logo-img"> CareerConnect
        </a>
    </div>
</header>

<div class="main-workspace">
    <div class="card">
        <div class="card-header">
            <span>Security Override Access</span>
            <h3>Reset Password</h3>
        </div>
        
        <div class="card-body">
            <p style="color: var(--muted-text); font-size: 0.95rem; text-align: center; margin-top: 0; margin-bottom: 25px;">
                Establish your custom administrative access phrase credentials below.
            </p>

            <?php if(!empty($error)): ?>
                <div class="error-box">
                    <i class="fa-solid fa-triangle-exclamation"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>New Strong Password</label>
                    <i class="fa-solid fa-lock field-icon"></i>
                    <input type="password" id="p1" name="new_password" required placeholder="••••••••">
                    <i class="fa-solid fa-eye eye" onclick="toggleField('p1', this)"></i>
                </div>

                <div class="form-group">
                    <label>Confirm New Password</label>
                    <i class="fa-solid fa-shield-check field-icon" style="top: 44px; left: 16px; position: absolute; color: var(--muted-text); z-index: 5;"></i>
                    <input type="password" id="p2" name="confirm_password" required placeholder="••••••••">
                    <i class="fa-solid fa-eye eye" onclick="toggleField('p2', this)"></i>
                </div>

                <button type="submit"><i class="fa-solid fa-key-skeleton"></i> Commit Security Update</button>
            </form>
        </div>
    </div>
</div>

<footer class="system-footer">
    <div class="footer-inner">
        <div class="footer-column">
            <h5>About CareerConnect</h5>
            <p>Our centralized management architecture handles seamless, automated verification parameters connecting academic talent directly with corporate structures.</p>
        </div>
        <div class="footer-column">
            <h5>Technical Desk Support</h5>
            <p>Encountering user access restrictions or database profile lockouts? Connect directly with support teams at info@softcareplacement.co.tz.</p>
        </div>
    </div>
    <div class="footer-base">
        &copy; 2026 Softcare Intelligent Career Placement System. All Rights Reserved.
    </div>
</footer>

<script>
    function toggleField(fieldId, icon) {
        const field = document.getElementById(fieldId);
        if (field.type === 'password') {
            field.type = 'text';
            icon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            field.type = 'password';
            icon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }
</script>
</body>
</html>