-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2026 at 03:20 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `career_placement_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `app_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `opportunity_id` int(11) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `referee_name` varchar(255) DEFAULT NULL,
  `referee_email` varchar(255) DEFAULT NULL,
  `referee_designation` varchar(255) DEFAULT NULL,
  `cover_letter` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`app_id`, `student_id`, `opportunity_id`, `status`, `applied_at`, `referee_name`, `referee_email`, `referee_designation`, `cover_letter`) VALUES
(5, 24, 7, '', '2026-06-30 04:22:12', NULL, NULL, NULL, 'dxgncfhmjb,n'),
(6, 24, 4, '', '2026-06-30 04:32:50', NULL, NULL, NULL, 'szdgdxgfhjk'),
(7, 24, 7, '', '2026-06-30 04:42:45', NULL, NULL, NULL, 'zsgsdxfcghvjb,kn.kmk,.\r\n'),
(8, 24, 4, '', '2026-06-30 04:43:03', NULL, NULL, NULL, 'vvvv'),
(9, 37, 7, '', '2026-07-01 02:10:02', NULL, NULL, NULL, 'ddfghjbk'),
(10, 37, 7, '', '2026-07-01 02:14:54', NULL, NULL, NULL, 'ddfghjbk'),
(11, 37, 7, '', '2026-07-01 02:15:14', NULL, NULL, NULL, 'dfhgjb'),
(12, 37, 7, '', '2026-07-01 02:16:37', NULL, NULL, NULL, 'xddfcgvh'),
(13, 37, 7, '', '2026-07-01 02:18:14', NULL, NULL, NULL, 'zddxgfchjj'),
(14, 37, 7, '', '2026-07-01 02:18:26', NULL, NULL, NULL, 'dxgfhgvj'),
(15, 37, 7, '', '2026-07-01 02:23:14', NULL, NULL, NULL, 'dfghjk'),
(16, 40, 7, '', '2026-07-06 11:22:59', NULL, NULL, NULL, 'werjt.vhj,hgnmf,c h  jmnd'),
(17, 40, 4, '', '2026-07-06 12:12:04', NULL, NULL, NULL, 'esdrtfgyh'),
(18, 44, 13, '', '2026-08-05 11:47:13', NULL, NULL, NULL, 'rtyguhjreftygui\'imnhu,yxrck'),
(19, 45, 13, '', '2026-08-06 18:44:15', NULL, NULL, NULL, 'Dear Hiring Manager,\r\n\r\nI am writing to express my interest in the Assistant Network Engineer position. I hold a background in Computer Science and have knowledge of computer networking, network troubleshooting, system administration, and IT support. I am eager to apply my technical skills, learn from experienced professionals, and contribute to the success of your organization. I am a hardworking, quick learner, and committed to delivering quality work.\r\nThank you for considering my application. I look forward to the opportunity to discuss my qualifications with you.\r\nYours sincerely,\r\nInesta Baraka Mwayaya'),
(20, 52, 14, '', '2026-08-07 16:28:16', NULL, NULL, NULL, '\r\n\r\nMercan T. Ates\r\nDar es Salaam, Tanzania\r\n0765490952\r\n[mercan@gmail.com](mailto:mercan@gmail.com)\r\n\r\n**Date:** 6 August 2026\r\n\r\nDear Hiring Manager,\r\n\r\nI am writing to apply for an internship position in your organization. I am a Computer Science graduate who is eager to gain practical experience and improve my technical skills.\r\n\r\nI am hardworking, willing to learn, and able to work well both independently and as part of a team. I believe this internship will help me grow professionally while allowing me to contribute positively to your organization.\r\n\r\nThank you for considering my application. I look forward to the opportunity to discuss my qualifications with you.\r\n\r\nYours faithfully,\r\n\r\nMercan T. Ates\r\n'),
(21, 45, 16, '', '2026-08-07 19:23:43', NULL, NULL, NULL, 'i want this job '),
(22, 45, 15, '', '2026-08-07 23:07:44', NULL, NULL, NULL, 'nataka nije');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `reg_number` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company_opportunities`
--

CREATE TABLE `company_opportunities` (
  `opp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company_opportunity`
--

CREATE TABLE `company_opportunity` (
  `opp_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `opportunity_type` enum('Internship','Field Study') NOT NULL DEFAULT 'Internship',
  `deadline` date NOT NULL,
  `slots_available` int(11) NOT NULL DEFAULT 1,
  `min_gpa` decimal(3,2) NOT NULL DEFAULT 0.00,
  `skills_required` text DEFAULT NULL,
  `responsibilities` text DEFAULT NULL,
  `status` enum('Open','Closed') NOT NULL DEFAULT 'Open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_opportunity`
--

INSERT INTO `company_opportunity` (`opp_id`, `title`, `company_name`, `opportunity_type`, `deadline`, `slots_available`, `min_gpa`, `skills_required`, `responsibilities`, `status`, `created_at`) VALUES
(1, 'Junior Database Administrator Trainee', 'TTCL Corporation', 'Internship', '2026-07-17', 5, 3.00, 'SQL Basics, Database Design, Linux Shell, Data Warehousing', '• Monitor local server node synchronization metrics daily.\n• Run backup script validations and log administrative exceptions.\n• Assist senior backend engineers with relational schema updates.', 'Open', '2026-06-18 00:47:36'),
(2, 'Telecommunication & Network Operations Assistant', 'TCRA (Tanzania Communications Regulatory Authority)', 'Field Study', '2026-07-02', 2, 3.50, 'Python Basics, Critical Thinking, Computer Networks, Routing Protocols', '• Analyze institutional framework data traffic arrays.\n• Prepare field performance summaries for compliance management tools.\n• Participate in live infrastructure mapping operations.', 'Open', '2026-06-18 00:47:36');

-- --------------------------------------------------------

--
-- Table structure for table `company_profiles`
--

CREATE TABLE `company_profiles` (
  `company_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `year_established` int(11) DEFAULT NULL,
  `company_size` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `social_links` text DEFAULT NULL,
  `intern_benefits` text DEFAULT NULL,
  `about` text DEFAULT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `license_path` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `rejection_reason` text DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_profiles`
--

INSERT INTO `company_profiles` (`company_id`, `name`, `year_established`, `company_size`, `location`, `contact_person`, `website`, `social_links`, `intern_benefits`, `about`, `logo_path`, `license_path`, `status`, `rejection_reason`, `profile_pic`) VALUES
(26, 'nmb', 2000, '123', 'Morogoro ', '0786565509', 'https://www.ttcl.co.tz', 'dgfhjkl;\'fghjkh.lghjbknlm', 'etrytfuyfglihujkghjv,bk', 'zdxfcgvjhkbj.nlhbjn', '', '', 'Pending', NULL, NULL),
(36, 'Airtel', 2000, '50', 'Arusha,Tanzania', '0616565509', 'https://www.Airtelco.tz', 'https://www.linkedin.com/airtel', '', '', '', '', 'Pending', NULL, NULL),
(43, 'TACL', 2010, '20', 'Morogoro, Kilosa', '0786565509', 'https://ttclAsystem', 'https://www.linkedin.com/ttacl', '1. Gained practical experience in network installation, configuration, maintenance, and troubleshooting.\r\nImproved technical, communication, teamwork, and problem-solving skills by working with network engineers.\r\n\r\n2.Developed professional work experience and gained knowledge of industry practices, preparing for a career in network engineering.', 'TTACL is an organization that provides communication and networking services. The company is involved in the installation, maintenance, monitoring, and support of network infrastructure to ensure reliable communication services. It offers students an opportunity to gain practical experience by working with network engineers and learning about real-world networking technologies and operations.', 'uploads/logos/passport_120x150.jpg', '', 'Pending', NULL, 'uploads/company_logos/company_43_1785840400.jpg'),
(47, 'CRDB Bank Plc', 1997, '50', 'Dar es Salaam, Kinondoni', '0786578630', 'https://www.crddb.tz', 'https://www.linkedin.com/crdbbank', '1.Gain practical experience in banking operations and financial services.\r\n2.Develop customer service, communication, and problem-solving skills.\r\n3.Learn professional workplace practices and digital banking technologies.', 'CRDB Bank Plc is one of the largest commercial banks in Tanzania. It provides banking and financial services such as savings accounts, loans, digital banking, investment services, and business financing to individuals, businesses, and organizations.', NULL, NULL, 'Pending', NULL, ''),
(48, 'Tanzania Breweries Limited (TBL)', 2005, '30', 'Mwanza, Geita', '0623456780', 'https://www.TBL.co.tz', 'https://www.linkedin.com/tbl', 'Gain practical experience in manufacturing and business operations.\r\nDevelop technical, teamwork, and analytical skills.', 'Tanzania Breweries Limited (TBL) is one of the leading beverage manufacturing companies in Tanzania. It produces and distributes a wide range of alcoholic and non-alcoholic beverages and operates modern manufacturing plants across the country.', NULL, NULL, 'Pending', NULL, ''),
(49, 'Tanzania Electric Supply Company Limited', 2000, '20', 'Mbeya, Mbeya City', '0786565509', 'https://www.tanesco.co.tz/', 'https://www.linkedin.com/tanesco', '1.Gain practical experience in electrical power systems and utility operations.\r\n2.Develop technical and problem-solving skills by working with experienced engineers and ICT professionals.\r\n3.Learn workplace professionalism, teamwork, and safety practices in the energy sector.', 'Tanzania Electric Supply Company Limited (TANESCO) is a government-owned electricity utility in Tanzania. It is responsible for generating, transmitting, distributing, and selling electricity across mainland Tanzania. The company plays a major role in supporting economic growth by providing reliable and affordable electricity to homes, industries, businesses, and public institutions.', NULL, NULL, 'Pending', NULL, 'uploads/company_logos/company_49_1786118344.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `app_id` int(11) NOT NULL,
  `opportunity_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `status` enum('Pending','Accepted','Rejected') DEFAULT 'Pending',
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `sender_role` enum('student','coordinator','company') NOT NULL,
  `message_text` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `sender_role`, `message_text`, `created_at`) VALUES
(1, 24, 1, 'student', 'hello admin', '2026-06-30 08:42:07');

-- --------------------------------------------------------

--
-- Table structure for table `opportunities`
--

CREATE TABLE `opportunities` (
  `opp_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` enum('Internship','Field Study') NOT NULL,
  `requirements` text NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `closing_date` date NOT NULL,
  `slots` int(11) NOT NULL DEFAULT 1,
  `required_gpa` decimal(3,2) NOT NULL DEFAULT 0.00,
  `core_responsibilities` text NOT NULL,
  `department` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `required_skills` text DEFAULT NULL,
  `status` enum('draft','published','blocked') DEFAULT 'draft'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `opportunities`
--

INSERT INTO `opportunities` (`opp_id`, `company_id`, `title`, `type`, `requirements`, `description`, `created_at`, `closing_date`, `slots`, `required_gpa`, `core_responsibilities`, `department`, `location`, `required_skills`, `status`) VALUES
(4, 26, 'network assisant', 'Internship', 'esrjftkghj', '', '2026-06-29 19:37:41', '2026-07-10', 1, 3.40, 'sdyfyghjk', NULL, NULL, NULL, 'draft'),
(7, 26, 'SOFTWARE ENGINNERR', 'Internship', 'HJKL\r\nFGHJ', 'ffchgvjbkn', '2026-06-29 20:20:43', '2026-07-10', 3, 4.00, 'GHVJBNL/KM\r\nFGHJK\r\nXFCHGJ', '', '', 'dxddfgjhkl', 'draft'),
(11, 39, 'fghjkl', 'Internship', 'tdofyguhnmkl', '', '2026-07-04 09:11:01', '2026-07-07', 5, 4.00, 'kml,;;lnklbjkn.mmlbj', NULL, NULL, NULL, 'draft'),
(13, 43, 'Assistant network lecturer', 'Internship', '1.Bachelor\'s degree or Diploma in Computer Science, Information Technology, Network Engineering, or a related field.\r\n2.Basic knowledge of computer networking concepts and operating systems.\r\n3.Ability to work independently and as part of a team.\r\n\r\nRequired Technical Skills\r\n.Network installation and configuration\r\n.Network troubleshooting\r\n.TCP/IP networking\r\n.Router and switch', '', '2026-08-04 12:25:58', '2026-08-22', 7, 3.50, '1.Assisted in installing, configuring, and maintaining computer network devices and equipment.\r\n\r\n2.Monitored network performance and helped troubleshoot network connectivity issues.\r\n\r\n3.Provided technical support to users and assisted in maintaining network security and system documentation.', NULL, NULL, NULL, 'published'),
(14, 43, 'IT Support Technician', 'Internship', 'Diploma or Bachelor\'s degree in Computer Science, Information Technology, or a related field.\r\nBasic knowledge of computer systems and networking.\r\nGood communication and teamwork skills.\r\nAbility to solve technical problems effectively.\r\n\r\nRequired Technical Skills\r\n1.Computer hardware maintenance\r\n2.Windows and Linux operating systems\r\n3.Network troubleshooting\r\n4.TCP/IP networking', '', '2026-08-06 18:36:48', '2026-08-15', 3, 4.00, '1.Install, configure, and maintain computer hardware and software.\r\n2.Troubleshoot hardware, software, and network issues.\r\n3.Provide technical support to staff and users.\r\n4.Perform system updates and regular maintenance.\r\n5.Maintain IT equipment and system documentation.', NULL, NULL, NULL, 'published'),
(15, 49, 'Network Support Intern', 'Field Study', 'Bachelor\'s student or graduate in Computer Science, Information Technology, or Computer Engineering.\r\nMinimum GPA: 3.00\r\nBasic knowledge of TCP/IP, LAN/WAN, routers, and switches.\r\nFamiliarity with Windows and Linux operating systems.\r\nGood analytical and teamwork skills.', '', '2026-08-07 18:53:28', '2026-08-22', 10, 3.00, '1.Assist in configuring and maintaining network devices.\r\n2.Monitor network performance and connectivity.\r\n3.Troubleshoot basic network issues.\r\n4.Support network documentation and reporting.', NULL, NULL, NULL, 'published'),
(16, 49, 'Systems Administrator Intern', 'Internship', 'Bachelor\'s student or graduate in Computer Science, Information Technology, or a related field.\r\nMinimum GPA: 3.8\r\nBasic knowledge of Windows Server or Linux.\r\nFamiliarity with Active Directory, networking, and system troubleshooting.\r\nStrong communication and problem-solving skills.', '', '2026-08-07 19:20:00', '2026-08-28', 5, 3.50, '1.Assist in maintaining computer systems and servers.\r\n2.Support user account management.\r\n3.Install and update software applications.\r\n4.Monitor system performance and perform routine maintenance', NULL, NULL, NULL, 'published');

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `org_id` int(11) NOT NULL,
  `org_name` varchar(150) NOT NULL,
  `industry` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `reg_number` varchar(100) NOT NULL,
  `tin_number` varchar(100) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `verification_documents` varchar(255) NOT NULL,
  `verification_status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `rejection_reason` text DEFAULT NULL,
  `has_fees` enum('None','Registration Only','Direct Cost Only','Both') DEFAULT 'None',
  `fee_amounts_json` varchar(255) DEFAULT NULL,
  `fee_reason` text DEFAULT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `allow_interns` tinyint(1) DEFAULT 1,
  `allow_field_study` tinyint(1) DEFAULT 1,
  `qualification_rules` text DEFAULT NULL,
  `selection_limit` int(11) DEFAULT 10,
  `application_deadline` date DEFAULT NULL,
  `company_website` varchar(255) DEFAULT NULL,
  `payment_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`org_id`, `org_name`, `industry`, `location`, `contact_email`, `reg_number`, `tin_number`, `website`, `verification_documents`, `verification_status`, `rejection_reason`, `has_fees`, `fee_amounts_json`, `fee_reason`, `registered_at`, `allow_interns`, `allow_field_study`, `qualification_rules`, `selection_limit`, `application_deadline`, `company_website`, `payment_description`) VALUES
(41, 'ARDHI UNIVERSITY', 'UNIVERSITY', 'Dar es Salaam, Ubungo', 'aru@gmail.com', '1238971', '1024567', 'https://arucasystem', 'uploads/company_verifications/verify_41_1785764002.pdf', 'Approved', NULL, 'None', '{\"registration_fee\":0,\"direct_field_cost\":0}', '', '2026-08-03 13:33:22', 1, 1, NULL, 10, NULL, NULL, NULL),
(43, 'TACL', 'Telecommunications', 'Morogoro, Kilosa', 'ttacl@gmail.com', '3456789', '987654334', 'https://ttclAsystem', 'uploads/company_verifications/verify_43_1785768984.pdf', 'Approved', NULL, 'Both', '{\"registration_fee\":455667,\"direct_field_cost\":344556}', 'ni hatuna hela', '2026-08-03 14:56:24', 1, 1, NULL, 10, NULL, NULL, NULL),
(47, 'CRDB Bank Plc', 'Telecomunication', 'Dar es Salaam, Kinondoni', 'recruitment@crdbbank.co.tz', '4567123', '4587906544556', 'https://www.crddb.tz', 'uploads/company_verifications/verify_47_1786117371.pdf', 'Approved', NULL, 'None', '{\"registration_fee\":0,\"direct_field_cost\":0}', '', '2026-08-07 15:42:51', 1, 1, NULL, 10, NULL, NULL, NULL),
(48, 'Tanzania Breweries Limited (TBL)', 'Manufacturing', 'Mwanza, Geita', 'recruitment@tbl.co.tz', '345678967', '345678O9897', 'https://www.TBL.co.tz', 'uploads/compliance_docs/org_48_fix_1786124363.pdf', 'Approved', NULL, 'None', '{\"registration_fee\":0,\"direct_field_cost\":0}', '', '2026-08-07 15:47:30', 1, 1, NULL, 10, NULL, 'https://www.TBL.co.tz/', 'they must pay'),
(49, 'Tanzania Electric Supply Company Limited', 'Energy and Utilities', 'Mbeya, Mbeya City', 'recruitment@tanesco.co.tz', '789012-G', '707-808-909', 'https://www.tanesco.co.tz/', 'uploads/compliance_docs/org_49_fix_1786124195.pdf', 'Approved', NULL, 'None', '{\"registration_fee\":0,\"direct_field_cost\":0}', '', '2026-08-07 15:53:56', 1, 1, NULL, 10, NULL, '', 'dfghjk');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('Pending','Resolved','Dismissed') DEFAULT 'Pending',
  `resolved_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `referee_recommendations`
--

CREATE TABLE `referee_recommendations` (
  `id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `secure_token` varchar(64) NOT NULL,
  `recommendation_text` text DEFAULT NULL,
  `rating` varchar(50) DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_docs`
--

CREATE TABLE `student_docs` (
  `doc_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `cv_path` varchar(255) DEFAULT NULL,
  `letter_path` varchar(255) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `certificate_path` varchar(255) DEFAULT NULL,
  `birth_certificate_path` varchar(255) DEFAULT NULL,
  `national_id_path` varchar(255) DEFAULT NULL,
  `recommendation_letter_path` varchar(255) DEFAULT NULL,
  `transcript_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_docs`
--

INSERT INTO `student_docs` (`doc_id`, `student_id`, `cv_path`, `letter_path`, `uploaded_at`, `certificate_path`, `birth_certificate_path`, `national_id_path`, `recommendation_letter_path`, `transcript_path`) VALUES
(1, 23, '../uploads/CV_23_1779934406.pdf', NULL, '2026-05-28 02:13:26', NULL, NULL, NULL, NULL, NULL),
(2, 37, '../uploads/CV_37_1782867586.docx', '../uploads/LETTER_37_1782867586.pdf', '2026-07-01 00:59:46', NULL, NULL, NULL, NULL, NULL),
(3, 40, '../uploads/CV_40_1783336380.pdf', '../uploads/LETTER_40_1783336380.pdf', '2026-07-06 11:13:00', NULL, NULL, NULL, NULL, NULL),
(4, 44, 'uploads/student_docs/cv/CV_44_1785855089.pdf', NULL, '2026-08-04 14:51:29', NULL, NULL, NULL, NULL, NULL),
(5, 45, NULL, NULL, '2026-08-06 16:02:18', 'uploads/student_docs/certificate/CERTIFICATE_45_1786032369.pdf', 'uploads/student_docs/birth_certificate/BIRTH_CERTIFICATE_45_1786032138.pdf', 'uploads/student_docs/national_id/NATIONAL_ID_45_1786032369.pdf', 'uploads/student_docs/recommendation_letter/RECOMMENDATION_LETTER_45_1786032369.docx', 'uploads/student_docs/transcript/TRANSCRIPT_45_1786032369.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `student_logbooks`
--

CREATE TABLE `student_logbooks` (
  `log_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `week_number` int(11) NOT NULL,
  `activities_done` text NOT NULL,
  `lessons_learned` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_notifications`
--

CREATE TABLE `student_notifications` (
  `notif_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_notifications`
--

INSERT INTO `student_notifications` (`notif_id`, `student_id`, `title`, `message`, `is_read`, `created_at`) VALUES
(3, 44, 'Application Accepted! ????', 'Congratulations! Your application for \'Assistant network lecturer\' has been accepted by the company. Please confirm your acceptance to proceed.', 0, '2026-08-05 13:25:04'),
(4, 45, 'Application Accepted! ????', 'Congratulations! Your application for \'Assistant network lecturer\' has been accepted by the company. Please confirm your acceptance to proceed.', 0, '2026-08-06 18:46:37'),
(5, 52, 'Application Accepted! ????', 'Congratulations! Your application for \'IT Support Technician\' has been accepted by the company. Please confirm your acceptance to proceed.', 0, '2026-08-07 18:25:15'),
(6, 45, 'Application Accepted! ????', 'Congratulations! Your application for \'Systems Administrator Intern\' has been accepted by the company. Please confirm your acceptance to proceed.', 0, '2026-08-07 21:52:48'),
(7, 45, 'Application Accepted! ????', 'Congratulations! Your application for \'Network Support Intern\' has been accepted by the company. Please confirm your acceptance to proceed.', 0, '2026-08-07 23:08:23');

-- --------------------------------------------------------

--
-- Table structure for table `student_profiles`
--

CREATE TABLE `student_profiles` (
  `profile_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `placement_type` enum('Internship','Field Study') NOT NULL,
  `skills` text DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `cv_path` varchar(255) DEFAULT NULL,
  `transcript_path` varchar(255) DEFAULT NULL,
  `intro_letter_path` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `education_history` text DEFAULT NULL,
  `work_experience` text DEFAULT NULL,
  `cv_verification_status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `cv_rejection_reason` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `grad_year` int(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT 0.00,
  `profile_pic` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `nida_number` varchar(50) DEFAULT NULL,
  `disability` varchar(50) DEFAULT NULL,
  `physical_address` varchar(255) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `course_program` varchar(255) DEFAULT NULL,
  `year_of_study` varchar(10) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `physical_address_full` text DEFAULT NULL,
  `technical_skills` text DEFAULT NULL,
  `soft_skills` text DEFAULT NULL,
  `experience` text DEFAULT NULL,
  `languages` varchar(100) DEFAULT NULL,
  `awards` varchar(255) DEFAULT NULL,
  `certifications` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `education` text DEFAULT NULL,
  `projects` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_profiles`
--

INSERT INTO `student_profiles` (`profile_id`, `student_id`, `placement_type`, `skills`, `bio`, `cv_path`, `transcript_path`, `intro_letter_path`, `phone_number`, `education_history`, `work_experience`, `cv_verification_status`, `cv_rejection_reason`, `phone`, `gender`, `nationality`, `course`, `grad_year`, `dob`, `gpa`, `profile_pic`, `date_of_birth`, `nida_number`, `disability`, `physical_address`, `district`, `region`, `course_program`, `year_of_study`, `religion`, `physical_address_full`, `technical_skills`, `soft_skills`, `experience`, `languages`, `awards`, `certifications`, `address`, `summary`, `education`, `projects`) VALUES
(3, 8, 'Field Study', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 19, 'Field Study', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 23, 'Internship', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 24, 'Internship', 'elecrtical engineer', 'i love this job', '../uploads/cvs/CV_STUDENT_24_1781036248.pdf', NULL, NULL, '0786565509', 'bachelor of electrical engineer', 'elertonics', 'Pending', NULL, '078886565509', 'Female', 'Tanzania', 'bachelor of computer system and network', 2026, '2003-12-16', 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 37, 'Field Study', 'Full-Stack Web Development (React, Node.js, and PostgreSQL)', 'Aspiring Computer Science student with a strong foundation in algorithmic problem-solving and full-stack development, dedicated to building scalable, user-centric applications through clean, efficient code.', '../uploads/cvs/CV_STUDENT_37_1782869816.pdf', NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, '34567890234567890567', 'Male', 'Tanzania', 'bachelor of computer sciences', 2024, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 38, 'Internship', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, '../uploads/avatars/avatar_38_1783171365.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 40, 'Internship', 'AXFGHJKL;O', 'AQSDFRGTHYUIO9', '../uploads/cvs/CV_STUDENT_40_1783336892.pdf', NULL, NULL, '0758450414', 'bachelor of  science in computer enginerr', 'FGHVBJNMK', 'Pending', NULL, '0758450414', 'Male', 'Tanzania', 'bachelor of  science in computer enginerr', NULL, '2026-07-07', 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 44, 'Internship', NULL, NULL, '../uploads/cvs/CV_STUDENT_44_1785930368.pdf', NULL, NULL, '0686410804', NULL, NULL, 'Pending', NULL, '0765490952', 'Male', NULL, NULL, NULL, NULL, 0.00, '../uploads/avatars/avatar_44_1785852837.jpg', '2003-02-14', '2003021425668899', 'None', 'P.O BOX 145', 'KILOSA', 'MOROGORO', 'BACHELOR OF ACCOUNT AND COMPUTER', '3', 'CHRISTIAN', 'KILOSA', '• Git & GitHub\r\n• Visual Studio Code\r\n• Linux', '• Critical Thinking\r\n• Adaptability\r\n• Creativity', 'Student Software Developer\r\n2023 – Present\r\n• Developed web applications\r\n• Built databases', 'English', 'freeCodeCamp Responsive Web Design', '', '', 'Motivated Computer Science student with a strong interest in software development, database management, networking, and cybersecurity. Skilled in building web applications, solving technical problems, and working collaboratively in team environments. Passionate about learning new technologies and applying them to develop innovative and efficient solutions.', 'Bachelor of Science in Account and Computer\r\nUniversity of Dar es Salaam\r\n2022 – Present', '• Internship Placement Management System\r\n• Student Record Management System\r\n• Personal Portfolio Website'),
(12, 45, 'Internship', NULL, NULL, '../uploads/cvs/CV_STUDENT_45_1786130591.pdf', NULL, NULL, '0616545509', NULL, NULL, 'Pending', NULL, '078886565509', 'Female', NULL, NULL, NULL, NULL, 0.00, NULL, '2004-06-17', '19990101-12345-00001-00', 'None', 'Mliman', 'Morogoro Mjini', 'Morogoro', 'bachelor of computer sciences', '3', 'christian', 'P.O.BOX 320', 'Database,\r\nprogramming language,\r\nFramework and technologies', 'Teamwork, \r\nLeadership,\r\nCommuunication,', 'Student Software Developer\r\nAcademic and Personal Projects\r\n2024 – Present', 'English', 'Recognized for teamwork and project presentation during academic group projects.', '', 'Morogoro', 'Motivated and detail-oriented Bachelor of Science in Computer Science student with a strong foundation in software development, database management, networking, and web technologies. Passionate about solving real-world problems through technology and continuously expanding technical knowledge. Quick to learn new tools, adaptable to different working environments, and committed to delivering high-quality results both independently and as part of a team.', 'Bachelor of Science in Computer Science\r\nArdhi university\r\n2023-present\r\nDesigned and developed web-based applications using modern programming technologies.\r\nCreated and managed relational databases for academic projects.', 'Internship Placement Management System\r\nStudent Management System'),
(13, 46, 'Internship', NULL, NULL, NULL, NULL, NULL, '0622545409', NULL, NULL, 'Pending', NULL, '078886565509', 'Female', NULL, NULL, NULL, NULL, 0.00, NULL, '2002-06-13', '19990101-25781-00001-00', 'None', 'Mlalakuwa', 'Kinondoni', 'Dar es salaam', 'bachelor of computer Engineering', '4', 'christian', 'P.O.BOX', 'Databse,\r\nframework and technologies,', 'Problem-solving,\r\nTime management,\r\nCreativity', 'Student Software Developer\r\nAcademic Projects | 2023 – Present', 'English', 'Successfully Completed Multiple Software Development Projects', 'Cisco Networking Academy – Networking Basics', 'Dar es salaam', 'Motivated Computer Science student with a strong interest in software development, database management, networking, and cybersecurity. Skilled in building web applications, solving technical problems, and working collaboratively in team environments. Passionate about learning new technologies and applying them to develop innovative and efficient solutions.', 'Bachelor of Science in Computer engineer\r\nUniversity of Dar es Salaam (UDSM)\r\n2022 – Present', 'Student Record Management System\r\nPersonal Portfolio Website'),
(14, 50, 'Field Study', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 51, 'Internship', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 52, 'Field Study', NULL, NULL, '../uploads/cvs/CV_STUDENT_52_1786119996.pdf', NULL, NULL, '', NULL, NULL, 'Pending', NULL, '0765490952', 'Female', NULL, NULL, NULL, NULL, 0.00, '../uploads/avatars/avatar_52_1786120277.jpg', '0000-00-00', '19990101-25781-00001-00', '', '', '', '', '', '', '', '', 'Node.js,\r\nMySQL,\r\nPython,\r\nGit & GitHub,\r\nMicrosoft Office', 'Problem Solving,\r\nTime Management,\r\nAdaptability,\r\nExperience', 'ICT Intern\r\n\r\nAssisted in maintaining computer systems and networks.\r\nProvided technical support to staff.\r\nParticipated in web application development and system testing.', 'English', 'Best Final Year Project Participant', 'Cisco Networking Academy – Networking Basics', 'Dar es salaam', 'Motivated and hardworking Computer Science graduate with strong knowledge of software development, database management, networking, and web technologies. Passionate about learning new technologies and applying technical skills to solve real-world problems. Able to work independently and as part of a team.', 'Bachelor of Science in Computer Science\r\nUniversity of Dar es Salaam\r\n2022 – 2025\r\nAdvanced Certificate of Secondary Education (ACSEE)\r\n2020 – 2022\r\nCertificate of Secondary Education (CSEE)\r\n2016 – 2019', 'Intelligent Career Placement Management System\r\n\r\nDesigned and developed a web-based system for internship and career placement.\r\nImplemented student, company, and administrator modules.\r\nUsed React.js, Node.js, Express.js, and MySQL.');

-- --------------------------------------------------------

--
-- Table structure for table `system_logs`
--

CREATE TABLE `system_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('admin','company','student') NOT NULL,
  `action` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_messages`
--

CREATE TABLE `system_messages` (
  `msg_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message_text` text NOT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_notifications`
--

CREATE TABLE `system_notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) DEFAULT 'reset_request',
  `otp_code` varchar(10) NOT NULL,
  `status` varchar(20) DEFAULT 'unread',
  `is_resolved` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_notifications`
--

INSERT INTO `system_notifications` (`id`, `user_id`, `message`, `type`, `otp_code`, `status`, `is_resolved`, `created_at`) VALUES
(1, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 183003', 'reset_request', '183003', 'read', 1, '2026-06-24 20:16:47'),
(2, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 541700', 'reset_request', '541700', 'unread', 0, '2026-06-24 20:19:10'),
(3, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 604237', 'reset_request', '604237', 'unread', 0, '2026-06-24 20:19:15'),
(4, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 241708', 'reset_request', '241708', 'unread', 0, '2026-06-24 20:19:35'),
(5, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 661677', 'reset_request', '661677', 'unread', 0, '2026-06-24 20:21:06'),
(6, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 599856', 'reset_request', '599856', 'read', 1, '2026-06-24 20:22:33'),
(7, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 628621', 'reset_request', '628621', 'read', 1, '2026-06-24 20:26:50'),
(8, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 955574', 'reset_request', '955574', 'read', 1, '2026-06-24 20:30:07'),
(9, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 555233', 'reset_request', '555233', 'read', 1, '2026-06-24 20:31:10'),
(10, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 629084', 'reset_request', '629084', 'read', 1, '2026-06-24 20:34:32'),
(11, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 222724', 'reset_request', '222724', 'read', 1, '2026-06-24 20:34:55'),
(12, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 374739', 'reset_request', '374739', 'unread', 0, '2026-06-24 20:45:22'),
(13, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 443414', 'reset_request', '443414', 'unread', 0, '2026-06-24 20:49:56'),
(14, 34, 'User TTCL Corporation (corporation@ttcl.co.tz) requested a secure account recovery link. Verification code generated: 881327', 'reset_request', '881327', 'unread', 0, '2026-06-25 19:14:26'),
(15, 32, 'User Yass Limited Company (yass@tigo.co.tz) requested a secure account recovery link. Verification code generated: 776089', 'reset_request', '776089', 'unread', 0, '2026-06-25 19:16:06'),
(16, 26, 'User NMB BANK (nmb@gmail.com) requested a secure account recovery link. Verification code generated: 550535', 'reset_request', '550535', 'unread', 0, '2026-06-29 19:16:24'),
(17, 4, 'User TTCL (ttcl@gmail.com) requested a secure account recovery link. Verification code generated: 132961', 'reset_request', '132961', 'unread', 0, '2026-07-04 08:05:11'),
(18, 43, 'User TACL (ttacl@gmail.com) requested a secure account recovery link. Verification code generated: 413812', 'reset_request', '413812', 'unread', 0, '2026-08-04 09:58:05');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES
('allow_company_reg', '1'),
('allow_student_reg', '1'),
('enable_vacancy_board', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT 'Admin',
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `reg_number` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','company','admin') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_pic` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT 'Tanzania',
  `id` int(11) DEFAULT NULL,
  `is_blocked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `full_name`, `email`, `reg_number`, `password`, `role`, `created_at`, `profile_pic`, `location`, `id`, `is_blocked`) VALUES
(4, 'Admin', 'TTCL', 'ttcl@gmail.com', NULL, '$2y$10$L/0PddlNsw4tLPQscAxNveLduELUizHJWkwrvfi6WciXV8/wK.pmm', 'company', '2026-05-13 01:44:04', NULL, 'Dar es Salaam', 4, 0),
(8, 'Admin', 'all', 'ally@gmail.com', NULL, '$2y$10$GTvSr1H5UeBm0oHk9rvtIeT29rj1Cb3mP.CBoDTv7i9y1c9J9Fa0O', 'student', '2026-05-14 22:55:39', NULL, 'Tanzania', 8, 0),
(11, 'Admin', 'DEULI LYDIA', 'Lydiadeuli@gmail.com', NULL, '$2y$10$iwVxfcVf7AhbkGIHotPzrOBIewpWbsfMxBKr5PoS4AYcSu0kdwlC2', 'admin', '2026-05-20 23:43:52', 'uploads/profile_pics/admin_11_1782431917.jpeg', 'Tanzania', 11, 0),
(16, 'Admin', 'TCRA', 'tcra@gmail.com', NULL, '$2y$10$ep/SZJzW1w5HzDcoqefH0us/nCuhhTYOOyGsIC/Ogws72LtHo7PUm', 'company', '2026-05-21 02:48:16', NULL, 'Dar es Salaam', 16, 0),
(18, 'Admin', 'BAKITA', 'bakita@gmail.com', NULL, '$2y$10$d6EKOtuhSYpSRi39RJTk9eIBIoSYqTISbb6l0x3LaGOHfVcpAMbhu', 'company', '2026-05-21 02:50:58', NULL, 'Dar es Salaam', 18, 0),
(19, 'Admin', 'juli', 'juliddeuli@gmail.com', NULL, '$2y$10$EbRzvJCieZM/d..lKK0rGOyxGnfllC9lj.PQ0IHpQKvHfYSo7hHUK', 'student', '2026-05-27 20:30:17', NULL, 'Tanzania', 19, 0),
(21, 'Admin', 'TTCL Corporation', 'placement@ttcl.co.tz', NULL, '$2y$10$xyz...', 'company', '2026-05-27 21:41:12', NULL, 'Dar es Salaam', 21, 0),
(23, 'Admin', 'JULIETH DEULI', 'julieth@gmail.com', NULL, '$2y$10$xY8dn4dkhBCaXG2K0YxoPuU18Npk4cI0IH4WOp6ThXGpRU6GFBwWq', 'student', '2026-05-28 01:37:51', NULL, 'Tanzania', 23, 0),
(24, 'Admin', 'surya', 'surya@gmail.com', NULL, '$2y$10$0Kvg/Xs5zDQG53aSVlCNqu5T3E/nLd9vdZVjxhDIpsyORv71Fxzte', 'student', '2026-06-09 16:05:29', NULL, 'Tanzania', 24, 0),
(25, 'Admin', 'DON', 'don@gmail.com', NULL, '$2y$10$rl1wZwUI7UQX6MQHdznTCeZgCL39M90iMtMYWJMGBK3hFxBZnluuq', 'company', '2026-06-15 23:56:01', NULL, 'Dar es Salaam', 25, 0),
(26, 'Admin', 'NMB BANK', 'nmb@gmail.com', NULL, '$2y$10$jK7lABNQ/BUilCO57rbvb.RX43.yYZnO/xvuwOIFRe1Sgy.TraLAi', 'company', '2026-06-18 23:22:52', NULL, 'Dar es Salaam', 26, 0),
(30, 'Admin', 'Vodacom Limited Company', 'hr@vodacom.co.tz', NULL, '$2y$10$P8mL7RKycvfOxaMBIXyta.2BP.QtdeV1fW4BVtkmlAyS40nLwVN4q', 'company', '2026-06-24 21:42:30', NULL, 'Dar es Salaam', 30, 1),
(32, 'Admin', 'Yass Limited Company', 'yass@tigo.co.tz', NULL, '$2y$10$z6RC0Wb4s6BwL/OTebU4MeTCXeeOTKk/SzlwDogmMwz4Weu62XPm6', 'company', '2026-06-24 23:15:39', NULL, 'Dar es Salaam', 32, 0),
(34, 'Admin', 'TTCL Corporation', 'corporation@ttcl.co.tz', NULL, '$2y$10$Un5G5IPrzOOTB5eF6Ohe4ulMjFSLArmbJqRACj1oEJLwc5R6EVlli', 'company', '2026-06-24 23:25:19', NULL, 'Dar es Salaam', 34, 0),
(35, 'Admin', 'kase', 'yao@kesi.co.tz', NULL, '$2y$10$gxfVNv6JfXS3pJm6VpN6teENJCK8jOtywZxG3Ys4fgqz16v4DFILG', 'company', '2026-06-24 23:29:15', NULL, 'Dar es Salaam', 35, 0),
(36, 'Admin', 'Airtel Tanzania', 'airtel@mtandao.co.tz', NULL, '$2y$10$s6ySOmWt.yEc1Rcwgoczgu1eZy60RhVft8bUUyfbhEj8aZlN1/08y', 'company', '2026-06-30 17:53:06', NULL, 'Dar es Salaam', 36, 0),
(37, 'Admin', 'Aryan Singh Rathore', 'aryanrathore@gmail.com', NULL, '$2y$10$TOa9Fjjh8/s3BdgmMpEGbeJETeYEnvNqdMIOet4OwLx/1ZsgKKyay', 'student', '2026-07-01 00:54:39', NULL, 'Tanzania', 37, 0),
(38, 'Admin', 'BOSCO FALES', 'bosco@gmail.com', NULL, '$2y$10$VU4D7wXvS.KsMK54/4fuCeAPmFMYHljnYkaxCedkQ2hSzYRnK9./a', 'student', '2026-07-04 08:16:50', NULL, 'Tanzania', 38, 0),
(39, 'Admin', 'SHEKH KINJUNGA', 'bosco3@gmail.com', NULL, '$2y$10$gGweR0Dk9ImPLB8/krzW1O/lqayu9H5oqydXfXJYuQ7Y7Co/r/uJe', 'company', '2026-07-04 09:08:08', NULL, 'Dar es Salaam', 39, 0),
(40, 'Admin', 'KAKA DON', 'kas@gmail.com', NULL, '$2y$10$EqQPsBWgSuXTgAXzbM1vQujdyRDsTYa7T/ishBhQKNktZXWvvrNr.', 'student', '2026-07-06 11:07:39', NULL, 'Tanzania', 0, 0),
(41, 'Admin', 'ARDHI UNIVERSITY', 'aru@gmail.com', NULL, '$2y$10$vG6QN.RmUXyzcG90klArhecJEx7gtuNFlLk80AP60NPcbuaAKYuey', 'company', '2026-08-03 13:33:22', NULL, 'Tanzania', 0, 0),
(43, 'Admin', 'TACL', 'ttacl@gmail.com', NULL, '$2y$10$t88vgWKve6EtDjyTyspd3.9jyUbYP0vc6LtEKNkq1qO0g2rR76eZq', 'company', '2026-08-03 14:56:24', NULL, 'Tanzania', 0, 0),
(44, 'Admin', 'JERRY LYSON ANDREA', 'jerry@gmail.com', NULL, '$2y$10$Y7JkChPMIa4Fulpi.7DcxO.BP8LJZXPcBX7jW3Eccbnsv2Iv4Qcey', 'student', '2026-08-04 13:45:19', NULL, 'Tanzania', 0, 0),
(45, 'Admin', 'Inesta Baraka  Mwayaya', 'inesta@gmail.com', NULL, '$2y$10$HJXTbVE7jv9/gyBbkaepmOYZB1WXJ3bS8bOLFVWXm2GkSH7i3AQHy', 'student', '2026-08-06 15:56:44', NULL, 'Tanzania', 0, 0),
(46, 'Admin', 'Neema D mushi', 'neema@gmail.com', NULL, '$2y$10$JEG60jLpL0tjwhME4aesO.L0sRy.5Op7siFnOsUeA96m6neSF2TnW', 'student', '2026-08-06 16:54:08', NULL, 'Tanzania', 0, 0),
(47, 'Admin', 'CRDB Bank Plc', 'recruitment@crdbbank.co.tz', NULL, '$2y$10$HK2NPnJ.gntPYNnoq/vB1O8Mhi1Hsep3dDpVdw.pGAkbvioFbMiei', 'company', '2026-08-07 15:42:51', NULL, 'Tanzania', 0, 0),
(48, 'Admin', 'Tanzania Breweries Limited (TBL)', 'recruitment@tbl.co.tz', NULL, '$2y$10$N1PNVFvPaTocNb7/vvP.R.BAwxCfzHdf.bCkM.dq/TS5GveXNpowy', 'company', '2026-08-07 15:47:30', NULL, 'Tanzania', 0, 0),
(49, 'Admin', 'Tanzania Electric Supply Company Limited', 'recruitment@tanesco.co.tz', NULL, '$2y$10$vrv8hprH1/IjHfvAP4atseKjaNLCrBqk0dm1dYxGTimlhWpXpLt7i', 'company', '2026-08-07 15:53:56', NULL, 'Tanzania', 0, 0),
(50, 'Admin', 'Ben Peter Dhahabu', 'ben@gmail.com', NULL, '$2y$10$2WC9QSOJfF9C3R9dKAdUEuW1nwaxVY0PK98ikFDgCTZ7Ce9qTN4Ta', 'student', '2026-08-07 16:11:50', NULL, 'Tanzania', 0, 0),
(51, 'Admin', 'Bluno T Thomas', 'bluno@gmail.com', NULL, '$2y$10$/PP4iB5sRn1B.BdcYrvmN.grziWNpetet6zgU22Uub8yv.iyNH4O2', 'student', '2026-08-07 16:13:14', NULL, 'Tanzania', 0, 0),
(52, 'Admin', 'Mercan T Ates', 'mercan@gmail.com', NULL, '$2y$10$gREyRv87nNZVEekX/8Lo5uUlSYnafu8mwHlqHzgImz4YEEQbvw7.2', 'student', '2026-08-07 16:16:40', NULL, 'Tanzania', 0, 0);

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `sync_users_id_on_insert` BEFORE INSERT ON `users` FOR EACH ROW BEGIN
    -- This ensures if 'id' is empty on a new registration, it copies the value or stays aligned
    SET NEW.id = NEW.user_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `vacancies`
--

CREATE TABLE `vacancies` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `status` enum('Open','Closed') DEFAULT 'Open',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`app_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `opportunity_id` (`opportunity_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_opportunities`
--
ALTER TABLE `company_opportunities`
  ADD PRIMARY KEY (`opp_id`);

--
-- Indexes for table `company_opportunity`
--
ALTER TABLE `company_opportunity`
  ADD PRIMARY KEY (`opp_id`);

--
-- Indexes for table `company_profiles`
--
ALTER TABLE `company_profiles`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD PRIMARY KEY (`app_id`),
  ADD KEY `opportunity_id` (`opportunity_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `opportunities`
--
ALTER TABLE `opportunities`
  ADD PRIMARY KEY (`opp_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`org_id`),
  ADD UNIQUE KEY `org_name` (`org_name`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `referee_recommendations`
--
ALTER TABLE `referee_recommendations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `secure_token` (`secure_token`),
  ADD KEY `application_id` (`application_id`);

--
-- Indexes for table `student_docs`
--
ALTER TABLE `student_docs`
  ADD PRIMARY KEY (`doc_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `student_logbooks`
--
ALTER TABLE `student_logbooks`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `student_notifications`
--
ALTER TABLE `student_notifications`
  ADD PRIMARY KEY (`notif_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `system_messages`
--
ALTER TABLE `system_messages`
  ADD PRIMARY KEY (`msg_id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `system_notifications`
--
ALTER TABLE `system_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vacancies`
--
ALTER TABLE `vacancies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company_opportunities`
--
ALTER TABLE `company_opportunities`
  MODIFY `opp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `company_opportunity`
--
ALTER TABLE `company_opportunity`
  MODIFY `opp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job_applications`
--
ALTER TABLE `job_applications`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `opportunities`
--
ALTER TABLE `opportunities`
  MODIFY `opp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `referee_recommendations`
--
ALTER TABLE `referee_recommendations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_docs`
--
ALTER TABLE `student_docs`
  MODIFY `doc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student_logbooks`
--
ALTER TABLE `student_logbooks`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_notifications`
--
ALTER TABLE `student_notifications`
  MODIFY `notif_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `student_profiles`
--
ALTER TABLE `student_profiles`
  MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `system_logs`
--
ALTER TABLE `system_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_messages`
--
ALTER TABLE `system_messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_notifications`
--
ALTER TABLE `system_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `vacancies`
--
ALTER TABLE `vacancies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `applications`
--
ALTER TABLE `applications`
  ADD CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_opportunity` FOREIGN KEY (`opportunity_id`) REFERENCES `opportunities` (`opp_id`) ON DELETE CASCADE;

--
-- Constraints for table `company_profiles`
--
ALTER TABLE `company_profiles`
  ADD CONSTRAINT `company_profiles_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD CONSTRAINT `job_applications_ibfk_1` FOREIGN KEY (`opportunity_id`) REFERENCES `company_opportunities` (`opp_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `job_applications_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `opportunities`
--
ALTER TABLE `opportunities`
  ADD CONSTRAINT `opportunities_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `referee_recommendations`
--
ALTER TABLE `referee_recommendations`
  ADD CONSTRAINT `referee_recommendations_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `applications` (`app_id`) ON DELETE CASCADE;

--
-- Constraints for table `student_docs`
--
ALTER TABLE `student_docs`
  ADD CONSTRAINT `student_docs_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `student_logbooks`
--
ALTER TABLE `student_logbooks`
  ADD CONSTRAINT `student_logbooks_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `student_notifications`
--
ALTER TABLE `student_notifications`
  ADD CONSTRAINT `student_notifications_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD CONSTRAINT `student_profiles_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `system_messages`
--
ALTER TABLE `system_messages`
  ADD CONSTRAINT `system_messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `system_messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `system_notifications`
--
ALTER TABLE `system_notifications`
  ADD CONSTRAINT `system_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
